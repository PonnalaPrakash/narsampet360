# Update Notes

- API URL requires `EXPO_PUBLIC_API_URL`; no localhost fallback is used.
- Auth state is hydrated from SecureStore on app startup.
- The root route now restores an existing authenticated session instead of always redirecting to login.
- OTP error UI no longer exposes request URLs or raw response objects.
- Development debug logging was removed from app screens.
