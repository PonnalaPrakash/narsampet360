# Update Notes

- API client refreshes expired access tokens before retrying requests.
- Report CSV/PDF downloads use the authenticated Axios client.
- Attachment open/download actions use authenticated requests instead of public URLs.
- Development debug logging was removed from admin pages.
- API URL is configured through `VITE_API_URL`.
