
import {
  Link,
  useLocation,
} from "react-router-dom";

type UserRole =
  | "ADMIN"
  | "MLA"
  | "PA"
  | "MANDAL_INCHARGE"
  | "VILLAGE_COORDINATOR"
  | "OFFICER";

interface MenuItem {
  name: string;
  path: string;
}

export default function Sidebar() {
  const location = useLocation();

  const role =
    localStorage
      .getItem("role")
      ?.toUpperCase() as UserRole | undefined;

  const userString =
    localStorage.getItem("user");

  let user: any = null;

  try {
    user = userString
      ? JSON.parse(userString)
      : null;
  } catch {
    user = null;
  }

  const userName =
    user?.name || "User";

  /*
   * ============================================================
   * COMMON MENUS
   * ============================================================
   */

  const commonMenus: MenuItem[] = [
    {
      name: "Dashboard",
      path: "/dashboard",
    },
    {
      name: "Grievances",
      path: "/grievances",
    },
  ];

  /*
   * ============================================================
   * ADMIN MENUS
   * ============================================================
   */

  const adminMenus: MenuItem[] = [
    {
      name: "Users",
      path: "/users",
    },
    {
      name: "Departments",
      path: "/departments",
    },
    {
      name: "Mandals",
      path: "/mandals",
    },
    {
      name: "Villages",
      path: "/villages",
    },
    {
      name: "Constituency",
      path: "/constituency",
    },
    {
      name: "Reports",
      path: "/reports",
    },
  ];

  /*
   * ============================================================
   * OFFICER MENUS
   * ============================================================
   */

  const officerMenus: MenuItem[] = [
    {
      name: "Officer Dashboard",
      path: "/officer-dashboard",
    },
    {
      name: "My Grievances",
      path: "/my-grievances",
    },
  ];

  /*
   * ============================================================
   * ROLE-BASED MENU
   *
   * Frontend menu restriction is only for UI.
   * Backend remains the actual security layer.
   * ============================================================
   */

  let menus: MenuItem[] = [];

  switch (role) {
    case "OFFICER":
      menus = officerMenus;
      break;

    case "ADMIN":
      menus = [
        ...commonMenus,
        ...adminMenus,
      ];
      break;

    case "MLA":
      menus = [
        ...commonMenus,
        {
          name: "Constituency",
          path: "/constituency",
        },
        {
          name: "Reports",
          path: "/reports",
        },
      ];
      break;

    case "PA":
      menus = [
        ...commonMenus,
        {
          name: "Reports",
          path: "/reports",
        },
      ];
      break;

    case "MANDAL_INCHARGE":
      menus = [
        ...commonMenus,
        {
          name: "Mandals",
          path: "/mandals",
        },
      ];
      break;

    case "VILLAGE_COORDINATOR":
      menus = [
        ...commonMenus,
        {
          name: "Villages",
          path: "/villages",
        },
      ];
      break;

    default:
      menus = commonMenus;
      break;
  }

  /*
   * ============================================================
   * ACTIVE MENU
   * ============================================================
   */

  function isActive(path: string) {
    if (location.pathname === path) {
      return true;
    }

    /*
     * Grievance detail should keep Grievances active
     */
    if (
      path === "/grievances" &&
      (
        location.pathname.startsWith(
          "/grievance/"
        ) ||
        location.pathname.startsWith(
          "/grievances/"
        )
      )
    ) {
      return true;
    }

    /*
     * User detail/edit should keep Users active
     */
    if (
      path === "/users" &&
      location.pathname.startsWith("/user/")
    ) {
      return true;
    }

    return false;
  }

  /*
   * ============================================================
   * LOGOUT
   * ============================================================
   */

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("role");
    localStorage.removeItem("user");

    window.location.href = "/login";
  }

  /*
   * ============================================================
   * UI
   * ============================================================
   */

  return (
    <aside
      style={{
        width: "220px",
        minWidth: "220px",
        height: "100vh",

        position: "fixed",
        left: 0,
        top: 0,

        background: "#1f2937",
        color: "#fff",

        padding: "20px 16px",
        boxSizing: "border-box",

        display: "flex",
        flexDirection: "column",

        overflow: "hidden",
        zIndex: 1000,
      }}
    >

      {/* ================= HEADER ================= */}

      <div
        style={{
          marginBottom: 24,
          flexShrink: 0,
        }}
      >
        <h2
          style={{
            margin: 0,
            marginBottom: 10,

            fontSize: 21,
            lineHeight: 1.2,

            color: "#ffffff",

            whiteSpace: "nowrap",
          }}
        >
          Narsampet360
        </h2>

        <div
          style={{
            fontSize: 12,
            color: "#93c5fd",
            fontWeight: 700,

            marginBottom: 5,

            letterSpacing: "0.5px",
          }}
        >
          {role || "USER"}
        </div>

        <div
          style={{
            fontSize: 14,
            color: "#d1d5db",

            whiteSpace: "normal",
            overflowWrap: "break-word",

            lineHeight: 1.4,
          }}
        >
          {userName}
        </div>
      </div>

      {/* ================= NAVIGATION ================= */}

      <nav
        style={{
          flex: 1,
          minHeight: 0,

          overflowY: "auto",
          overflowX: "hidden",

          paddingRight: 2,
        }}
      >
        {menus.map((menu) => {
          const active =
            isActive(menu.path);

          return (
            <Link
              key={menu.path}
              to={menu.path}
              style={{
                display: "flex",
                alignItems: "center",

                width: "100%",
                minHeight: "44px",

                boxSizing: "border-box",

                padding: "11px 13px",
                marginBottom: 7,

                textDecoration: "none",

                color: "#ffffff",

                borderRadius: 8,

                background: active
                  ? "#2563eb"
                  : "transparent",

                fontWeight: active
                  ? 600
                  : 400,

                fontSize: 15,
                lineHeight: 1.35,

                whiteSpace: "normal",
                overflowWrap: "break-word",

                transition:
                  "background 0.2s ease",
              }}
            >
              {menu.name}
            </Link>
          );
        })}
      </nav>

      {/* ================= LOGOUT ================= */}

      <button
        onClick={logout}
        style={{
          marginTop: 15,

          width: "100%",
          minHeight: "44px",

          padding: "11px 13px",

          border: "none",
          borderRadius: 8,

          cursor: "pointer",

          background: "#dc2626",
          color: "#ffffff",

          fontWeight: 600,
          fontSize: 15,

          flexShrink: 0,

          whiteSpace: "nowrap",
        }}
      >
        Logout
      </button>

    </aside>
  );
}
