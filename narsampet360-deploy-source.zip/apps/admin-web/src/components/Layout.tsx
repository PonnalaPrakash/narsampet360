import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";

export default function Layout() {
  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        background: "#f5f6f8",
        boxSizing: "border-box",
      }}
    >
      <Sidebar />

      <main
        style={{
          marginLeft: "220px",
          width: "calc(100% - 220px)",
          minHeight: "100vh",
          boxSizing: "border-box",
          overflowX: "hidden",
        }}
      >
        <Outlet />
      </main>
    </div>
  );
}