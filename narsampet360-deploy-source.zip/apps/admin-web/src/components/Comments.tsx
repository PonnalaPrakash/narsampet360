import { useEffect, useState } from "react";
import {
  addComment,
  deleteComment,
  getComments,
  updateComment,
  type Comment,
} from "./commentsApi";

interface CommentsProps {
  grievanceId: string;
  grievanceStatus: string;
}

export default function Comments({
  grievanceId,
  grievanceStatus,
}: CommentsProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const isReadOnly =
    grievanceStatus === "RESOLVED" ||
    grievanceStatus === "CLOSED" ||
    grievanceStatus === "REJECTED";

  const loadComments = async () => {
    try {
      setLoading(true);
      setError("");

      const data = await getComments(grievanceId);

      setComments(data);
    } catch (err: any) {
      setError(
        err?.message || "Failed to load comments",
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (grievanceId) {
      loadComments();
    }
  }, [grievanceId]);

  const handleAddComment = async () => {
    const trimmedMessage = message.trim();

    if (!trimmedMessage) {
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      const newComment = await addComment(
        grievanceId,
        trimmedMessage,
      );

      setComments((previous) => [
        newComment,
        ...previous,
      ]);

      setMessage("");
    } catch (err: any) {
      setError(
        err?.message || "Failed to add comment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      setError("");

      await deleteComment(id);

      setComments((previous) =>
        previous.filter(
          (comment) => comment.id !== id,
        ),
      );
    } catch (err: any) {
      setError(
        err?.message || "Failed to delete comment",
      );
    }
  };

  const handleEdit = async (
    comment: Comment,
  ) => {
    const newMessage = window.prompt(
      "Edit comment",
      comment.message,
    );

    if (
      newMessage === null ||
      !newMessage.trim()
    ) {
      return;
    }

    try {
      setError("");

      const updated = await updateComment(
        comment.id,
        newMessage.trim(),
      );

      setComments((previous) =>
        previous.map((item) =>
          item.id === updated.id
            ? updated
            : item,
        ),
      );
    } catch (err: any) {
      setError(
        err?.message || "Failed to update comment",
      );
    }
  };

  return (
    <div className="comments-section">
      <div className="comments-header">
        <h3>Comments</h3>

        <span>
          {comments.length}
        </span>
      </div>

      {error && (
        <div className="comments-error">
          {error}
        </div>
      )}

      {!isReadOnly && (
        <div className="comment-input">
          <textarea
            value={message}
            onChange={(event) =>
              setMessage(event.target.value)
            }
            placeholder="Write a comment..."
            rows={3}
            maxLength={5000}
            disabled={submitting}
          />

          <button
            type="button"
            onClick={handleAddComment}
            disabled={
              submitting ||
              !message.trim()
            }
          >
            {submitting
              ? "Adding..."
              : "Add Comment"}
          </button>
        </div>
      )}

      {isReadOnly && (
        <div className="comments-readonly">
          Comments are view-only because this
          grievance is {grievanceStatus}.
        </div>
      )}

      {loading ? (
        <div>Loading comments...</div>
      ) : comments.length === 0 ? (
        <div>No comments yet.</div>
      ) : (
        <div className="comments-list">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className="comment-item"
            >
              <div className="comment-top">
                <strong>
                  {comment.user?.name ||
                    "Unknown User"}
                </strong>

                <span>
                  {comment.user?.role || ""}
                </span>
              </div>

              <div className="comment-message">
                {comment.message}
              </div>

              <div className="comment-bottom">
                <small>
                  {new Date(
                    comment.createdAt,
                  ).toLocaleString()}
                </small>

                {!isReadOnly && (
                  <div>
                    <button
                      type="button"
                      onClick={() =>
                        handleEdit(comment)
                      }
                    >
                      Edit
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleDelete(comment.id)
                      }
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}