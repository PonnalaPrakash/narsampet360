import client from "../api/client";

export interface CommentUser {
  id: string;
  name: string;
  role: string;
}

export interface Comment {
  id: string;
  grievanceId: string;
  userId: string;
  message: string;
  createdAt: string;
  updatedAt: string;
  user: CommentUser;
}

export async function getComments(
  grievanceId: string,
): Promise<Comment[]> {
  const response = await client.get("/comments", {
    params: { grievanceId },
  });
  return response.data;
}

export async function addComment(
  grievanceId: string,
  message: string,
): Promise<Comment> {
  const response = await client.post("/comments", {
    grievanceId,
    message,
  });
  return response.data;
}

export async function updateComment(
  id: string,
  message: string,
): Promise<Comment> {
  const response = await client.patch(`/comments/${id}`, {
    message,
  });
  return response.data;
}

export async function deleteComment(id: string): Promise<void> {
  await client.delete(`/comments/${id}`);
}
