
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import Grievances from "./pages/Grievances";
import NewGrievance from "./pages/NewGrievance";
import GrievanceDetails from "./pages/GrievanceDetails";

import Users from "./pages/Users";
import UserDetails from "./pages/UserDetails";
import CreateUser from "./pages/CreateUser";
import EditUser from "./pages/EditUser";

import Departments from "./pages/Departments";
import Mandals from "./pages/Mandals";
import Villages from "./pages/Villages";

import Login from "./pages/Login";

import Layout from "./components/Layout";
import ProtectedRoute from "./routes/ProtectedRoute";

import Constituency from "./pages/Constituency";
import Reports from "./pages/Reports";

import OfficerDashboard from "./pages/OfficerDashboard";
import OfficerGrievances from "./pages/OfficerGrievances";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* =====================================================
            LOGIN
            ===================================================== */}

        <Route
          path="/login"
          element={<Login />}
        />

        {/* =====================================================
            DEFAULT
            ===================================================== */}

        <Route
          path="/"
          element={
            <Navigate
              to="/dashboard"
              replace
            />
          }
        />

        {/* =====================================================
            AUTHENTICATED ROUTES
            ===================================================== */}

        <Route element={<ProtectedRoute />}>

          {/* =================================================
              COMMON LAYOUT ROUTES
              ================================================= */}

          <Route element={<Layout />}>

            <Route
              path="/dashboard"
              element={<Dashboard />}
            />

            <Route
              path="/grievances"
              element={<Grievances />}
            />

            <Route
              path="/grievance/new"
              element={<NewGrievance />}
            />

            {/* =================================================
                GRIEVANCE DETAILS

                Both URLs are supported:

                /grievance/:id
                /grievances/:id
                ================================================= */}

            <Route
              path="/grievance/:id"
              element={<GrievanceDetails />}
            />

            <Route
              path="/grievances/:id"
              element={<GrievanceDetails />}
            />

            <Route
              path="/users"
              element={<Users />}
            />

            <Route
              path="/user/:id"
              element={<UserDetails />}
            />

            <Route
              path="/users/create"
              element={<CreateUser />}
            />

            <Route
              path="/user/:id/edit"
              element={<EditUser />}
            />

            <Route
              path="/departments"
              element={<Departments />}
            />

            <Route
              path="/mandals"
              element={<Mandals />}
            />

            <Route
              path="/villages"
              element={<Villages />}
            />

            <Route
              path="/constituency"
              element={<Constituency />}
            />

            <Route
              path="/reports"
              element={<Reports />}
            />

          </Route>

          {/* =================================================
              OFFICER-ONLY ROUTES
              ================================================= */}

          <Route
            element={
              <ProtectedRoute
                roles={["OFFICER"]}
              />
            }
          >

            <Route
              path="/officer-dashboard"
              element={<OfficerDashboard />}
            />

            <Route
              path="/my-grievances"
              element={<OfficerGrievances />}
            />

          </Route>

        </Route>

      </Routes>
    </BrowserRouter>
  );
}

export default App;
