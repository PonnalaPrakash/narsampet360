import client from "./client";

export const getDepartments = async()=>{

const res =
await client.get("/departments");

return res.data;

};


export const createDepartment = async(data:any)=>{

const res =
await client.post(
"/departments",
data
);

return res.data;

};


export const updateDepartment = async(
id:string,
data:any
)=>{

const res =
await client.patch(
`/departments/${id}`,
data
);

return res.data;

};


export const deleteDepartment = async(
id:string
)=>{

const res =
await client.delete(
`/departments/${id}`
);

return res.data;

};