import axios from "axios";

/**
 * =====================================================
 * API CLIENT
 * =====================================================
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || "/api/v1";

const API = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

/**
 * =====================================================
 * AUTH TOKEN INTERCEPTOR
 * =====================================================
 */

API.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

/**
 * =====================================================
 * DEFAULT API EXPORT
 * =====================================================
 */

export default API;

/**
 * =====================================================
 * GET GRIEVANCE DASHBOARD
 * =====================================================
 */

export const getGrievanceDashboard = async () => {
  const response = await API.get("/grievance/dashboard");

  return response.data;
};

/**
 * =====================================================
 * GET GRIEVANCES
 * =====================================================
 */

export type GrievanceFilters = {
  status?: string;
  date?: string;
};

export const getGrievances = async (
  params?: GrievanceFilters,
) => {
  const response = await API.get("/grievance", {
    params,
  });

  return response.data;
};

/**
 * =====================================================
 * GET MY ASSIGNED GRIEVANCES
 * =====================================================
 */

export const getMyGrievances = async () => {
  const response = await API.get("/grievance/my");

  return response.data;
};

/**
 * =====================================================
 * GET SINGLE GRIEVANCE
 * =====================================================
 */

export const getGrievanceById = async (
  id: string,
) => {
  const response = await API.get(
    `/grievance/${id}`,
  );

  return response.data;
};

/**
 * =====================================================
 * GET GRIEVANCE HISTORY
 * =====================================================
 */

export const getGrievanceHistory = async (
  id: string,
) => {
  const response = await API.get(
    `/grievance/${id}/history`,
  );

  return response.data;
};

/**
 * =====================================================
 * GET OFFICERS
 * =====================================================
 */

export const getOfficers = async () => {
  const response = await API.get(
    "/users/officers",
  );

  return response.data;
};

/**
 * =====================================================
 * CREATE GRIEVANCE
 * =====================================================
 */

export type CreateGrievanceData = {
  title: string;
  description: string;

  citizenName: string;
  citizenMobile: string;

  priority?: "LOW" | "MEDIUM" | "HIGH";

  constituencyId?: string;
  mandalId?: string;
  villageId?: string;
  departmentId?: string;
};

export const createGrievance = async (
  data: CreateGrievanceData,
) => {
  const response = await API.post(
    "/grievance",
    data,
  );

  return response.data;
};

/**
 * =====================================================
 * UPDATE GRIEVANCE STATUS
 * =====================================================
 */

export const updateGrievanceStatus = async (
  id: string,
  data: {
    status: string;
    remarks?: string;
  },
) => {
  const response = await API.patch(
    `/grievance/${id}/status`,
    data,
  );

  return response.data;
};

/**
 * =====================================================
 * ASSIGN GRIEVANCE
 * =====================================================
 */

export const assignGrievance = async (
  id: string,
  data: {
    assignedToId: string;
  },
) => {
  const response = await API.patch(
    `/grievance/${id}/assign`,
    data,
  );

  return response.data;
};

/**
 * =====================================================
 * UNDO LAST STATUS CHANGE
 * =====================================================
 */

export const undoGrievance = async (
  id: string,
) => {
  const response = await API.post(
    `/grievance/${id}/undo`,
  );

  return response.data;
};

/**
 * =====================================================
 * ATTACHMENTS
 * =====================================================
 */

export const getGrievanceAttachments = async (
  grievanceId: string,
) => {
  const response = await API.get(
    `/attachments/grievance/${grievanceId}`,
  );

  return response.data;
};

export const uploadGrievanceAttachment = async (
  grievanceId: string,
  file: File,
) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("grievanceId", grievanceId);

  const response = await API.post(
    "/attachments/upload",
    formData,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    },
  );

  return response.data;
};

export const deleteGrievanceAttachment = async (
  attachmentId: string,
) => {
  const response = await API.delete(
    `/attachments/${attachmentId}`,
  );

  return response.data;
};

export const getAttachmentUrl = (fileUrl: string) => {
  if (!fileUrl) return "";

  if (fileUrl.startsWith("http://") || fileUrl.startsWith("https://")) {
    return fileUrl;
  }

  const apiUrl = new URL(API_BASE_URL, window.location.origin);
  const baseOrigin = apiUrl.origin;
  return `${baseOrigin}${fileUrl.startsWith("/") ? "" : "/"}${fileUrl}`;
};

