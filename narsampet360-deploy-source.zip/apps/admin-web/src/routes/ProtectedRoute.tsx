
import { Navigate, Outlet } from "react-router-dom";

type UserRole =
  | "ADMIN"
  | "MLA"
  | "PA"
  | "MANDAL_INCHARGE"
  | "VILLAGE_COORDINATOR"
  | "OFFICER";

interface ProtectedRouteProps {
  roles?: UserRole[];
}

export default function ProtectedRoute({
  roles,
}: ProtectedRouteProps) {
  const token = localStorage.getItem("accessToken");

  const storedRole =
    localStorage.getItem("role")?.toUpperCase() as
      | UserRole
      | undefined;

  // User is not logged in
  if (!token) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  // User is logged in but does not have required role
  if (
    roles &&
    (!storedRole ||
      !roles.includes(storedRole))
  ) {
    return (
      <Navigate
        to="/dashboard"
        replace
      />
    );
  }

  return <Outlet />;
}
