import { useEffect, useMemo, useState } from "react";
import client from "../api/client";

export default function Villages() {
  const [villages, setVillages] = useState<any[]>([]);
  const [mandals, setMandals] = useState<any[]>([]);

  const [name, setName] = useState("");
  const [mandalId, setMandalId] = useState("");

  const [search, setSearch] = useState("");
  const [mandalFilter, setMandalFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const [loading, setLoading] = useState(true);
  const [loadingMandals, setLoadingMandals] = useState(true);
  const [creating, setCreating] = useState(false);

  async function loadVillages() {
    try {
      setLoading(true);

      const res = await client.get("/villages");

      setVillages(
        Array.isArray(res.data)
          ? res.data
          : Array.isArray(res.data?.data)
          ? res.data.data
          : []
      );
    } catch (err: any) {

      setVillages([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadMandals() {
    try {
      setLoadingMandals(true);

      const res = await client.get("/mandals");

      setMandals(
        Array.isArray(res.data)
          ? res.data
          : Array.isArray(res.data?.data)
          ? res.data.data
          : []
      );
    } catch (err: any) {

      setMandals([]);
    } finally {
      setLoadingMandals(false);
    }
  }

  useEffect(() => {
    loadVillages();
    loadMandals();
  }, []);

  async function createVillage() {
    if (!name.trim()) {
      alert("Village name is required");
      return;
    }

    if (!mandalId) {
      alert("Please select mandal");
      return;
    }

    try {
      setCreating(true);

      await client.post("/villages", {
        name: name.trim(),
        mandalId,
      });

      alert("Village created successfully");

      setName("");
      setMandalId("");

      await loadVillages();
    } catch (err: any) {

      const message = err.response?.data?.message;

      alert(
        Array.isArray(message)
          ? message.join(", ")
          : message || "Create failed"
      );
    } finally {
      setCreating(false);
    }
  }

  async function deleteVillage(id: string) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this village?"
    );

    if (!confirmed) {
      return;
    }

    try {
      await client.delete(`/villages/${id}`);

      alert("Village deleted successfully");

      await loadVillages();
    } catch (err: any) {

      alert(
        err.response?.data?.message ||
          "Delete failed"
      );
    }
  }

  function scrollToCreate() {
    document
      .getElementById("create-village-section")
      ?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
  }

  function clearFilters() {
    setSearch("");
    setMandalFilter("");
    setStatusFilter("ALL");
  }

  const activeVillages = villages.filter(
    (v) =>
      v.isActive === true ||
      v.isActive === undefined
  );

  const inactiveVillages = villages.filter(
    (v) => v.isActive === false
  );

  const filteredVillages = useMemo(() => {
    const query = search.trim().toLowerCase();

    return villages.filter((v) => {
      const villageName = String(
        v.name || ""
      ).toLowerCase();

      const mandalName = String(
        v.mandal?.name || ""
      ).toLowerCase();

      const matchesSearch =
        !query ||
        villageName.includes(query) ||
        mandalName.includes(query);

      const matchesMandal =
        !mandalFilter ||
        String(
          v.mandal?.id || v.mandalId || ""
        ) === mandalFilter;

      const isActive =
        v.isActive === undefined
          ? true
          : Boolean(v.isActive);

      const matchesStatus =
        statusFilter === "ALL" ||
        (statusFilter === "ACTIVE" && isActive) ||
        (statusFilter === "INACTIVE" && !isActive);

      return (
        matchesSearch &&
        matchesMandal &&
        matchesStatus
      );
    });
  }, [
    villages,
    search,
    mandalFilter,
    statusFilter,
  ]);

  return (
    <div className="villages-page">
      <style>{`
        * {
          box-sizing: border-box;
        }

        .villages-page {
          min-height: 100vh;
          background: #f5f7fb;
          padding: 0 0 40px;
          color: #172033;
        }

        .villages-header {
          background: linear-gradient(
            135deg,
            #0d47a1 0%,
            #1565c0 45%,
            #1976d2 100%
          );
          color: white;
          padding: 30px 40px;
          position: relative;
          overflow: hidden;
        }

        .villages-header::after {
          content: "";
          position: absolute;
          width: 260px;
          height: 260px;
          border-radius: 50%;
          background: rgba(255,255,255,0.07);
          right: -80px;
          top: -110px;
        }

        .header-inner {
          max-width: 1500px;
          margin: 0 auto;
          position: relative;
          z-index: 1;
        }

        .brand-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
        }

        .brand-title {
          margin: 0;
          font-size: 30px;
          font-weight: 800;
          letter-spacing: -0.5px;
        }

        .brand-subtitle {
          margin: 7px 0 0;
          color: rgba(255,255,255,0.82);
          font-size: 14px;
        }

        .header-add-btn {
          border: 1px solid rgba(255,255,255,0.28);
          background: rgba(255,255,255,0.14);
          color: white;
          padding: 12px 18px;
          border-radius: 10px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
          backdrop-filter: blur(8px);
        }

        .header-add-btn:hover {
          background: white;
          color: #1565c0;
          transform: translateY(-1px);
        }

        .content {
          max-width: 1500px;
          margin: 0 auto;
          padding: 28px 40px;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 18px;
          margin-bottom: 26px;
        }

        .stat-card {
          background: white;
          border: 1px solid #e6eaf0;
          border-radius: 16px;
          padding: 20px;
          box-shadow: 0 5px 18px rgba(20, 35, 60, 0.05);
          transition: all 0.2s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 9px 25px rgba(20, 35, 60, 0.08);
        }

        .stat-label {
          color: #687386;
          font-size: 13px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .stat-value {
          margin-top: 7px;
          font-size: 28px;
          font-weight: 800;
          color: #172033;
        }

        .section-card {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 18px;
          box-shadow: 0 7px 24px rgba(20, 35, 60, 0.05);
          margin-bottom: 24px;
          overflow: hidden;
        }

        .section-header {
          padding: 20px 22px;
          border-bottom: 1px solid #edf0f4;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
        }

        .section-title {
          margin: 0;
          font-size: 19px;
          font-weight: 800;
        }

        .section-description {
          margin: 5px 0 0;
          font-size: 13px;
          color: #7a8494;
        }

        .form-body {
          padding: 22px;
        }

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr auto;
          gap: 15px;
          align-items: end;
        }

        .field {
          display: flex;
          flex-direction: column;
          gap: 7px;
        }

        .field label {
          font-size: 12px;
          font-weight: 700;
          color: #4e596b;
        }

        .input,
        .select {
          width: 100%;
          height: 46px;
          border: 1px solid #dce2ea;
          border-radius: 10px;
          background: #fff;
          padding: 0 13px;
          font-size: 14px;
          color: #172033;
          outline: none;
          transition: all 0.2s ease;
        }

        .input:focus,
        .select:focus {
          border-color: #1976d2;
          box-shadow: 0 0 0 3px rgba(25,118,210,0.10);
        }

        .create-btn {
          height: 46px;
          padding: 0 20px;
          border: none;
          border-radius: 10px;
          background: #1565c0;
          color: white;
          font-weight: 800;
          cursor: pointer;
          white-space: nowrap;
          transition: all 0.2s ease;
        }

        .create-btn:hover:not(:disabled) {
          background: #0d47a1;
          transform: translateY(-1px);
        }

        .create-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .filters {
          padding: 20px 22px;
          background: #fbfcfe;
          border-bottom: 1px solid #edf0f4;
        }

        .filter-grid {
          display: grid;
          grid-template-columns: 1.5fr 1fr 1fr auto;
          gap: 12px;
          align-items: end;
        }

        .clear-btn {
          height: 46px;
          padding: 0 17px;
          border: 1px solid #d9e0e9;
          border-radius: 10px;
          background: white;
          color: #455166;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .clear-btn:hover {
          background: #f1f4f8;
        }

        .table-wrap {
          width: 100%;
          overflow-x: auto;
        }

        .villages-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          min-width: 760px;
        }

        .villages-table th {
          background: #f8fafc;
          color: #667085;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          font-weight: 800;
          text-align: left;
          padding: 15px 20px;
          border-bottom: 1px solid #e7ebf0;
          white-space: nowrap;
        }

        .villages-table td {
          padding: 17px 20px;
          border-bottom: 1px solid #edf0f4;
          font-size: 14px;
          vertical-align: middle;
        }

        .villages-table tbody tr {
          transition: background 0.18s ease;
        }

        .villages-table tbody tr:hover {
          background: #f8fbff;
        }

        .village-name {
          font-weight: 800;
          color: #172033;
        }

        .mandal-name {
          color: #596579;
          font-weight: 600;
        }

        .id-text {
          color: #9aa3b1;
          font-size: 11px;
          margin-top: 4px;
          word-break: break-all;
        }

        .badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 10px;
          border-radius: 999px;
          font-size: 11px;
          font-weight: 800;
        }

        .badge-active {
          color: #137333;
          background: #e8f5e9;
        }

        .badge-inactive {
          color: #b42318;
          background: #fdecec;
        }

        .status-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: currentColor;
        }

        .delete-btn {
          border: 1px solid #f0caca;
          background: #fff7f7;
          color: #c62828;
          border-radius: 8px;
          padding: 8px 12px;
          font-size: 12px;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .delete-btn:hover {
          background: #fdeaea;
          border-color: #e9aaaa;
        }

        .empty-state,
        .loading-state {
          padding: 55px 20px;
          text-align: center;
          color: #7b8493;
        }

        .empty-icon {
          font-size: 34px;
          margin-bottom: 8px;
        }

        .mobile-list {
          display: none;
        }

        .mobile-card {
          border: 1px solid #e7ebf0;
          border-radius: 14px;
          padding: 17px;
          background: white;
          margin-bottom: 12px;
        }

        .mobile-card:last-child {
          margin-bottom: 0;
        }

        .mobile-top {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          align-items: flex-start;
        }

        .mobile-name {
          font-size: 16px;
          font-weight: 800;
          color: #172033;
        }

        .mobile-row {
          display: flex;
          justify-content: space-between;
          gap: 15px;
          padding: 9px 0;
          border-bottom: 1px solid #f0f2f5;
          font-size: 13px;
        }

        .mobile-row:last-of-type {
          border-bottom: none;
        }

        .mobile-label {
          color: #8992a0;
          font-weight: 700;
        }

        .mobile-value {
          color: #344054;
          font-weight: 700;
          text-align: right;
        }

        .mobile-actions {
          margin-top: 13px;
          display: flex;
          justify-content: flex-end;
        }

        @media (max-width: 900px) {
          .villages-header {
            padding: 25px 22px;
          }

          .content {
            padding: 22px;
          }

          .stats-grid {
            grid-template-columns: repeat(3, 1fr);
          }

          .form-grid {
            grid-template-columns: 1fr 1fr;
          }

          .create-btn {
            width: 100%;
          }

          .filter-grid {
            grid-template-columns: 1fr 1fr;
          }

          .clear-btn {
            width: 100%;
          }
        }

        @media (max-width: 680px) {
          .villages-header {
            padding: 22px 16px;
          }

          .content {
            padding: 18px 14px;
          }

          .brand-row {
            align-items: flex-start;
          }

          .brand-title {
            font-size: 24px;
          }

          .brand-subtitle {
            font-size: 12px;
          }

          .header-add-btn {
            padding: 10px 12px;
            font-size: 12px;
          }

          .stats-grid {
            grid-template-columns: 1fr;
            gap: 10px;
          }

          .stat-card {
            padding: 15px;
          }

          .stat-value {
            font-size: 24px;
          }

          .section-header {
            padding: 17px;
          }

          .form-body {
            padding: 17px;
          }

          .form-grid {
            grid-template-columns: 1fr;
          }

          .filters {
            padding: 17px;
          }

          .filter-grid {
            grid-template-columns: 1fr;
          }

          .table-wrap {
            display: none;
          }

          .mobile-list {
            display: block;
            padding: 15px;
          }

          .section-card {
            border-radius: 15px;
          }
        }
      `}</style>

      {/* Premium Header */}
      <header className="villages-header">
        <div className="header-inner">
          <div className="brand-row">
            <div>
              <h1 className="brand-title">
                Narsampet360
              </h1>

              <p className="brand-subtitle">
                Villages Management
              </p>
            </div>

            <button
              className="header-add-btn"
              onClick={scrollToCreate}
            >
              + Add Village
            </button>
          </div>
        </div>
      </header>

      <main className="content">
        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-label">
              Total Villages
            </div>

            <div className="stat-value">
              {villages.length}
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">
              Active Villages
            </div>

            <div className="stat-value">
              {activeVillages.length}
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">
              Inactive Villages
            </div>

            <div className="stat-value">
              {inactiveVillages.length}
            </div>
          </div>
        </div>

        {/* Create Village */}
        <section
          id="create-village-section"
          className="section-card"
        >
          <div className="section-header">
            <div>
              <h2 className="section-title">
                Create Village
              </h2>

              <p className="section-description">
                Add a new village and assign it
                to a mandal.
              </p>
            </div>
          </div>

          <div className="form-body">
            <div className="form-grid">
              <div className="field">
                <label>
                  Village Name
                </label>

                <input
                  className="input"
                  placeholder="Enter village name"
                  value={name}
                  onChange={(e) =>
                    setName(e.target.value)
                  }
                />
              </div>

              <div className="field">
                <label>
                  Mandal
                </label>

                <select
                  className="select"
                  value={mandalId}
                  onChange={(e) =>
                    setMandalId(e.target.value)
                  }
                  disabled={loadingMandals}
                >
                  <option value="">
                    {loadingMandals
                      ? "Loading Mandals..."
                      : "Select Mandal"}
                  </option>

                  {mandals.map((m) => (
                    <option
                      key={m.id}
                      value={m.id}
                    >
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                className="create-btn"
                onClick={createVillage}
                disabled={creating}
              >
                {creating
                  ? "Creating..."
                  : "Create Village"}
              </button>
            </div>
          </div>
        </section>

        {/* Villages List */}
        <section className="section-card">
          <div className="section-header">
            <div>
              <h2 className="section-title">
                Villages
              </h2>

              <p className="section-description">
                Manage villages available in the
                system.
              </p>
            </div>
          </div>

          {/* Filters */}
          <div className="filters">
            <div className="filter-grid">
              <div className="field">
                <label>
                  Search
                </label>

                <input
                  className="input"
                  placeholder="Search village or mandal..."
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                />
              </div>

              <div className="field">
                <label>
                  Mandal
                </label>

                <select
                  className="select"
                  value={mandalFilter}
                  onChange={(e) =>
                    setMandalFilter(
                      e.target.value
                    )
                  }
                >
                  <option value="">
                    All Mandals
                  </option>

                  {mandals.map((m) => (
                    <option
                      key={m.id}
                      value={m.id}
                    >
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="field">
                <label>
                  Status
                </label>

                <select
                  className="select"
                  value={statusFilter}
                  onChange={(e) =>
                    setStatusFilter(
                      e.target.value
                    )
                  }
                >
                  <option value="ALL">
                    All Status
                  </option>

                  <option value="ACTIVE">
                    Active
                  </option>

                  <option value="INACTIVE">
                    Inactive
                  </option>
                </select>
              </div>

              <button
                className="clear-btn"
                onClick={clearFilters}
              >
                Clear Filters
              </button>
            </div>
          </div>

          {loading ? (
            <div className="loading-state">
              <h3>
                Loading villages...
              </h3>

              <p>
                Please wait while villages are
                being loaded.
              </p>
            </div>
          ) : filteredVillages.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">
                🏘️
              </div>

              <h3>
                No villages found
              </h3>

              <p>
                Try changing your search or
                filters.
              </p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="table-wrap">
                <table className="villages-table">
                  <thead>
                    <tr>
                      <th>
                        Village
                      </th>

                      <th>
                        Mandal
                      </th>

                      <th>
                        Status
                      </th>

                      <th>
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredVillages.map(
                      (v) => {
                        const isActive =
                          v.isActive ===
                          undefined
                            ? true
                            : Boolean(
                                v.isActive
                              );

                        return (
                          <tr
                            key={v.id}
                          >
                            <td>
                              <div className="village-name">
                                {v.name}
                              </div>

                              <div className="id-text">
                                ID: {v.id}
                              </div>
                            </td>

                            <td>
                              <span className="mandal-name">
                                {v.mandal
                                  ?.name ||
                                  "-"}
                              </span>
                            </td>

                            <td>
                              <span
                                className={`badge ${
                                  isActive
                                    ? "badge-active"
                                    : "badge-inactive"
                                }`}
                              >
                                <span className="status-dot" />

                                {isActive
                                  ? "Active"
                                  : "Inactive"}
                              </span>
                            </td>

                            <td>
                              <button
                                className="delete-btn"
                                onClick={() =>
                                  deleteVillage(
                                    v.id
                                  )
                                }
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        );
                      }
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="mobile-list">
                {filteredVillages.map(
                  (v) => {
                    const isActive =
                      v.isActive ===
                      undefined
                        ? true
                        : Boolean(
                            v.isActive
                          );

                    return (
                      <div
                        className="mobile-card"
                        key={v.id}
                      >
                        <div className="mobile-top">
                          <div>
                            <div className="mobile-name">
                              {v.name}
                            </div>

                            <div className="id-text">
                              ID: {v.id}
                            </div>
                          </div>

                          <span
                            className={`badge ${
                              isActive
                                ? "badge-active"
                                : "badge-inactive"
                            }`}
                          >
                            <span className="status-dot" />

                            {isActive
                              ? "Active"
                              : "Inactive"}
                          </span>
                        </div>

                        <div className="mobile-row">
                          <span className="mobile-label">
                            Mandal
                          </span>

                          <span className="mobile-value">
                            {v.mandal
                              ?.name ||
                              "-"}
                          </span>
                        </div>

                        <div className="mobile-actions">
                          <button
                            className="delete-btn"
                            onClick={() =>
                              deleteVillage(
                                v.id
                              )
                            }
                          >
                            Delete Village
                          </button>
                        </div>
                      </div>
                    );
                  }
                )}
              </div>
            </>
          )}
        </section>
      </main>
    </div>
  );
}