import { useEffect, useMemo, useState } from "react";
import client from "../api/client";

type Summary = {
  total?: number;
  pending?: number;
  assigned?: number;
  inProgress?: number;
  resolved?: number;
  rejected?: number;
  closed?: number;
};

type DepartmentReport = {
  department?: string;
  total?: number;
};

type MonthlyReport = {
  month?: string;
  total?: number;
};

export default function Reports() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [department, setDepartment] = useState<DepartmentReport[]>([]);
  const [monthly, setMonthly] = useState<MonthlyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  async function load(isRefresh = false) {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const [summaryRes, deptRes, monthlyRes] =
        await Promise.all([
          client.get("/reports/summary"),
          client.get("/reports/department"),
          client.get("/reports/monthly"),
        ]);

      const summaryData =
        summaryRes.data?.data ?? summaryRes.data ?? {};

      const departmentData = Array.isArray(deptRes.data)
        ? deptRes.data
        : Array.isArray(deptRes.data?.data)
        ? deptRes.data.data
        : [];

      const monthlyData = Array.isArray(monthlyRes.data)
        ? monthlyRes.data
        : Array.isArray(monthlyRes.data?.data)
        ? monthlyRes.data.data
        : [];

      setSummary(summaryData);
      setDepartment(departmentData);
      setMonthly(monthlyData);
    } catch (err: any) {

      setError(
        err.response?.data?.message ||
          "Unable to load reports. Please try again."
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function downloadReport(format: "csv" | "pdf") {
    try {
      const response = await client.get(
        `/reports/export/${format}`,
        { responseType: "blob" },
      );

      const headerContentType = response.headers["content-type"];
      const contentType =
        typeof headerContentType === "string"
          ? headerContentType
          : format === "csv"
          ? "text/csv"
          : "application/pdf";
      const blob = new Blob([response.data], { type: contentType });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `grievance-report.${format}`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          `Unable to download ${format.toUpperCase()} report. Please try again.`,
      );
    }
  }

  function downloadCSV() {
    void downloadReport("csv");
  }

  function downloadPDF() {
    void downloadReport("pdf");
  }

  const total = Number(summary?.total || 0);
  const pending = Number(summary?.pending || 0);
  const assigned = Number(summary?.assigned || 0);
  const inProgress = Number(summary?.inProgress || 0);
  const resolved = Number(summary?.resolved || 0);
  const rejected = Number(summary?.rejected || 0);
  const closed = Number(summary?.closed || 0);

  const activeCases = pending + assigned + inProgress;
  const completedCases = resolved + closed;

  const resolutionRate = total
    ? Math.round((resolved / total) * 100)
    : 0;

  const closureRate = total
    ? Math.round((completedCases / total) * 100)
    : 0;

  const totalDepartmentGrievances = useMemo(() => {
    return department.reduce(
      (sum, item) => sum + Number(item.total || 0),
      0
    );
  }, [department]);

  const sortedDepartments = useMemo(() => {
    return [...department].sort(
      (a, b) =>
        Number(b.total || 0) - Number(a.total || 0)
    );
  }, [department]);

  const highestDepartment = useMemo(() => {
    if (!department.length) {
      return null;
    }

    return department.reduce(
      (highest, current) =>
        Number(current.total || 0) >
        Number(highest?.total || 0)
          ? current
          : highest,
      department[0]
    );
  }, [department]);

  const highestMonthly = useMemo(() => {
    if (!monthly.length) {
      return null;
    }

    return monthly.reduce(
      (highest, current) =>
        Number(current.total || 0) >
        Number(highest?.total || 0)
          ? current
          : highest,
      monthly[0]
    );
  }, [monthly]);

  const monthlyMaximum = useMemo(() => {
    return Math.max(
      ...monthly.map((item) =>
        Number(item.total || 0)
      ),
      1
    );
  }, [monthly]);

  function getPercentage(
    value: number,
    totalValue: number
  ) {
    if (!totalValue) {
      return 0;
    }

    return Math.round(
      (value / totalValue) * 100
    );
  }

  return (
    <div className="reports-page">
      <style>{`
        * {
          box-sizing: border-box;
        }

        .reports-page {
          min-height: 100vh;
          background:
            radial-gradient(
              circle at top right,
              rgba(25,118,210,0.06),
              transparent 30%
            ),
            #f5f7fb;
          color: #172033;
          padding-bottom: 50px;
        }

        .reports-header {
          background:
            linear-gradient(
              135deg,
              #0b3d91 0%,
              #1565c0 48%,
              #1976d2 100%
            );
          color: white;
          padding: 30px 40px;
          position: relative;
          overflow: hidden;
        }

        .reports-header::before {
          content: "";
          position: absolute;
          width: 360px;
          height: 360px;
          border-radius: 50%;
          background: rgba(255,255,255,0.055);
          right: -120px;
          top: -180px;
        }

        .reports-header::after {
          content: "";
          position: absolute;
          width: 180px;
          height: 180px;
          border-radius: 50%;
          background: rgba(255,255,255,0.035);
          left: 38%;
          bottom: -130px;
        }

        .header-inner {
          max-width: 1500px;
          margin: 0 auto;
          position: relative;
          z-index: 2;
        }

        .header-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
        }

        .brand-title {
          margin: 0;
          font-size: 31px;
          font-weight: 850;
          letter-spacing: -0.8px;
        }

        .brand-subtitle {
          margin: 7px 0 0;
          color: rgba(255,255,255,0.82);
          font-size: 14px;
          font-weight: 500;
        }

        .header-description {
          margin: 13px 0 0;
          max-width: 620px;
          color: rgba(255,255,255,0.68);
          font-size: 12px;
          line-height: 1.6;
        }

        .refresh-btn {
          border: 1px solid rgba(255,255,255,0.25);
          background: rgba(255,255,255,0.13);
          color: white;
          padding: 11px 17px;
          border-radius: 11px;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.2s ease;
          backdrop-filter: blur(8px);
          white-space: nowrap;
        }

        .refresh-btn:hover {
          background: white;
          color: #1565c0;
          transform: translateY(-1px);
        }

        .refresh-btn:disabled {
          opacity: 0.7;
          cursor: wait;
          transform: none;
        }

        .content {
          max-width: 1500px;
          margin: 0 auto;
          padding: 28px 40px;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 13px;
          margin-bottom: 22px;
        }

        .summary-card {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 16px;
          padding: 18px;
          min-height: 132px;
          box-shadow:
            0 5px 18px rgba(20,35,60,0.045);
          transition: all 0.2s ease;
          position: relative;
          overflow: hidden;
        }

        .summary-card::after {
          content: "";
          position: absolute;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          right: -25px;
          bottom: -25px;
          background: #f5f8fc;
        }

        .summary-card:hover {
          transform: translateY(-3px);
          box-shadow:
            0 10px 27px rgba(20,35,60,0.09);
        }

        .summary-label {
          color: #697586;
          font-size: 10px;
          font-weight: 850;
          text-transform: uppercase;
          letter-spacing: 0.55px;
          position: relative;
          z-index: 1;
        }

        .summary-value {
          margin-top: 10px;
          font-size: 28px;
          line-height: 1;
          font-weight: 850;
          color: #172033;
          position: relative;
          z-index: 1;
        }

        .summary-description {
          margin-top: 9px;
          color: #9aa3b1;
          font-size: 10px;
          position: relative;
          z-index: 1;
        }

        .summary-card.total {
          border-top: 3px solid #1565c0;
        }

        .summary-card.pending {
          border-top: 3px solid #f59e0b;
        }

        .summary-card.assigned {
          border-top: 3px solid #7c3aed;
        }

        .summary-card.progress {
          border-top: 3px solid #2563eb;
        }

        .summary-card.resolved {
          border-top: 3px solid #16a34a;
        }

        .summary-card.rejected {
          border-top: 3px solid #dc2626;
        }

        .summary-card.closed {
          border-top: 3px solid #475569;
        }

        .analytics-grid {
          display: grid;
          grid-template-columns: 1.15fr 0.85fr;
          gap: 18px;
          margin-bottom: 22px;
        }

        .analytics-card {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 18px;
          padding: 21px;
          box-shadow:
            0 7px 24px rgba(20,35,60,0.045);
        }

        .analytics-head {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 15px;
          margin-bottom: 20px;
        }

        .analytics-title {
          margin: 0;
          font-size: 16px;
          font-weight: 850;
        }

        .analytics-subtitle {
          margin: 5px 0 0;
          color: #8a94a3;
          font-size: 11px;
        }

        .analytics-badge {
          padding: 7px 10px;
          border-radius: 999px;
          background: #eef5ff;
          color: #1565c0;
          font-size: 10px;
          font-weight: 850;
          white-space: nowrap;
        }

        .rate-row {
          display: flex;
          align-items: center;
          gap: 15px;
          padding: 13px 0;
          border-bottom: 1px solid #f0f2f5;
        }

        .rate-row:last-child {
          border-bottom: none;
          padding-bottom: 0;
        }

        .rate-info {
          width: 125px;
          flex-shrink: 0;
        }

        .rate-name {
          font-size: 12px;
          font-weight: 800;
          color: #344054;
        }

        .rate-count {
          margin-top: 3px;
          font-size: 10px;
          color: #98a2b3;
        }

        .rate-track {
          flex: 1;
          height: 9px;
          background: #edf1f5;
          border-radius: 999px;
          overflow: hidden;
        }

        .rate-bar {
          height: 100%;
          border-radius: 999px;
          transition: width 0.5s ease;
        }

        .rate-bar.resolved {
          background: #16a34a;
        }

        .rate-bar.active {
          background: #2563eb;
        }

        .rate-bar.rejected {
          background: #dc2626;
        }

        .rate-percent {
          width: 43px;
          text-align: right;
          font-size: 11px;
          font-weight: 850;
          color: #344054;
        }

        .metric-boxes {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .metric-box {
          border: 1px solid #e8edf3;
          border-radius: 13px;
          padding: 15px;
          background: #fbfcfe;
        }

        .metric-box-label {
          color: #8a94a3;
          font-size: 10px;
          font-weight: 800;
          text-transform: uppercase;
        }

        .metric-box-value {
          margin-top: 6px;
          font-size: 25px;
          font-weight: 850;
          color: #172033;
        }

        .metric-box-description {
          margin-top: 3px;
          color: #98a2b3;
          font-size: 10px;
        }

        .section-card {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 18px;
          box-shadow:
            0 7px 24px rgba(20,35,60,0.045);
          overflow: hidden;
          margin-bottom: 22px;
        }

        .section-header {
          padding: 20px 22px;
          border-bottom: 1px solid #edf0f4;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
        }

        .section-title {
          margin: 0;
          font-size: 18px;
          font-weight: 850;
        }

        .section-description {
          margin: 5px 0 0;
          color: #7a8494;
          font-size: 12px;
        }

        .section-badge {
          display: inline-flex;
          align-items: center;
          padding: 7px 11px;
          border-radius: 999px;
          background: #eef5ff;
          color: #1565c0;
          font-size: 10px;
          font-weight: 850;
          white-space: nowrap;
        }

        .table-wrap {
          width: 100%;
          overflow-x: auto;
        }

        .reports-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          min-width: 700px;
        }

        .reports-table th {
          background: #f8fafc;
          color: #667085;
          font-size: 10px;
          text-transform: uppercase;
          letter-spacing: 0.45px;
          font-weight: 850;
          text-align: left;
          padding: 14px 20px;
          border-bottom: 1px solid #e7ebf0;
        }

        .reports-table td {
          padding: 16px 20px;
          border-bottom: 1px solid #edf0f4;
          font-size: 13px;
          vertical-align: middle;
        }

        .reports-table tbody tr:last-child td {
          border-bottom: none;
        }

        .reports-table tbody tr {
          transition: background 0.18s ease;
        }

        .reports-table tbody tr:hover {
          background: #f8fbff;
        }

        .rank-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          height: 28px;
          border-radius: 9px;
          background: #f1f5f9;
          color: #64748b;
          font-size: 11px;
          font-weight: 850;
        }

        .rank-badge.first {
          background: #fff4d8;
          color: #a16207;
        }

        .department-name {
          font-weight: 800;
          color: #172033;
        }

        .number-cell {
          font-weight: 850;
          color: #344054;
        }

        .progress-wrap {
          width: 100%;
          min-width: 190px;
        }

        .progress-track {
          height: 8px;
          background: #edf1f5;
          border-radius: 999px;
          overflow: hidden;
        }

        .progress-bar {
          height: 100%;
          background: linear-gradient(
            90deg,
            #1565c0,
            #42a5f5
          );
          border-radius: 999px;
          transition: width 0.4s ease;
        }

        .progress-text {
          margin-top: 5px;
          font-size: 10px;
          color: #8a94a3;
          font-weight: 750;
        }

        .mobile-list {
          display: none;
        }

        .mobile-report-card {
          background: #fbfcfe;
          border: 1px solid #e7ebf0;
          border-radius: 14px;
          padding: 16px;
          margin-bottom: 10px;
        }

        .mobile-report-card:last-child {
          margin-bottom: 0;
        }

        .mobile-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        .mobile-name {
          font-weight: 800;
          color: #172033;
          font-size: 14px;
        }

        .mobile-total {
          font-weight: 850;
          color: #1565c0;
        }

        .mobile-progress {
          margin-top: 13px;
        }

        .mobile-row {
          display: flex;
          justify-content: space-between;
          padding-top: 11px;
          margin-top: 11px;
          border-top: 1px solid #edf0f4;
          font-size: 12px;
        }

        .mobile-label {
          color: #8992a0;
          font-weight: 700;
        }

        .mobile-value {
          color: #344054;
          font-weight: 850;
        }

        .trend-list {
          display: grid;
          grid-template-columns:
            repeat(auto-fit, minmax(155px, 1fr));
          gap: 12px;
          padding: 20px;
        }

        .month-card {
          border: 1px solid #e7ebf0;
          border-radius: 14px;
          padding: 15px;
          background: #fbfcfe;
          transition: all 0.2s ease;
          position: relative;
          overflow: hidden;
        }

        .month-card:hover {
          transform: translateY(-2px);
          background: white;
          box-shadow:
            0 7px 18px rgba(20,35,60,0.06);
        }

        .month-name {
          font-size: 10px;
          color: #7a8494;
          font-weight: 850;
          text-transform: uppercase;
          letter-spacing: 0.4px;
        }

        .month-total {
          font-size: 25px;
          font-weight: 850;
          margin-top: 7px;
          color: #172033;
        }

        .month-label {
          font-size: 10px;
          color: #9aa3b1;
          margin-top: 3px;
        }

        .month-bar-area {
          height: 75px;
          display: flex;
          align-items: flex-end;
          margin-top: 13px;
        }

        .month-bar-track {
          width: 100%;
          height: 100%;
          background: #f0f3f7;
          border-radius: 8px;
          display: flex;
          align-items: flex-end;
          overflow: hidden;
        }

        .month-bar {
          width: 100%;
          min-height: 5px;
          background: linear-gradient(
            180deg,
            #42a5f5,
            #1565c0
          );
          border-radius: 7px;
          transition: height 0.4s ease;
        }

        .peak-tag {
          display: inline-block;
          margin-top: 9px;
          padding: 4px 7px;
          border-radius: 6px;
          background: #fff4d8;
          color: #a16207;
          font-size: 9px;
          font-weight: 850;
        }

        .export-section {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          padding: 21px 22px;
        }

        .export-title {
          margin: 0;
          font-size: 16px;
          font-weight: 850;
        }

        .export-description {
          margin: 5px 0 0;
          color: #7a8494;
          font-size: 11px;
        }

        .export-buttons {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .export-btn {
          min-width: 130px;
          height: 44px;
          padding: 0 16px;
          border-radius: 10px;
          font-weight: 850;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .csv-btn {
          border: 1px solid #c9dced;
          background: #f3f8fd;
          color: #1565c0;
        }

        .csv-btn:hover {
          background: #e6f1fc;
          transform: translateY(-1px);
        }

        .pdf-btn {
          border: 1px solid #efcccc;
          background: #fff6f6;
          color: #c62828;
        }

        .pdf-btn:hover {
          background: #fdeaea;
          transform: translateY(-1px);
        }

        .loading-state {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 18px;
          padding: 70px 20px;
          text-align: center;
          box-shadow:
            0 7px 24px rgba(20,35,60,0.05);
          color: #7b8493;
        }

        .loading-icon {
          width: 38px;
          height: 38px;
          border: 4px solid #e8eef6;
          border-top-color: #1565c0;
          border-radius: 50%;
          margin: 0 auto 15px;
          animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        .error-state {
          background: white;
          border: 1px solid #f1d4d4;
          border-radius: 18px;
          padding: 55px 20px;
          text-align: center;
          box-shadow:
            0 7px 24px rgba(20,35,60,0.05);
        }

        .error-icon {
          font-size: 34px;
          margin-bottom: 8px;
        }

        .error-state h3 {
          margin: 0;
          color: #b42318;
          font-size: 17px;
        }

        .error-state p {
          color: #7b8493;
          font-size: 12px;
          margin: 7px 0 18px;
        }

        .retry-btn {
          border: none;
          background: #1565c0;
          color: white;
          padding: 10px 17px;
          border-radius: 9px;
          font-weight: 800;
          cursor: pointer;
        }

        .empty-state {
          padding: 45px 20px;
          text-align: center;
          color: #7b8493;
        }

        .empty-icon {
          font-size: 34px;
          margin-bottom: 8px;
        }

        .empty-state h3 {
          margin: 0;
          font-size: 16px;
          color: #344054;
        }

        .empty-state p {
          margin: 6px 0 0;
          font-size: 12px;
        }

        @media (max-width: 1250px) {
          .summary-grid {
            grid-template-columns: repeat(4, 1fr);
          }

          .analytics-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 1050px) {
          .summary-grid {
            grid-template-columns: repeat(3, 1fr);
          }

          .content {
            padding: 24px;
          }

          .reports-header {
            padding: 26px 24px;
          }
        }

        @media (max-width: 760px) {
          .reports-header {
            padding: 22px 16px;
          }

          .content {
            padding: 18px 14px;
          }

          .header-row {
            align-items: flex-start;
          }

          .brand-title {
            font-size: 24px;
          }

          .brand-subtitle {
            font-size: 12px;
          }

          .header-description {
            display: none;
          }

          .summary-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
          }

          .summary-card {
            padding: 15px;
            min-height: 115px;
          }

          .summary-value {
            font-size: 24px;
          }

          .summary-description {
            font-size: 9px;
          }

          .analytics-card {
            padding: 17px;
          }

          .metric-boxes {
            gap: 9px;
          }

          .section-card {
            border-radius: 15px;
          }

          .section-header {
            padding: 17px;
          }

          .table-wrap {
            display: none;
          }

          .mobile-list {
            display: block;
            padding: 15px;
          }

          .trend-list {
            grid-template-columns: repeat(2, 1fr);
            padding: 15px;
          }

          .export-section {
            flex-direction: column;
            align-items: stretch;
            padding: 18px;
          }

          .export-buttons {
            width: 100%;
          }

          .export-btn {
            flex: 1;
          }
        }

        @media (max-width: 480px) {
          .summary-grid {
            grid-template-columns: 1fr;
          }

          .trend-list {
            grid-template-columns: 1fr;
          }

          .rate-info {
            width: 100px;
          }

          .rate-percent {
            width: 35px;
          }

          .refresh-btn {
            padding: 9px 11px;
            font-size: 11px;
          }

          .export-buttons {
            flex-direction: column;
          }

          .export-btn {
            width: 100%;
          }
        }
      `}</style>

      {/* Header */}
      <header className="reports-header">
        <div className="header-inner">
          <div className="header-row">
            <div>
              <h1 className="brand-title">
                Narsampet360
              </h1>

              <p className="brand-subtitle">
                Reports & Analytics
              </p>

              <p className="header-description">
                Monitor grievance volume, department
                performance, resolution progress and
                monthly activity from one place.
              </p>
            </div>

            <button
              className="refresh-btn"
              onClick={() => load(true)}
              disabled={refreshing}
            >
              {refreshing
                ? "↻ Refreshing..."
                : "↻ Refresh"}
            </button>
          </div>
        </div>
      </header>

      <main className="content">
        {/* Loading */}
        {loading && !summary ? (
          <div className="loading-state">
            <div className="loading-icon" />

            <h3>Loading reports...</h3>

            <p>
              Please wait while analytics are
              being loaded.
            </p>
          </div>
        ) : error && !summary ? (
          /* Error */
          <div className="error-state">
            <div className="error-icon">
              ⚠️
            </div>

            <h3>
              Unable to load reports
            </h3>

            <p>{error}</p>

            <button
              className="retry-btn"
              onClick={() => load()}
            >
              Try Again
            </button>
          </div>
        ) : (
          <>
            {/* Summary */}
            <div className="summary-grid">
              <div className="summary-card total">
                <div className="summary-label">
                  Total
                </div>

                <div className="summary-value">
                  {total}
                </div>

                <div className="summary-description">
                  All grievances
                </div>
              </div>

              <div className="summary-card pending">
                <div className="summary-label">
                  Pending
                </div>

                <div className="summary-value">
                  {pending}
                </div>

                <div className="summary-description">
                  Awaiting action
                </div>
              </div>

              <div className="summary-card assigned">
                <div className="summary-label">
                  Assigned
                </div>

                <div className="summary-value">
                  {assigned}
                </div>

                <div className="summary-description">
                  Assigned cases
                </div>
              </div>

              <div className="summary-card progress">
                <div className="summary-label">
                  In Progress
                </div>

                <div className="summary-value">
                  {inProgress}
                </div>

                <div className="summary-description">
                  Currently working
                </div>
              </div>

              <div className="summary-card resolved">
                <div className="summary-label">
                  Resolved
                </div>

                <div className="summary-value">
                  {resolved}
                </div>

                <div className="summary-description">
                  Successfully resolved
                </div>
              </div>

              <div className="summary-card rejected">
                <div className="summary-label">
                  Rejected
                </div>

                <div className="summary-value">
                  {rejected}
                </div>

                <div className="summary-description">
                  Rejected cases
                </div>
              </div>

              <div className="summary-card closed">
                <div className="summary-label">
                  Closed
                </div>

                <div className="summary-value">
                  {closed}
                </div>

                <div className="summary-description">
                  Completed cases
                </div>
              </div>
            </div>

            {/* Analytics Overview */}
            <div className="analytics-grid">
              <div className="analytics-card">
                <div className="analytics-head">
                  <div>
                    <h2 className="analytics-title">
                      Status Overview
                    </h2>

                    <p className="analytics-subtitle">
                      Current distribution of all
                      grievances.
                    </p>
                  </div>

                  <span className="analytics-badge">
                    {total} Total
                  </span>
                </div>

                <div className="rate-row">
                  <div className="rate-info">
                    <div className="rate-name">
                      Resolved
                    </div>

                    <div className="rate-count">
                      {resolved} cases
                    </div>
                  </div>

                  <div className="rate-track">
                    <div
                      className="rate-bar resolved"
                      style={{
                        width: `${getPercentage(
                          resolved,
                          total
                        )}%`,
                      }}
                    />
                  </div>

                  <div className="rate-percent">
                    {getPercentage(
                      resolved,
                      total
                    )}
                    %
                  </div>
                </div>

                <div className="rate-row">
                  <div className="rate-info">
                    <div className="rate-name">
                      Active
                    </div>

                    <div className="rate-count">
                      {activeCases} cases
                    </div>
                  </div>

                  <div className="rate-track">
                    <div
                      className="rate-bar active"
                      style={{
                        width: `${getPercentage(
                          activeCases,
                          total
                        )}%`,
                      }}
                    />
                  </div>

                  <div className="rate-percent">
                    {getPercentage(
                      activeCases,
                      total
                    )}
                    %
                  </div>
                </div>

                <div className="rate-row">
                  <div className="rate-info">
                    <div className="rate-name">
                      Rejected
                    </div>

                    <div className="rate-count">
                      {rejected} cases
                    </div>
                  </div>

                  <div className="rate-track">
                    <div
                      className="rate-bar rejected"
                      style={{
                        width: `${getPercentage(
                          rejected,
                          total
                        )}%`,
                      }}
                    />
                  </div>

                  <div className="rate-percent">
                    {getPercentage(
                      rejected,
                      total
                    )}
                    %
                  </div>
                </div>
              </div>

              <div className="analytics-card">
                <div className="analytics-head">
                  <div>
                    <h2 className="analytics-title">
                      Performance Snapshot
                    </h2>

                    <p className="analytics-subtitle">
                      Key operational indicators.
                    </p>
                  </div>
                </div>

                <div className="metric-boxes">
                  <div className="metric-box">
                    <div className="metric-box-label">
                      Resolution Rate
                    </div>

                    <div className="metric-box-value">
                      {resolutionRate}%
                    </div>

                    <div className="metric-box-description">
                      Resolved / total
                    </div>
                  </div>

                  <div className="metric-box">
                    <div className="metric-box-label">
                      Completion Rate
                    </div>

                    <div className="metric-box-value">
                      {closureRate}%
                    </div>

                    <div className="metric-box-description">
                      Resolved + closed
                    </div>
                  </div>

                  <div className="metric-box">
                    <div className="metric-box-label">
                      Active Workload
                    </div>

                    <div className="metric-box-value">
                      {activeCases}
                    </div>

                    <div className="metric-box-description">
                      Needs attention
                    </div>
                  </div>

                  <div className="metric-box">
                    <div className="metric-box-label">
                      Departments
                    </div>

                    <div className="metric-box-value">
                      {department.length}
                    </div>

                    <div className="metric-box-description">
                      Reporting departments
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Department Wise */}
            <section className="section-card">
              <div className="section-header">
                <div>
                  <h2 className="section-title">
                    Department Wise Report
                  </h2>

                  <p className="section-description">
                    Grievance distribution and
                    workload across departments.
                  </p>
                </div>

                <span className="section-badge">
                  {department.length} Departments
                </span>
              </div>

              {department.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">
                    📊
                  </div>

                  <h3>
                    No department data
                  </h3>

                  <p>
                    Department report data is
                    currently unavailable.
                  </p>
                </div>
              ) : (
                <>
                  {/* Desktop */}
                  <div className="table-wrap">
                    <table className="reports-table">
                      <thead>
                        <tr>
                          <th>Rank</th>
                          <th>Department</th>
                          <th>Total</th>
                          <th>Distribution</th>
                        </tr>
                      </thead>

                      <tbody>
                        {sortedDepartments.map(
                          (d, index) => {
                            const value = Number(
                              d.total || 0
                            );

                            const percentage =
                              getPercentage(
                                value,
                                totalDepartmentGrievances
                              );

                            return (
                              <tr
                                key={
                                  d.department ||
                                  index
                                }
                              >
                                <td>
                                  <span
                                    className={`rank-badge ${
                                      index === 0
                                        ? "first"
                                        : ""
                                    }`}
                                  >
                                    {index + 1}
                                  </span>
                                </td>

                                <td>
                                  <span className="department-name">
                                    {d.department ||
                                      "-"}
                                  </span>
                                </td>

                                <td>
                                  <span className="number-cell">
                                    {value}
                                  </span>
                                </td>

                                <td>
                                  <div className="progress-wrap">
                                    <div className="progress-track">
                                      <div
                                        className="progress-bar"
                                        style={{
                                          width: `${percentage}%`,
                                        }}
                                      />
                                    </div>

                                    <div className="progress-text">
                                      {percentage}% of
                                      department
                                      workload
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            );
                          }
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile */}
                  <div className="mobile-list">
                    {sortedDepartments.map(
                      (d, index) => {
                        const value = Number(
                          d.total || 0
                        );

                        const percentage =
                          getPercentage(
                            value,
                            totalDepartmentGrievances
                          );

                        return (
                          <div
                            className="mobile-report-card"
                            key={
                              d.department ||
                              index
                            }
                          >
                            <div className="mobile-top">
                              <span className="mobile-name">
                                {index + 1}.{" "}
                                {d.department ||
                                  "-"}
                              </span>

                              <span className="mobile-total">
                                {value}
                              </span>
                            </div>

                            <div className="mobile-progress">
                              <div className="progress-track">
                                <div
                                  className="progress-bar"
                                  style={{
                                    width: `${percentage}%`,
                                  }}
                                />
                              </div>
                            </div>

                            <div className="mobile-row">
                              <span className="mobile-label">
                                Distribution
                              </span>

                              <span className="mobile-value">
                                {percentage}%
                              </span>
                            </div>
                          </div>
                        );
                      }
                    )}
                  </div>
                </>
              )}
            </section>

            {/* Monthly Trend */}
            <section className="section-card">
              <div className="section-header">
                <div>
                  <h2 className="section-title">
                    Monthly Trend
                  </h2>

                  <p className="section-description">
                    Grievance volume across reporting
                    months.
                  </p>
                </div>

                {highestMonthly && (
                  <span className="section-badge">
                    Peak:{" "}
                    {highestMonthly.month ||
                      "-"}
                  </span>
                )}
              </div>

              {monthly.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">
                    📈
                  </div>

                  <h3>
                    No monthly data
                  </h3>

                  <p>
                    Monthly trend data is
                    currently unavailable.
                  </p>
                </div>
              ) : (
                <div className="trend-list">
                  {monthly.map((m, index) => {
                    const value = Number(
                      m.total || 0
                    );

                    const barHeight = Math.max(
                      7,
                      Math.round(
                        (value /
                          monthlyMaximum) *
                          100
                      )
                    );

                    const isPeak =
                      highestMonthly &&
                      m === highestMonthly;

                    return (
                      <div
                        className="month-card"
                        key={`${m.month}-${index}`}
                      >
                        <div className="month-name">
                          {m.month || "-"}
                        </div>

                        <div className="month-total">
                          {value}
                        </div>

                        <div className="month-label">
                          grievances
                        </div>

                        <div className="month-bar-area">
                          <div className="month-bar-track">
                            <div
                              className="month-bar"
                              style={{
                                height: `${barHeight}%`,
                              }}
                            />
                          </div>
                        </div>

                        {isPeak && (
                          <span className="peak-tag">
                            ★ Peak month
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </section>

            {/* Quick Insights */}
            <section className="analytics-grid">
              <div className="analytics-card">
                <div className="analytics-head">
                  <div>
                    <h2 className="analytics-title">
                      Department Insight
                    </h2>

                    <p className="analytics-subtitle">
                      Highest grievance concentration.
                    </p>
                  </div>
                </div>

                <div className="metric-boxes">
                  <div className="metric-box">
                    <div className="metric-box-label">
                      Top Department
                    </div>

                    <div
                      className="metric-box-value"
                      style={{
                        fontSize:
                          highestDepartment?.department &&
                          highestDepartment.department
                            .length > 15
                            ? "17px"
                            : "21px",
                      }}
                    >
                      {highestDepartment?.department ||
                        "-"}
                    </div>

                    <div className="metric-box-description">
                      Highest workload
                    </div>
                  </div>

                  <div className="metric-box">
                    <div className="metric-box-label">
                      Total Cases
                    </div>

                    <div className="metric-box-value">
                      {highestDepartment?.total ??
                        0}
                    </div>

                    <div className="metric-box-description">
                      Top department cases
                    </div>
                  </div>
                </div>
              </div>

              <div className="analytics-card">
                <div className="analytics-head">
                  <div>
                    <h2 className="analytics-title">
                      Monthly Insight
                    </h2>

                    <p className="analytics-subtitle">
                      Highest recorded monthly volume.
                    </p>
                  </div>
                </div>

                <div className="metric-boxes">
                  <div className="metric-box">
                    <div className="metric-box-label">
                      Peak Month
                    </div>

                    <div className="metric-box-value">
                      {highestMonthly?.month ||
                        "-"}
                    </div>

                    <div className="metric-box-description">
                      Highest grievance volume
                    </div>
                  </div>

                  <div className="metric-box">
                    <div className="metric-box-label">
                      Peak Cases
                    </div>

                    <div className="metric-box-value">
                      {highestMonthly?.total ??
                        0}
                    </div>

                    <div className="metric-box-description">
                      Grievances in peak month
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Export */}
            <section className="section-card">
              <div className="export-section">
                <div>
                  <h3 className="export-title">
                    Export Reports
                  </h3>

                  <p className="export-description">
                    Download the complete analytics
                    report in CSV or PDF format.
                  </p>
                </div>

                <div className="export-buttons">
                  <button
                    className="export-btn csv-btn"
                    onClick={downloadCSV}
                  >
                    ↓ Export CSV
                  </button>

                  <button
                    className="export-btn pdf-btn"
                    onClick={downloadPDF}
                  >
                    ↓ Export PDF
                  </button>
                </div>
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}