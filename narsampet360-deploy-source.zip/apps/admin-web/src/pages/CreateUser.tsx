import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import client from "../api/client";

type Department = { id: string; name: string };
type Constituency = { id: string; name: string };
type Mandal = { id: string; name: string; constituencyId: string; constituency?: { id: string } };
type Village = { id: string; name: string; mandalId: string; mandal?: { id: string; constituencyId?: string } };

const roles = ["ADMIN", "OFFICER", "PA", "MLA", "MANDAL_INCHARGE", "VILLAGE_COORDINATOR"];

export default function CreateUser() {
  const navigate = useNavigate();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [constituencies, setConstituencies] = useState<Constituency[]>([]);
  const [mandals, setMandals] = useState<Mandal[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const [form, setForm] = useState({ name: "", mobile: "", email: "", password: "", role: "OFFICER", departmentId: "", constituencyId: "", mandalId: "", villageId: "" });

  useEffect(() => { loadMasterData(); }, []);

  async function loadMasterData() {
    try {
      setLoading(true);
      const [d, c, m, v] = await Promise.all([
        client.get("/departments"),
        client.get("/master/constituencies"),
        client.get("/master/mandals"),
        client.get("/master/villages"),
      ]);
      const unwrap = (r: any) => r.data?.data ?? r.data ?? [];
      setDepartments(Array.isArray(unwrap(d)) ? unwrap(d) : []);
      setConstituencies(Array.isArray(unwrap(c)) ? unwrap(c) : []);
      setMandals(Array.isArray(unwrap(m)) ? unwrap(m) : []);
      setVillages(Array.isArray(unwrap(v)) ? unwrap(v) : []);
    } catch (err: any) {
      alert(err.response?.data?.message || "Failed to load master data");
    } finally { setLoading(false); }
  }

  const filteredMandals = useMemo(() => form.constituencyId ? mandals.filter(m => m.constituencyId === form.constituencyId || m.constituency?.id === form.constituencyId) : [], [mandals, form.constituencyId]);
  const filteredVillages = useMemo(() => form.mandalId ? villages.filter(v => v.mandalId === form.mandalId || v.mandal?.id === form.mandalId) : [], [villages, form.mandalId]);
  const needsConstituency = ["MLA", "PA", "MANDAL_INCHARGE", "VILLAGE_COORDINATOR"].includes(form.role);
  const needsMandal = ["MANDAL_INCHARGE", "VILLAGE_COORDINATOR"].includes(form.role);
  const needsVillage = form.role === "VILLAGE_COORDINATOR";
  const needsDepartment = form.role === "OFFICER";

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value } = e.target;
    setForm(prev => {
      const next = { ...prev, [name]: value };
      if (name === "role") {
        next.constituencyId = prev.constituencyId;
        next.mandalId = prev.mandalId;
        next.villageId = prev.villageId;
      }
      if (name === "constituencyId") { next.mandalId = ""; next.villageId = ""; }
      if (name === "mandalId") next.villageId = "";
      return next;
    });
  }

  async function createUser() {
    if (!form.name.trim() || !form.mobile.trim() || !form.password.trim()) return alert("Name, mobile and password are required");
    if (needsConstituency && !form.constituencyId) return alert("Please select constituency");
    if (needsMandal && !form.mandalId) return alert("Please select mandal");
    if (needsVillage && !form.villageId) return alert("Please select village");
    if (needsDepartment && !form.departmentId) return alert("Please select department for the officer");

    try {
      setCreating(true);
      await client.post("/users", {
        name: form.name.trim(), mobile: form.mobile.trim(), email: form.email.trim() || undefined,
        password: form.password, role: form.role,
        constituencyId: form.constituencyId || undefined,
        mandalId: form.mandalId || undefined,
        villageId: form.villageId || undefined,
        departmentId: form.departmentId || undefined,
      });
      alert("User created successfully with assignment");
      navigate("/users");
    } catch (err: any) {
      const message = err.response?.data?.message;
      alert(Array.isArray(message) ? message.join("\n") : message || "Create user failed");
    } finally { setCreating(false); }
  }

  return <div style={{ padding: 40, maxWidth: 700 }}>
    <button onClick={() => navigate("/users")} style={{ marginBottom: 20, padding: "8px 14px" }}>← Back</button>
    <h1>Create User</h1>
    <p style={{ color: "#666" }}>Assign the user's service area here. The mobile app will use this assignment from the profile.</p>
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <input name="name" placeholder="Name" value={form.name} onChange={handleChange} />
      <input name="mobile" placeholder="Mobile" value={form.mobile} onChange={handleChange} />
      <input name="email" placeholder="Email" type="email" value={form.email} onChange={handleChange} />
      <input name="password" placeholder="Password" type="password" value={form.password} onChange={handleChange} />
      <select name="role" value={form.role} onChange={handleChange}><option value="">Select Role</option>{roles.map(r => <option key={r} value={r}>{r}</option>)}</select>

      {needsConstituency && <select name="constituencyId" value={form.constituencyId} onChange={handleChange} disabled={loading}><option value="">{loading ? "Loading constituencies..." : "Select Constituency"}</option>{constituencies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>}
      {needsMandal && <select name="mandalId" value={form.mandalId} onChange={handleChange} disabled={!form.constituencyId}><option value="">Select Mandal</option>{filteredMandals.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select>}
      {needsVillage && <select name="villageId" value={form.villageId} onChange={handleChange} disabled={!form.mandalId}><option value="">Select Village</option>{filteredVillages.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select>}
      {needsDepartment && <select name="departmentId" value={form.departmentId} onChange={handleChange} disabled={loading}><option value="">{loading ? "Loading departments..." : "Select Department"}</option>{departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select>}

      <button onClick={createUser} disabled={creating || loading} style={{ padding: "10px 20px" }}>{creating ? "Creating..." : "Create User"}</button>
    </div>
  </div>;
}
