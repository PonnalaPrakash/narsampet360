import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import client from "../api/client";

type Department = { id: string; name: string };
type Constituency = { id: string; name: string };
type Mandal = { id: string; name: string; constituencyId: string; constituency?: { id: string } };
type Village = { id: string; name: string; mandalId: string; mandal?: { id: string } };
const roles = ["ADMIN", "OFFICER", "PA", "MLA", "MANDAL_INCHARGE", "VILLAGE_COORDINATOR"];

export default function EditUser() {
  const { id } = useParams(); const navigate = useNavigate();
  const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false);
  const [departments, setDepartments] = useState<Department[]>([]); const [constituencies, setConstituencies] = useState<Constituency[]>([]); const [mandals, setMandals] = useState<Mandal[]>([]); const [villages, setVillages] = useState<Village[]>([]);
  const [form, setForm] = useState({ name: "", mobile: "", email: "", role: "", departmentId: "", constituencyId: "", mandalId: "", villageId: "" });

  useEffect(() => { if (id) load(); }, [id]);
  async function load() {
    try {
      const [u, d, c, m, v] = await Promise.all([client.get(`/users/${id}`), client.get("/departments"), client.get("/master/constituencies"), client.get("/master/mandals"), client.get("/master/villages")]);
      const unwrap = (r: any) => r.data?.data ?? r.data ?? [];
      const user = u.data?.data ?? u.data;
      setDepartments(Array.isArray(unwrap(d)) ? unwrap(d) : []); setConstituencies(Array.isArray(unwrap(c)) ? unwrap(c) : []); setMandals(Array.isArray(unwrap(m)) ? unwrap(m) : []); setVillages(Array.isArray(unwrap(v)) ? unwrap(v) : []);
      setForm({ name: user.name || "", mobile: user.mobile || "", email: user.email || "", role: user.role || "", departmentId: user.department?.id || user.departmentId || "", constituencyId: user.constituency?.id || user.constituencyId || "", mandalId: user.mandal?.id || user.mandalId || "", villageId: user.village?.id || user.villageId || "" });
    } catch (err: any) { alert(err.response?.data?.message || "Failed to load user"); } finally { setLoading(false); }
  }
  const filteredMandals = useMemo(() => form.constituencyId ? mandals.filter(m => m.constituencyId === form.constituencyId || m.constituency?.id === form.constituencyId) : [], [mandals, form.constituencyId]);
  const filteredVillages = useMemo(() => form.mandalId ? villages.filter(v => v.mandalId === form.mandalId || v.mandal?.id === form.mandalId) : [], [villages, form.mandalId]);
  const needsConstituency = ["MLA", "PA", "MANDAL_INCHARGE", "VILLAGE_COORDINATOR"].includes(form.role);
  const needsMandal = ["MANDAL_INCHARGE", "VILLAGE_COORDINATOR"].includes(form.role);
  const needsVillage = form.role === "VILLAGE_COORDINATOR";
  const needsDepartment = form.role === "OFFICER";
  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) { const { name, value } = e.target; setForm(p => { const n = { ...p, [name]: value }; if (name === "constituencyId") { n.mandalId = ""; n.villageId = ""; } if (name === "mandalId") n.villageId = ""; return n; }); }
  async function updateUser() {
    if (!id) return; if (!form.name.trim() || !form.mobile.trim()) return alert("Name and mobile are required");
    if (needsConstituency && !form.constituencyId) return alert("Please select constituency"); if (needsMandal && !form.mandalId) return alert("Please select mandal"); if (needsVillage && !form.villageId) return alert("Please select village"); if (needsDepartment && !form.departmentId) return alert("Please select department for the officer");
    try { setSaving(true); await client.patch(`/users/${id}`, { name: form.name.trim(), mobile: form.mobile.trim(), email: form.email.trim() || undefined, role: form.role, constituencyId: form.constituencyId || undefined, mandalId: form.mandalId || undefined, villageId: form.villageId || undefined, departmentId: form.departmentId || undefined }); alert("User updated successfully"); navigate(`/user/${id}`); } catch (err: any) { const m = err.response?.data?.message; alert(Array.isArray(m) ? m.join("\n") : m || "Update failed"); } finally { setSaving(false); }
  }
  if (loading) return <div style={{ padding: 40 }}><h3>Loading...</h3></div>;
  return <div style={{ padding: 40, maxWidth: 700 }}>
    <button onClick={() => navigate(`/user/${id}`)} style={{ marginBottom: 20, padding: "8px 14px" }}>← Back</button><h1>Edit User</h1>
    <p style={{ color: "#666" }}>Update the user's role and assigned service area.</p>
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <input name="name" placeholder="Name" value={form.name} onChange={handleChange}/><input name="mobile" placeholder="Mobile" value={form.mobile} onChange={handleChange}/><input name="email" placeholder="Email" type="email" value={form.email} onChange={handleChange}/>
      <select name="role" value={form.role} onChange={handleChange}><option value="">Select Role</option>{roles.map(r => <option key={r} value={r}>{r}</option>)}</select>
      {needsConstituency && <select name="constituencyId" value={form.constituencyId} onChange={handleChange}><option value="">Select Constituency</option>{constituencies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>}
      {needsMandal && <select name="mandalId" value={form.mandalId} onChange={handleChange} disabled={!form.constituencyId}><option value="">Select Mandal</option>{filteredMandals.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select>}
      {needsVillage && <select name="villageId" value={form.villageId} onChange={handleChange} disabled={!form.mandalId}><option value="">Select Village</option>{filteredVillages.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select>}
      {needsDepartment && <select name="departmentId" value={form.departmentId} onChange={handleChange}><option value="">Select Department</option>{departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select>}
      <button onClick={updateUser} disabled={saving} style={{ padding: "10px 20px" }}>{saving ? "Updating..." : "Update User"}</button>
    </div>
  </div>;
}
