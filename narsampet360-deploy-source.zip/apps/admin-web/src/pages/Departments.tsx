
import { useEffect, useMemo, useState } from "react";
import client from "../api/client";

type Department = {
  id: string | number;
  name?: string;
  description?: string;
  isActive?: boolean;
};

export default function Departments() {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  async function loadDepartments() {
    try {
      const res = await client.get("/departments");
      setDepartments(res.data || []);
    } catch (err: any) {
      setDepartments([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDepartments();
  }, []);

  async function createDepartment() {
    if (!name.trim()) {
      alert("Please enter department name");
      return;
    }

    try {
      await client.post("/departments", {
        name: name.trim(),
        description: description.trim(),
      });

      alert("Department created successfully");

      setName("");
      setDescription("");

      setLoading(true);
      await loadDepartments();
    } catch (err: any) {
      alert(
        err.response?.data?.message ||
          "Create failed"
      );
    }
  }

  async function deactivate(id: string | number) {
    const confirmed = window.confirm(
      "Are you sure you want to deactivate this department?"
    );

    if (!confirmed) return;

    try {
      await client.delete(
        `/departments/${id}`
      );

      alert("Department deactivated");

      setLoading(true);
      await loadDepartments();
    } catch (err: any) {
      alert(
        err.response?.data?.message ||
          "Failed"
      );
    }
  }

  const activeDepartments = departments.filter(
    (department) => department.isActive
  ).length;

  const inactiveDepartments =
    departments.length - activeDepartments;

  const filteredDepartments = useMemo(() => {
    const searchValue =
      search.trim().toLowerCase();

    return departments.filter((department) => {
      const matchesSearch =
        !searchValue ||
        department.name
          ?.toLowerCase()
          .includes(searchValue) ||
        department.description
          ?.toLowerCase()
          .includes(searchValue);

      const matchesStatus =
        statusFilter === "ALL" ||
        (statusFilter === "ACTIVE" &&
          department.isActive) ||
        (statusFilter === "INACTIVE" &&
          !department.isActive);

      return (
        matchesSearch &&
        matchesStatus
      );
    });
  }, [
    departments,
    search,
    statusFilter,
  ]);

  function handleSearch() {
    setSearch(search.trim());
  }

  function clearFilters() {
    setSearch("");
    setStatusFilter("ALL");
  }

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        .departments-page {
          min-height: 100vh;
          background:
            radial-gradient(
              circle at top right,
              rgba(37, 99, 235, 0.08),
              transparent 28%
            ),
            #f6f8fc;
          padding: 28px;
          color: #172033;
        }

        .departments-container {
          width: 100%;
          max-width: 1500px;
          margin: 0 auto;
        }

        /* HEADER */

        .premium-header {
          position: relative;
          overflow: hidden;
          border-radius: 22px;
          padding: 28px 30px;
          margin-bottom: 22px;
          background:
            linear-gradient(
              135deg,
              #0f3d91 0%,
              #1556c0 48%,
              #1976d2 100%
            );
          box-shadow:
            0 16px 40px
            rgba(15, 61, 145, 0.18);
          color: white;
        }

        .premium-header::after {
          content: "";
          position: absolute;
          width: 240px;
          height: 240px;
          right: -80px;
          top: -120px;
          border-radius: 50%;
          background:
            rgba(255,255,255,0.08);
        }

        .header-content {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
        }

        .brand-section {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .brand-icon {
          width: 54px;
          height: 54px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 16px;
          background:
            rgba(255,255,255,0.16);
          border:
            1px solid rgba(255,255,255,0.2);
          font-size: 25px;
          font-weight: 800;
        }

        .brand-title {
          margin: 0;
          font-size: 25px;
          font-weight: 800;
          letter-spacing: -0.5px;
        }

        .brand-subtitle {
          margin: 5px 0 0;
          color:
            rgba(255,255,255,0.78);
          font-size: 13px;
        }

        .create-header-btn {
          border: 0;
          border-radius: 12px;
          padding: 12px 18px;
          background: white;
          color: #1556c0;
          font-size: 14px;
          font-weight: 800;
          cursor: pointer;
          box-shadow:
            0 8px 20px
            rgba(0,0,0,0.12);
          transition:
            transform 0.2s ease,
            box-shadow 0.2s ease;
          white-space: nowrap;
        }

        .create-header-btn:hover {
          transform:
            translateY(-2px);
          box-shadow:
            0 12px 24px
            rgba(0,0,0,0.16);
        }

        /* STATS */

        .stats-grid {
          display: grid;
          grid-template-columns:
            repeat(3, minmax(0, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }

        .stat-card {
          background: white;
          border:
            1px solid #e5eaf2;
          border-radius: 17px;
          padding: 19px;
          box-shadow:
            0 6px 18px
            rgba(25, 40, 70, 0.05);
          transition:
            transform 0.2s ease,
            box-shadow 0.2s ease;
        }

        .stat-card:hover {
          transform:
            translateY(-2px);
          box-shadow:
            0 10px 25px
            rgba(25, 40, 70, 0.08);
        }

        .stat-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        .stat-label {
          color: #68758a;
          font-size: 13px;
          font-weight: 700;
        }

        .stat-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eef4ff;
          color: #1556c0;
          font-size: 17px;
          font-weight: 800;
        }

        .stat-value {
          margin-top: 9px;
          font-size: 28px;
          line-height: 1;
          font-weight: 800;
          color: #172033;
        }

        /* CREATE CARD */

        .create-card {
          background: white;
          border:
            1px solid #e3e8f0;
          border-radius: 18px;
          padding: 20px;
          margin-bottom: 20px;
          box-shadow:
            0 7px 22px
            rgba(25, 40, 70, 0.05);
        }

        .section-heading {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 17px;
        }

        .section-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eef4ff;
          color: #1556c0;
          font-weight: 800;
        }

        .section-title {
          margin: 0;
          font-size: 16px;
          font-weight: 800;
        }

        .section-subtitle {
          margin: 3px 0 0;
          color: #8a94a5;
          font-size: 11px;
        }

        .form-grid {
          display: grid;
          grid-template-columns:
            1fr 1.5fr auto;
          gap: 11px;
          align-items: end;
        }

        .field-group {
          min-width: 0;
        }

        .field-label {
          display: block;
          margin-bottom: 6px;
          color: #566275;
          font-size: 11px;
          font-weight: 800;
        }

        .form-input {
          width: 100%;
          height: 45px;
          border:
            1px solid #dce2eb;
          border-radius: 10px;
          padding: 0 13px;
          outline: none;
          background: #fbfcfe;
          color: #172033;
          font-size: 13px;
          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease;
        }

        .form-input:focus {
          border-color: #3478dc;
          box-shadow:
            0 0 0 3px
            rgba(52, 120, 220, 0.1);
          background: white;
        }

        .create-btn {
          height: 45px;
          padding: 0 19px;
          border: 0;
          border-radius: 10px;
          background: #1556c0;
          color: white;
          font-size: 13px;
          font-weight: 800;
          cursor: pointer;
          white-space: nowrap;
          transition:
            background 0.2s ease,
            transform 0.2s ease;
        }

        
        .create-btn:hover {
          background: #10479f;
          transform:
            translateY(-1px);
        }

        /* TOOLBAR */

        .toolbar-card {
          background: white;
          border:
            1px solid #e3e8f0;
          border-radius: 18px;
          padding: 18px;
          margin-bottom: 20px;
          box-shadow:
            0 6px 18px
            rgba(25, 40, 70, 0.04);
        }

        .search-row {
          display: flex;
          gap: 10px;
          align-items: stretch;
        }

        .search-box {
          position: relative;
          flex: 1;
        }

        .search-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform:
            translateY(-50%);
          color: #8a95a8;
          font-size: 17px;
          pointer-events: none;
        }

        .search-input {
          width: 100%;
          height: 46px;
          border:
            1px solid #dce2eb;
          border-radius: 11px;
          padding:
            0 14px 0 42px;
          outline: none;
          color: #172033;
          background: #fbfcfe;
          font-size: 14px;
        }

        .search-input:focus {
          border-color: #3478dc;
          box-shadow:
            0 0 0 3px
            rgba(52, 120, 220, 0.1);
          background: white;
        }

        .search-btn {
          height: 46px;
          padding: 0 22px;
          border: 0;
          border-radius: 11px;
          background: #1556c0;
          color: white;
          font-weight: 800;
          cursor: pointer;
          transition:
            background 0.2s ease,
            transform 0.2s ease;
        }

        .search-btn:hover {
          background: #10479f;
          transform:
            translateY(-1px);
        }

        .filter-row {
          display: grid;
          grid-template-columns:
            1fr auto;
          gap: 10px;
          margin-top: 12px;
        }

        .filter-select {
          height: 43px;
          width: 100%;
          border:
            1px solid #dce2eb;
          border-radius: 10px;
          padding: 0 12px;
          background: #fbfcfe;
          color: #344054;
          outline: none;
          font-size: 13px;
          cursor: pointer;
        }

        .clear-btn {
          height: 43px;
          padding: 0 16px;
          border:
            1px solid #dce2eb;
          border-radius: 10px;
          background: white;
          color: #526071;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        .clear-btn:hover {
          background: #f7f9fc;
        }

        /* TABLE */

        .table-card {
          background: white;
          border:
            1px solid #e3e8f0;
          border-radius: 18px;
          overflow: hidden;
          box-shadow:
            0 7px 22px
            rgba(25, 40, 70, 0.05);
        }

        .table-header {
          padding: 17px 20px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          border-bottom:
            1px solid #edf0f5;
        }

        .table-title {
          margin: 0;
          font-size: 16px;
          font-weight: 800;
        }

        .result-count {
          color: #7a8495;
          font-size: 12px;
          font-weight: 700;
        }

        .table-wrapper {
          width: 100%;
          overflow-x: auto;
        }

        table {
          width: 100%;
          min-width: 700px;
          border-collapse: separate;
          border-spacing: 0;
        }

        th {
          padding: 13px 18px;
          text-align: left;
          background: #f8faff;
          color: #697586;
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom:
            1px solid #e8edf4;
          white-space: nowrap;
        }

        td {
          padding: 15px 18px;
          border-bottom:
            1px solid #edf0f4;
          color: #344054;
          font-size: 13px;
          vertical-align: middle;
        }

        tbody tr {
          transition:
            background 0.18s ease;
        }

        tbody tr:hover {
          background: #f8fbff;
        }

        tbody tr:last-child td {
          border-bottom: 0;
        }

        .department-cell {
          display: flex;
          align-items: center;
          gap: 11px;
        }

        .department-icon {
          width: 39px;
          height: 39px;
          min-width: 39px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 11px;
          background: #eaf1ff;
          color: #1556c0;
          border:
            1px solid #d8e5ff;
          font-size: 16px;
          font-weight: 800;
        }

        .department-name {
          color: #172033;
          font-weight: 800;
        }

        .department-id {
          margin-top: 3px;
          color: #929baa;
          font-size: 10px;
        }

        .description {
          max-width: 500px;
          color: #697586;
          line-height: 1.45;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 12px;
          font-weight: 800;
          white-space: nowrap;
        }

        .status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
        }

        .status-active {
          color: #198754;
        }

        .status-active .status-dot {
          background: #20a464;
          box-shadow:
            0 0 0 3px
            rgba(32, 164, 100, 0.1);
        }

        .status-inactive {
          color: #8a94a5;
        }

        .status-inactive .status-dot {
          background: #9aa3b1;
        }

        .action-btn {
          border:
            1px solid #dce2eb;
          background: white;
          color: #b54747;
          border-radius: 8px;
          padding: 7px 11px;
          cursor: pointer;
          font-size: 11px;
          font-weight: 800;
          transition: all 0.18s ease;
        }

        .action-btn:hover {
          background: #fff4f4;
          border-color: #efbcbc;
        }

        /* EMPTY / LOADING */

        .empty-state,
        .loading-state {
          padding: 55px 20px;
          text-align: center;
          color: #758094;
        }

        .empty-icon {
          width: 48px;
          height: 48px;
          margin:
            0 auto 12px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f4f8;
          color: #8a95a8;
          font-size: 20px;
        }

        .empty-title {
          margin: 0;
          color: #344054;
          font-size: 15px;
          font-weight: 800;
        }

        .empty-text {
          margin: 6px 0 0;
          font-size: 12px;
        }

        /* MOBILE */

        .mobile-cards {
          display: none;
        }

        .mobile-department-card {
          padding: 16px;
          border-bottom:
            1px solid #edf0f4;
        }

        .mobile-department-card:last-child {
          border-bottom: 0;
        }

        .mobile-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }

        .mobile-description {
          margin-top: 13px;
          color: #697586;
          font-size: 12px;
          line-height: 1.5;
        }

        .mobile-bottom {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-top: 14px;
        }

        @media (max-width: 1000px) {
          .form-grid {
            grid-template-columns: 1fr 1fr;
          }

          .create-btn {
            width: 100%;
          }

          .form-grid .create-btn {
            grid-column: 1 / -1;
          }
        }

        @media (max-width: 700px) {
          .departments-page {
            padding: 14px;
          }

          .premium-header {
            padding: 20px;
            border-radius: 17px;
          }

          .header-content {
            align-items: flex-start;
          }

          .brand-title {
            font-size: 20px;
          }

          .brand-subtitle {
            font-size: 11px;
          }

          .brand-icon {
            width: 45px;
            height: 45px;
            font-size: 20px;
          }

          .create-header-btn {
            padding: 10px 12px;
            font-size: 12px;
          }

          .stats-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
            gap: 8px;
          }

          .stat-card {
            padding: 12px;
            border-radius: 14px;
          }

          .stat-value {
            font-size: 21px;
          }

          .stat-label {
            font-size: 10px;
          }

          .stat-icon {
            width: 30px;
            height: 30px;
            font-size: 13px;
          }

          .form-grid {
            grid-template-columns: 1fr;
          }

          .form-grid .create-btn {
            grid-column: auto;
          }

          .search-row {
            flex-direction: column;
          }

          .search-btn {
            width: 100%;
          }

          .filter-row {
            grid-template-columns: 1fr;
          }

          .table-wrapper {
            display: none;
          }

          .mobile-cards {
            display: block;
          }

          .table-header {
            padding: 14px 16px;
          }

          .create-card,
          .toolbar-card,
          .table-card {
            border-radius: 14px;
          }
        }

        @media (max-width: 430px) {
          .header-content {
            flex-direction: column;
          }

          .create-header-btn {
            width: 100%;
          }

          .stats-grid {
            grid-template-columns: 1fr 1fr 1fr;
          }

          .stat-label {
            line-height: 1.25;
          }

          .mobile-bottom {
            align-items: flex-start;
            flex-direction: column;
          }

          .mobile-bottom .action-btn {
            width: 100%;
          }
        }
      `}</style>

      <div className="departments-page">
        <div className="departments-container">

          {/* HEADER */}

          <section className="premium-header">
            <div className="header-content">

              <div className="brand-section">
                <div className="brand-icon">
                  N
                </div>

                <div>
                  <h1 className="brand-title">
                    Narsampet360
                  </h1>

                  <p className="brand-subtitle">
                    Department Management •
                    Administration Portal
                  </p>
                </div>
              </div>

              <button
                className="create-header-btn"
                onClick={() => {
                  document
                    .getElementById(
                      "create-department"
                    )
                    ?.scrollIntoView({
                      behavior: "smooth",
                    });
                }}
              >
                + Add Department
              </button>

            </div>
          </section>

          {/* STATS */}

          <section className="stats-grid">

            <div className="stat-card">
              <div className="stat-top">
                <span className="stat-label">
                  Total Departments
                </span>

                <div className="stat-icon">
                  ▦
                </div>
              </div>

              <div className="stat-value">
                {departments.length}
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-top">
                <span className="stat-label">
                  Active
                </span>

                <div className="stat-icon">
                  ✓
                </div>
              </div>

              <div className="stat-value">
                {activeDepartments}
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-top">
                <span className="stat-label">
                  Inactive
                </span>

                <div className="stat-icon">
                  —
                </div>
              </div>

              <div className="stat-value">
                {inactiveDepartments}
              </div>
            </div>

          </section>

          {/* CREATE DEPARTMENT */}

          <section
            id="create-department"
            className="create-card"
          >

            <div className="section-heading">

              <div className="section-icon">
                +
              </div>

              <div>
                <h2 className="section-title">
                  Create Department
                </h2>

                <p className="section-subtitle">
                  Add a new department to
                  Narsampet360
                </p>
              </div>

            </div>

            <div className="form-grid">

              <div className="field-group">

                <label className="field-label">
                  Department Name
                </label>

                <input
                  className="form-input"
                  placeholder="Enter department name"
                  value={name}
                  onChange={(e) =>
                    setName(e.target.value)
                  }
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      createDepartment();
                    }
                  }}
                />

              </div>

              <div className="field-group">

                <label className="field-label">
                  Description
                </label>

                <input
                  className="form-input"
                  placeholder="Enter department description"
                  value={description}
                  onChange={(e) =>
                    setDescription(
                      e.target.value
                    )
                  }
                />

              </div>

              <button
                className="create-btn"
                onClick={createDepartment}
              >
                + Create Department
              </button>

            </div>

          </section>

          {/* SEARCH / FILTER */}

          <section className="toolbar-card">

            <div className="search-row">

              <div className="search-box">

                <span className="search-icon">
                  🔎
                </span>

                <input
                  className="search-input"
                  type="text"
                  placeholder="Search department name or description..."
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSearch();
                    }
                  }}
                />

              </div>

              <button
                className="search-btn"
                onClick={handleSearch}
              >
                Search
              </button>

            </div>

            <div className="filter-row">

              <select
                className="filter-select"
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(
                    e.target.value
                  )
                }
              >
                <option value="ALL">
                  All Status
                </option>

                <option value="ACTIVE">
                  Active
                </option>

                <option value="INACTIVE">
                  Inactive
                </option>
              </select>

              <button
                className="clear-btn"
                onClick={clearFilters}
              >
                Clear Filters
              </button>

            </div>

          </section>

          {/* DEPARTMENT LIST */}

          <section className="table-card">

            <div className="table-header">

              <h2 className="table-title">
                Departments
              </h2>

              <span className="result-count">
                {filteredDepartments.length} result
                {filteredDepartments.length !== 1
                  ? "s"
                  : ""}
              </span>

            </div>

            {loading ? (

              <div className="loading-state">
                Loading departments...
              </div>

            ) : filteredDepartments.length ===
              0 ? (

              <div className="empty-state">

                <div className="empty-icon">
                  ▦
                </div>

                <p className="empty-title">
                  No departments found
                </p>

                <p className="empty-text">
                  Try changing your search
                  or filters.
                </p>

              </div>

            ) : (

              <>

                {/* DESKTOP / TABLET */}

                <div className="table-wrapper">

                  <table>

                    <thead>

                      <tr>
                        <th>
                          Department
                        </th>

                        <th>
                          Description
                        </th>

                        <th>
                          Status
                        </th>

                        <th>
                          Action
                        </th>
                      </tr>

                    </thead>

                    <tbody>

                      {filteredDepartments.map(
                        (department) => (

                          <tr
                            key={department.id}
                          >

                            <td>

                              <div className="department-cell">

                                <div className="department-icon">
                                  ▦
                                </div>

                                <div>

                                  <div className="department-name">
                                    {department.name ||
                                      "Unnamed Department"}
                                  </div>

                                  <div className="department-id">
                                    ID:{" "}
                                    {department.id}
                                  </div>

                                </div>

                              </div>

                            </td>

                            <td>

                              <div className="description">
                                {department.description ||
                                  "-"}
                              </div>

                            </td>

                            <td>

                              <span
                                className={`status-badge ${
                                  department.isActive
                                    ? "status-active"
                                    : "status-inactive"
                                }`}
                              >

                                <span className="status-dot" />

                                {department.isActive
                                  ? "Active"
                                  : "Inactive"}

                              </span>

                            </td>

                            <td>

                              {department.isActive ? (

                                <button
                                  className="action-btn"
                                  onClick={() =>
                                    deactivate(
                                      department.id
                                    )
                                  }
                                >
                                  Deactivate
                                </button>

                              ) : (

                                <span
                                  className="status-badge status-inactive"
                                >
                                  Deactivated
                                </span>

                              )}

                            </td>

                          </tr>

                        )
                      )}

                    </tbody>

                  </table>

                </div>

                {/* MOBILE */}

                <div className="mobile-cards">

                  {filteredDepartments.map(
                    (department) => (

                      <div
                        className="mobile-department-card"
                        key={department.id}
                      >

                        <div className="mobile-card-top">

                          <div className="department-cell">

                            <div className="department-icon">
                              ▦
                            </div>

                            <div>

                              <div className="department-name">
                                {department.name ||
                                  "Unnamed Department"}
                              </div>

                              <div className="department-id">
                                ID:{" "}
                                {department.id}
                              </div>

                            </div>

                          </div>

                          <span
                            className={`status-badge ${
                              department.isActive
                                ? "status-active"
                                : "status-inactive"
                            }`}
                          >

                            <span className="status-dot" />

                            {department.isActive
                              ? "Active"
                              : "Inactive"}

                          </span>

                        </div>

                        <div className="mobile-description">
                          {department.description ||
                            "No description available."}
                        </div>

                        <div className="mobile-bottom">

                          <span className="department-id">
                            Department ID:{" "}
                            {department.id}
                          </span>

                          {department.isActive && (
                            <button
                              className="action-btn"
                              onClick={() =>
                                deactivate(
                                  department.id
                                )
                              }
                            >
                              Deactivate
                            </button>
                          )}

                        </div>

                      </div>

                    )
                  )}

                </div>

              </>

            )}

          </section>

        </div>
      </div>
    </>
  );
}
