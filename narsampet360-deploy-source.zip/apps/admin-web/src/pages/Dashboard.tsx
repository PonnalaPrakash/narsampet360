
import {
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  getMyGrievances,
  updateGrievanceStatus,
} from "../api/grievanceApi";
import { useNavigate } from "react-router-dom";

type UserRole =
  | "ADMIN"
  | "SUPER_ADMIN"
  | "DISTRICT_ADMIN"
  | "MANDAL_ADMIN"
  | "OFFICER"
  | "EMPLOYEE"
  | "STAFF"
  | "CITIZEN"
  | string;

type Grievance = {
  id: string;
  title: string;
  description?: string;
  status: string;
  priority?: string;
  citizenName?: string;
  citizenMobile?: string;
  createdAt?: string;
  village?: {
    name: string;
  };
  mandal?: {
    name: string;
  };
  department?: {
    name: string;
  };
  assignedTo?: {
    id: string;
    name: string;
    mobile?: string;
  };
};

type DashboardSummary = {
  total: number;
  pending: number;
  assigned: number;
  inProgress: number;
  resolved: number;
  rejected: number;
  closed: number;
  today: number;
};

const initialSummary: DashboardSummary = {
  total: 0,
  pending: 0,
  assigned: 0,
  inProgress: 0,
  resolved: 0,
  rejected: 0,
  closed: 0,
  today: 0,
};

const STATUS_META: Record<
  string,
  {
    label: string;
    background: string;
    color: string;
    border: string;
    dot: string;
  }
> = {
  PENDING: {
    label: "Pending",
    background: "#fff7ed",
    color: "#c2410c",
    border: "#fed7aa",
    dot: "#f97316",
  },
  ASSIGNED: {
    label: "Assigned",
    background: "#eff6ff",
    color: "#1d4ed8",
    border: "#bfdbfe",
    dot: "#3b82f6",
  },
  IN_PROGRESS: {
    label: "In Progress",
    background: "#f5f3ff",
    color: "#6d28d9",
    border: "#ddd6fe",
    dot: "#8b5cf6",
  },
  FORWARDED: {
    label: "Forwarded",
    background: "#eff6ff",
    color: "#1d4ed8",
    border: "#bfdbfe",
    dot: "#3b82f6",
  },
  PROCESSING: {
    label: "Processing",
    background: "#f5f3ff",
    color: "#6d28d9",
    border: "#ddd6fe",
    dot: "#8b5cf6",
  },
  RESOLVED: {
    label: "Resolved",
    background: "#ecfdf5",
    color: "#047857",
    border: "#a7f3d0",
    dot: "#10b981",
  },
  COMPLETED: {
    label: "Completed",
    background: "#ecfdf5",
    color: "#047857",
    border: "#a7f3d0",
    dot: "#10b981",
  },
  DISPOSED: {
    label: "Disposed",
    background: "#ecfdf5",
    color: "#047857",
    border: "#a7f3d0",
    dot: "#10b981",
  },
  REDRESSED: {
    label: "Redressed",
    background: "#ecfdf5",
    color: "#047857",
    border: "#a7f3d0",
    dot: "#10b981",
  },
  REJECTED: {
    label: "Rejected",
    background: "#fef2f2",
    color: "#b91c1c",
    border: "#fecaca",
    dot: "#ef4444",
  },
  CLOSED: {
    label: "Closed",
    background: "#f1f5f9",
    color: "#475569",
    border: "#cbd5e1",
    dot: "#64748b",
  },
};

const PRIORITY_META: Record<
  string,
  {
    label: string;
    background: string;
    color: string;
    border: string;
  }
> = {
  LOW: {
    label: "Low",
    background: "#f0fdf4",
    color: "#15803d",
    border: "#bbf7d0",
  },
  MEDIUM: {
    label: "Medium",
    background: "#fffbeb",
    color: "#a16207",
    border: "#fde68a",
  },
  HIGH: {
    label: "High",
    background: "#fff7ed",
    color: "#c2410c",
    border: "#fed7aa",
  },
  URGENT: {
    label: "Urgent",
    background: "#fef2f2",
    color: "#b91c1c",
    border: "#fecaca",
  },
  CRITICAL: {
    label: "Critical",
    background: "#fef2f2",
    color: "#991b1b",
    border: "#fecaca",
  },
};

const extractGrievances = (payload: any): Grievance[] => {
  if (Array.isArray(payload)) {
    return payload;
  }

  if (Array.isArray(payload?.data)) {
    return payload.data;
  }

  if (Array.isArray(payload?.grievances)) {
    return payload.grievances;
  }

  if (Array.isArray(payload?.data?.grievances)) {
    return payload.data.grievances;
  }

  if (Array.isArray(payload?.result)) {
    return payload.result;
  }

  if (Array.isArray(payload?.data?.result)) {
    return payload.data.result;
  }

  return [];
};

const formatDate = (value?: string) => {
  if (!value) {
    return "—";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatDateTime = (value?: string) => {
  if (!value) {
    return "—";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const getStatusMeta = (status?: string) => {
  const normalized = String(status || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  return (
    STATUS_META[normalized] || {
      label:
        normalized
          .replace(/_/g, " ")
          .toLowerCase()
          .replace(/\b\w/g, (char) =>
            char.toUpperCase(),
          ) || "Unknown",
      background: "#f8fafc",
      color: "#475569",
      border: "#cbd5e1",
      dot: "#64748b",
    }
  );
};

const getPriorityMeta = (priority?: string) => {
  const normalized = String(priority || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  return (
    PRIORITY_META[normalized] || {
      label:
        normalized
          .replace(/_/g, " ")
          .toLowerCase()
          .replace(/\b\w/g, (char) =>
            char.toUpperCase(),
          ) || "Normal",
      background: "#f8fafc",
      color: "#475569",
      border: "#cbd5e1",
    }
  );
};

const normalizeStatus = (status: unknown) =>
  String(status ?? "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");

const getRecordStatus = (grievance: any) =>
  normalizeStatus(
    grievance?.status ??
      grievance?.grievanceStatus ??
      grievance?.currentStatus ??
      grievance?.state,
  );

const getAllowedNextStatuses = (status?: string) => {
  const normalized = normalizeStatus(status);

  switch (normalized) {
    case "pending":
      return ["ASSIGNED"];

    case "assigned":
      return ["IN_PROGRESS", "FORWARDED"];

    case "in_progress":
    case "processing":
    case "forwarded":
    case "under_processing":
    case "under_process":
      return ["RESOLVED", "REJECTED"];

    case "resolved":
      return ["CLOSED"];

    case "completed":
    case "disposed":
    case "redressed":
    case "rejected":
    case "closed":
      return [];

    default:
      return [];
  }
};

function Dashboard() {
  const navigate = useNavigate();

  const [summary, setSummary] =
    useState<DashboardSummary>(initialSummary);

  const [grievances, setGrievances] =
    useState<Grievance[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [refreshing, setRefreshing] =
    useState(false);

  const [error, setError] =
    useState("");

  const [lastUpdated, setLastUpdated] =
    useState<Date | null>(null);

  const [updatingId, setUpdatingId] =
    useState<string | null>(null);

  const [userRole, setUserRole] =
    useState<UserRole>("ADMIN");

  useEffect(() => {
    try {
      const storedUser =
        localStorage.getItem("user") ||
        localStorage.getItem("userData");

      if (storedUser) {
        const parsedUser =
          JSON.parse(storedUser);

        setUserRole(
          parsedUser?.role ||
            parsedUser?.user?.role ||
            "ADMIN",
        );
      }
    } catch {
      setUserRole("ADMIN");
    }
  }, []);

  const loadDashboard = async (
    showRefreshState = false,
  ) => {
    try {
      if (showRefreshState) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      /*
       * IMPORTANT:
       * Dashboard statistics are calculated ONLY from
       * the actual grievances returned by /grievance/my.
       *
       * We intentionally do NOT use /grievance/dashboard
       * for KPI numbers.
       */
      const response =
        await getMyGrievances();

      const list =
        extractGrievances(response);

      const resolvedStatuses = new Set([
        "resolved",
        "closed",
        "completed",
        "disposed",
        "redressed",
      ]);

      const inProgressStatuses = new Set([
        "assigned",
        "processing",
        "in_progress",
        "forwarded",
        "under_processing",
        "under_process",
      ]);

      const rejectedStatuses = new Set([
        "rejected",
        "reject",
      ]);

      const total = list.length;

      let resolved = 0;
      let inProgress = 0;
      let rejected = 0;
      let pending = 0;
      let assigned = 0;
      let closed = 0;

      list.forEach((grievance: any) => {
        const status =
          getRecordStatus(grievance);

        if (
          resolvedStatuses.has(status)
        ) {
          resolved++;

          if (status === "closed") {
            closed++;
          }

          return;
        }

        if (
          inProgressStatuses.has(status)
        ) {
          inProgress++;

          if (status === "assigned") {
            assigned++;
          }

          return;
        }

        if (
          rejectedStatuses.has(status)
        ) {
          rejected++;
          pending++;
          return;
        }

        /*
         * Anything that is not resolved,
         * in-progress or rejected is treated
         * as pending.
         */
        pending++;
      });

      const today = list.filter(
        (grievance: any) => {
          const createdAt =
            grievance?.createdAt ??
            grievance?.created_at ??
            grievance?.registeredAt ??
            grievance?.createdDate;

          if (!createdAt) {
            return false;
          }

          const createdDate =
            new Date(createdAt);

          if (
            Number.isNaN(
              createdDate.getTime(),
            )
          ) {
            return false;
          }

          const now = new Date();

          return (
            createdDate.getFullYear() ===
              now.getFullYear() &&
            createdDate.getMonth() ===
              now.getMonth() &&
            createdDate.getDate() ===
              now.getDate()
          );
        },
      ).length;

      const normalizedSummary: DashboardSummary =
        {
          total,
          pending,
          assigned,
          inProgress,
          resolved,
          rejected,
          closed,
          today,
        };

      setSummary(normalizedSummary);
      setGrievances(list);
      setLastUpdated(new Date());
    } catch (err: any) {
      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Failed to load dashboard";

      setError(message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const openGrievance = (
    grievanceId: string,
  ) => {
    navigate(
      `/grievances/${grievanceId}`,
    );
  };

  const handleStatusUpdate = async (
    grievance: Grievance,
    nextStatus: string,
  ) => {
    try {
      setUpdatingId(grievance.id);
      setError("");

      await updateGrievanceStatus(
        grievance.id,
        { status: nextStatus },
      );

      await loadDashboard(true);
    } catch (err: any) {
      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Failed to update grievance status";

      setError(message);
    } finally {
      setUpdatingId(null);
    }
  };

  const resolutionRate =
    summary.total > 0
      ? Math.round(
          (summary.resolved /
            summary.total) *
            100,
        )
      : 0;

  /*
   * Resolved is already the aggregate completed
   * count. Do not add closed again because CLOSED
   * is included inside RESOLVED.
   */
  const completedCases =
    summary.resolved;

  /*
   * Assigned is already included inside
   * In Progress. Do not double-count it here.
   */
  const activeCases =
    summary.pending +
    summary.inProgress;

  const recentGrievances =
    useMemo(
      () =>
        [...grievances]
          .sort((a, b) => {
            const aTime = a.createdAt
              ? new Date(
                  a.createdAt,
                ).getTime()
              : 0;

            const bTime = b.createdAt
              ? new Date(
                  b.createdAt,
                ).getTime()
              : 0;

            return bTime - aTime;
          })
          .slice(0, 8),
      [grievances],
    );

  const departmentStats =
    useMemo(() => {
      const counts: Record<
        string,
        number
      > = {};

      grievances.forEach(
        (grievance) => {
          const department =
            grievance.department
              ?.name ||
            "Unassigned";

          counts[department] =
            (counts[department] || 0) +
            1;
        },
      );

      return Object.entries(counts)
        .sort(
          (a, b) =>
            b[1] - a[1],
        )
        .slice(0, 5);
    }, [grievances]);

  const mandalStats =
    useMemo(() => {
      const counts: Record<
        string,
        number
      > = {};

      grievances.forEach(
        (grievance) => {
          const mandal =
            grievance.mandal
              ?.name ||
            "Unknown Mandal";

          counts[mandal] =
            (counts[mandal] || 0) +
            1;
        },
      );

      return Object.entries(counts)
        .sort(
          (a, b) =>
            b[1] - a[1],
        )
        .slice(0, 5);
    }, [grievances]);

  const maxDepartmentCount =
    departmentStats.length > 0
      ? Math.max(
          ...departmentStats.map(
            ([, count]) => count,
          ),
        )
      : 1;

  const healthPercentage =
  summary.total > 0
    ? Math.round(
        (summary.resolved /
          summary.total) *
          100,
      )
    : 0;

  const refreshDashboard = () => {
    loadDashboard(true);
  };

  if (loading) {
    return (
      <>
        <style>{styles}</style>

        <div className="dashboard-loading">
          <div className="loading-logo">
            N
          </div>

          <div className="loading-line large" />
          <div className="loading-line medium" />

          <div className="loading-grid">
            <div className="skeleton-card" />
            <div className="skeleton-card" />
            <div className="skeleton-card" />
            <div className="skeleton-card" />
          </div>

          <p>
            Loading grievance dashboard...
          </p>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{styles}</style>

      <div className="dashboard-page">
        {/* =================================================
            HEADER
            ================================================= */}

        <header className="dashboard-header">
          <div className="brand-area">
            <div className="brand-mark">
              N
            </div>

            <div>
              <div className="brand-name">
                NARSAMPET360
              </div>

              <div className="brand-subtitle">
                GRIEVANCE MANAGEMENT SYSTEM
              </div>
            </div>
          </div>

          <div className="header-right">
            <div className="admin-badge">
              <span className="live-dot" />
              {String(userRole).replace(
                /_/g,
                " ",
              )}
            </div>

            <button
              className="refresh-button"
              onClick={
                refreshDashboard
              }
              disabled={refreshing}
            >
              <span
                className={
                  refreshing
                    ? "refresh-icon spinning"
                    : "refresh-icon"
                }
              >
                ↻
              </span>

              {refreshing
                ? "Refreshing..."
                : "Refresh"}
            </button>

            <span className="updated-text">
              {lastUpdated
                ? `Updated ${formatDateTime(
                    lastUpdated.toISOString(),
                  )}`
                : "Not updated yet"}
            </span>
          </div>
        </header>

        <main className="dashboard-main">
          {/* =================================================
              HERO
              ================================================= */}

          <section className="hero-section">
            <div>
              <div className="hero-eyebrow">
                ADMINISTRATIVE OVERVIEW
              </div>

              <h1>
                Grievance Dashboard
              </h1>

              <p>
                Monitor grievance activity,
                track resolution progress,
                and manage citizen requests
                from one administrative
                workspace.
              </p>
            </div>

            <div className="hero-metrics">
              <div className="hero-metric">
                <span>Total</span>
                <strong>
                  {summary.total}
                </strong>
              </div>

              <div className="hero-divider" />

              <div className="hero-metric">
                <span>Resolved</span>
                <strong>
                  {summary.resolved}
                </strong>
              </div>

              <div className="hero-divider" />

              <div className="hero-metric">
                <span>Today</span>
                <strong>
                  {summary.today}
                </strong>
              </div>
            </div>
          </section>

          {error ? (
            <div className="error-banner">
              <div>
                <strong>
                  Dashboard error
                </strong>

                <span>{error}</span>
              </div>

              <button
                onClick={() =>
                  loadDashboard()
                }
              >
                Retry
              </button>
            </div>
          ) : null}

          {/* =================================================
              KPI CARDS
              ================================================= */}

          <section className="kpi-grid">
            <button
              className="kpi-card blue"
              onClick={() =>
                navigate("/grievances")
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ◉
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.total}
              </div>

              <div className="kpi-title">
                Total Grievances
              </div>

              <div className="kpi-description">
                All records from your
                grievance list
              </div>
            </button>

            <button
              className="kpi-card orange"
              onClick={() =>
                navigate(
                  "/grievances?status=PENDING",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ◷
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.pending}
              </div>

              <div className="kpi-title">
                Pending
              </div>

              <div className="kpi-description">
                Remaining unresolved
                records
              </div>
            </button>

            <button
              className="kpi-card indigo"
              onClick={() =>
                navigate(
                  "/grievances?status=IN_PROGRESS",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ↻
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.inProgress}
              </div>

              <div className="kpi-title">
                In Progress
              </div>

              <div className="kpi-description">
                Assigned and processing
                cases
              </div>
            </button>

            <button
              className="kpi-card violet"
              onClick={() =>
                navigate(
                  "/grievances?status=ASSIGNED",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ◎
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.assigned}
              </div>

              <div className="kpi-title">
                Assigned
              </div>

              <div className="kpi-description">
                Currently assigned
                grievances
              </div>
            </button>

            <button
              className="kpi-card green"
              onClick={() =>
                navigate(
                  "/grievances?status=RESOLVED",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ✓
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.resolved}
              </div>

              <div className="kpi-title">
                Resolved
              </div>

              <div className="kpi-description">
                Successfully completed
                outcomes
              </div>
            </button>

            <button
              className="kpi-card red"
              onClick={() =>
                navigate(
                  "/grievances?status=REJECTED",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  ×
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.rejected}
              </div>

              <div className="kpi-title">
                Rejected
              </div>

              <div className="kpi-description">
                Rejected grievance
                records
              </div>
            </button>

            <button
              className="kpi-card slate"
              onClick={() =>
                navigate(
                  "/grievances?status=CLOSED",
                )
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  □
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {summary.closed}
              </div>

              <div className="kpi-title">
                Closed
              </div>

              <div className="kpi-description">
                Closed grievance
                records
              </div>
            </button>

            <button
              className="kpi-card teal"
              onClick={() =>
                navigate("/grievances")
              }
            >
              <div className="kpi-top">
                <span className="kpi-icon">
                  %
                </span>

                <span className="kpi-arrow">
                  →
                </span>
              </div>

              <div className="kpi-value">
                {resolutionRate}%
              </div>

              <div className="kpi-title">
                Resolution Rate
              </div>

              <div className="kpi-description">
                Resolved ÷ total
                grievances
              </div>
            </button>
          </section>

          {/* =================================================
              QUICK ACTIONS
              ================================================= */}

          <section className="section-block">
            <div className="section-heading">
              <div>
                <div className="section-eyebrow">
                  SHORTCUTS
                </div>

                <h2>
                  Quick Actions
                </h2>
              </div>

              <span className="section-note">
                Common administrative
                tasks
              </span>
            </div>

            <div
              className={
                String(userRole).toUpperCase() ===
                  "CITIZEN"
                  ? "quick-actions quick-actions-limited"
                  : "quick-actions"
              }
            >
              <button
                className="quick-action"
                onClick={() =>
                  navigate("/grievances")
                }
              >
                <span className="quick-icon">
                  ▦
                </span>

                <span>
                  <strong>
                    View Grievances
                  </strong>

                  <small>
                    Browse all available
                    grievance records
                  </small>
                </span>

                <b>→</b>
              </button>

              <button
                className="quick-action"
                onClick={() =>
                  navigate(
                    "/grievances?status=PENDING",
                  )
                }
              >
                <span className="quick-icon">
                  ◷
                </span>

                <span>
                  <strong>
                    Pending Cases
                  </strong>

                  <small>
                    Review unresolved
                    grievance records
                  </small>
                </span>

                <b>→</b>
              </button>

              <button
                className="quick-action"
                onClick={() =>
                  navigate(
                    "/grievances?status=IN_PROGRESS",
                  )
                }
              >
                <span className="quick-icon">
                  ↻
                </span>

                <span>
                  <strong>
                    In Progress
                  </strong>

                  <small>
                    Track active
                    processing cases
                  </small>
                </span>

                <b>→</b>
              </button>

              <button
                className="quick-action"
                onClick={() =>
                  navigate(
                    "/grievances?status=RESOLVED",
                  )
                }
              >
                <span className="quick-icon">
                  ✓
                </span>

                <span>
                  <strong>
                    Resolved Cases
                  </strong>

                  <small>
                    Review completed
                    grievance outcomes
                  </small>
                </span>

                <b>→</b>
              </button>
            </div>
          </section>

          {/* =================================================
              ANALYTICS
              ================================================= */}

          <section className="section-block">
            <div className="section-heading">
              <div>
                <div className="section-eyebrow">
                  PERFORMANCE
                </div>

                <h2>
                  Grievance Analytics
                </h2>
              </div>

              <span className="section-note">
                Calculated from actual
                grievance records
              </span>
            </div>

            <div className="analytics-grid">
              {/* Resolution Overview */}

              <div className="panel">
                <div className="panel-header">
                  <div>
                    <div className="panel-eyebrow">
                      RESOLUTION OVERVIEW
                    </div>

                    <h3>
                      Case Resolution
                    </h3>
                  </div>

                  <span className="resolution-badge">
                    {resolutionRate}%
                    resolved
                  </span>
                </div>

                <div className="resolution-content">
                  <div className="resolution-ring-wrap">
                    <div
                      className="resolution-ring"
                      style={
                        {
                          "--resolution": `${resolutionRate}%`,
                        } as React.CSSProperties
                      }
                    >
                      <div className="ring-inner">
                        <strong>
                          {resolutionRate}%
                        </strong>

                        <span>
                          Resolution
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="resolution-list">
                    <div className="resolution-row">
                      <span>
                        <i className="dot pending" />
                        Pending
                      </span>

                      <strong>
                        {summary.pending}
                      </strong>
                    </div>

                    <div className="resolution-row">
                      <span>
                        <i className="dot assigned" />
                        Assigned
                      </span>

                      <strong>
                        {summary.assigned}
                      </strong>
                    </div>

                    <div className="resolution-row">
                      <span>
                        <i className="dot progress" />
                        In Progress
                      </span>

                      <strong>
                        {summary.inProgress}
                      </strong>
                    </div>

                    <div className="resolution-row">
                      <span>
                        <i className="dot resolved" />
                        Resolved
                      </span>

                      <strong>
                        {summary.resolved}
                      </strong>
                    </div>

                    <div className="resolution-row">
                      <span>
                        <i className="dot rejected" />
                        Rejected
                      </span>

                      <strong>
                        {summary.rejected}
                      </strong>
                    </div>

                    <div className="resolution-row">
                      <span>
                        <i className="dot closed" />
                        Closed
                      </span>

                      <strong>
                        {summary.closed}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Department Ranking */}

              <div className="panel">
                <div className="panel-header">
                  <div>
                    <div className="panel-eyebrow">
                      DEPARTMENT ACTIVITY
                    </div>

                    <h3>
                      Top Departments
                    </h3>
                  </div>

                  <button
                    className="text-button"
                    onClick={() =>
                      navigate(
                        "/grievances",
                      )
                    }
                  >
                    View all
                  </button>
                </div>

                {departmentStats.length ===
                0 ? (
                  <div className="empty-panel">
                    No department data
                    available.
                  </div>
                ) : (
                  <div className="ranking-list">
                    {departmentStats.map(
                      (
                        [
                          department,
                          count,
                        ],
                        index,
                      ) => (
                        <div
                          className="ranking-row"
                          key={
                            department
                          }
                        >
                          <span className="ranking-number">
                            {String(
                              index + 1,
                            ).padStart(
                              2,
                              "0",
                            )}
                          </span>

                          <div className="ranking-main">
                            <div className="ranking-title">
                              <span>
                                {
                                  department
                                }
                              </span>

                              <strong>
                                {count}
                              </strong>
                            </div>

                            <div className="progress-track">
                              <div
                                className="progress-fill"
                                style={{
                                  width: `${Math.round(
                                    (count /
                                      maxDepartmentCount) *
                                      100,
                                  )}%`,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      ),
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Secondary Analytics */}

            <div className="secondary-grid">
              <div className="panel compact-panel">
                <div className="panel-header">
                  <div>
                    <div className="panel-eyebrow">
                      LOCATION ACTIVITY
                    </div>

                    <h3>
                      Mandal Activity
                    </h3>
                  </div>

                  <span className="section-note">
                    Top 5
                  </span>
                </div>

                {mandalStats.length ===
                0 ? (
                  <div className="empty-panel">
                    No mandal data
                    available.
                  </div>
                ) : (
                  <div className="mandal-list">
                    {mandalStats.map(
                      (
                        [mandal, count],
                        index,
                      ) => (
                        <div
                          className="mandal-row"
                          key={mandal}
                        >
                          <div>
                            <strong>
                              {mandal}
                            </strong>

                            <span>
                              Rank #
                              {index + 1}
                            </span>
                          </div>

                          <b>{count}</b>
                        </div>
                      ),
                    )}
                  </div>
                )}
              </div>

              <div className="panel compact-panel">
                <div className="panel-header">
                  <div>
                    <div className="panel-eyebrow">
                      DASHBOARD HEALTH
                    </div>

                    <h3>
                      Current Status
                    </h3>
                  </div>

                  <span className="health-status">
                    Live
                  </span>
                </div>

                <div className="health-grid">
                  <div className="health-item">
                    <span>
                      Total Cases
                    </span>

                    <strong>
                      {summary.total}
                    </strong>
                  </div>

                  <div className="health-item">
                    <span>
                      Active Cases
                    </span>

                    <strong>
                      {activeCases}
                    </strong>
                  </div>

                  <div className="health-item">
                    <span>
                      Completed
                    </span>

                    <strong>
                      {completedCases}
                    </strong>
                  </div>

                  <div className="health-item">
                    <span>
                      Today
                    </span>

                    <strong>
                      {summary.today}
                    </strong>
                  </div>
                </div>

                <div className="health-progress">
                  <div className="health-progress-head">
                    <span>
                      Overall completion
                    </span>

                    <strong>
                      {healthPercentage}%
                    </strong>
                  </div>

                  <div className="progress-track">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${healthPercentage}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* =================================================
              RECENT GRIEVANCES
              ================================================= */}

          <section className="recent-section">
            <div className="section-heading">
              <div>
                <div className="section-eyebrow">
                  LIVE RECORDS
                </div>

                <h2>
                  Recent Grievances
                </h2>
              </div>

              <button
                className="view-all-button"
                onClick={() =>
                  navigate(
                    "/grievances",
                  )
                }
              >
                View all grievances →
              </button>
            </div>

            {recentGrievances.length ===
            0 ? (
              <div className="empty-recent">
                <div className="empty-icon">
                  ▦
                </div>

                <h3>
                  No grievances found
                </h3>

                <p>
                  New grievances will
                  appear here once they
                  are registered.
                </p>
              </div>
            ) : (
              <>
                {/* =================================================
                    DESKTOP TABLE
                    ================================================= */}

                <div className="grievance-table">
                  <div className="table-head">
                    <span>
                      GRIEVANCE
                    </span>

                    <span>
                      CITIZEN
                    </span>

                    <span>
                      LOCATION
                    </span>

                    <span>
                      DEPARTMENT
                    </span>

                    <span>
                      STATUS
                    </span>

                    <span>
                      ACTIONS
                    </span>
                  </div>

                  {recentGrievances.map(
                    (grievance) => {
                      const statusMeta =
                        getStatusMeta(
                          grievance.status,
                        );

                      const priorityMeta =
                        getPriorityMeta(
                          grievance.priority,
                        );

                      const nextStatuses =
                        getAllowedNextStatuses(
                          grievance.status,
                        );

                      const isUpdating =
                        updatingId ===
                        grievance.id;

                      return (
                        <div
                          className="table-row"
                          key={
                            grievance.id
                          }
                        >
                          <div className="grievance-cell">
                            <button
                              className="grievance-title-button"
                              onClick={() =>
                                openGrievance(
                                  grievance.id,
                                )
                              }
                            >
                              <span className="grievance-title-scroll">
                                {grievance.title ||
                                  "Untitled grievance"}
                              </span>
                            </button>

                            <div className="grievance-meta">
                              <span
                                className="priority-pill"
                                style={{
                                  background:
                                    priorityMeta.background,
                                  color:
                                    priorityMeta.color,
                                  borderColor:
                                    priorityMeta.border,
                                }}
                              >
                                {
                                  priorityMeta.label
                                }
                              </span>

                              <span>
                                {formatDate(
                                  grievance.createdAt,
                                )}
                              </span>
                            </div>
                          </div>

                          <div className="citizen-cell">
                            <strong>
                              {grievance.citizenName ||
                                "Unknown Citizen"}
                            </strong>

                            <span>
                              {grievance.citizenMobile ||
                                "No mobile"}
                            </span>
                          </div>

                          <div className="location-cell">
                            <strong>
                              {grievance.village
                                ?.name ||
                                "Unknown Village"}
                            </strong>

                            <span>
                              {grievance.mandal
                                ?.name ||
                                "Unknown Mandal"}
                            </span>
                          </div>

                          <div className="department-cell">
                            {grievance.department
                              ?.name ||
                              "Unassigned"}
                          </div>

                          <div>
                            <span
                              className="status-pill"
                              style={{
                                background:
                                  statusMeta.background,
                                color:
                                  statusMeta.color,
                                borderColor:
                                  statusMeta.border,
                              }}
                            >
                              <i
                                style={{
                                  background:
                                    statusMeta.dot,
                                }}
                              />

                              {
                                statusMeta.label
                              }
                            </span>
                          </div>

                          <div className="action-cell">
                            <div className="status-actions">
                              {nextStatuses.length >
                              0
                                ? nextStatuses.map(
                                    (
                                      nextStatus,
                                    ) => {
                                      const nextMeta =
                                        getStatusMeta(
                                          nextStatus,
                                        );

                                      return (
                                        <button
                                          key={
                                            nextStatus
                                          }
                                          className="status-action-button"
                                          disabled={
                                            isUpdating
                                          }
                                          onClick={() =>
                                            handleStatusUpdate(
                                              grievance,
                                              nextStatus,
                                            )
                                          }
                                          style={{
                                            background:
                                              nextMeta.background,
                                            color:
                                              nextMeta.color,
                                            borderColor:
                                              nextMeta.border,
                                          }}
                                        >
                                          {isUpdating
                                            ? "Updating..."
                                            : `Mark ${nextMeta.label}`}
                                        </button>
                                      );
                                    },
                                  )
                                : null}

                              <button
                                className="details-button"
                                onClick={() =>
                                  openGrievance(
                                    grievance.id,
                                  )
                                }
                              >
                                Details →
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    },
                  )}
                </div>

                {/* =================================================
                    MOBILE CARDS
                    ================================================= */}

                <div className="mobile-grievances">
                  {recentGrievances.map(
                    (grievance) => {
                      const statusMeta =
                        getStatusMeta(
                          grievance.status,
                        );

                      const priorityMeta =
                        getPriorityMeta(
                          grievance.priority,
                        );

                      const nextStatuses =
                        getAllowedNextStatuses(
                          grievance.status,
                        );

                      const isUpdating =
                        updatingId ===
                        grievance.id;

                      return (
                        <div
                          className="mobile-grievance-card"
                          key={
                            grievance.id
                          }
                        >
                          <div className="mobile-card-top">
                            <span
                              className="status-pill"
                              style={{
                                background:
                                  statusMeta.background,
                                color:
                                  statusMeta.color,
                                borderColor:
                                  statusMeta.border,
                              }}
                            >
                              <i
                                style={{
                                  background:
                                    statusMeta.dot,
                                }}
                              />

                              {
                                statusMeta.label
                              }
                            </span>

                            <span
                              className="priority-pill"
                              style={{
                                background:
                                  priorityMeta.background,
                                color:
                                  priorityMeta.color,
                                borderColor:
                                  priorityMeta.border,
                              }}
                            >
                              {
                                priorityMeta.label
                              }
                            </span>
                          </div>

                          <button
                            className="mobile-title"
                            onClick={() =>
                              openGrievance(
                                grievance.id,
                              )
                            }
                          >
                            <span className="mobile-title-scroll">
                              {grievance.title ||
                                "Untitled grievance"}
                            </span>
                          </button>

                          <div className="mobile-info">
                            <div>
                              <span>
                                Citizen
                              </span>

                              <strong>
                                {grievance.citizenName ||
                                  "Unknown Citizen"}
                              </strong>
                            </div>

                            <div>
                              <span>
                                Location
                              </span>

                              <strong>
                                {grievance.village
                                  ?.name ||
                                  "Unknown Village"}

                                {grievance.mandal
                                  ?.name
                                  ? `, ${grievance.mandal.name}`
                                  : ""}
                              </strong>
                            </div>

                            <div>
                              <span>
                                Department
                              </span>

                              <strong>
                                {grievance.department
                                  ?.name ||
                                  "Unassigned"}
                              </strong>
                            </div>

                            <div>
                              <span>
                                Created
                              </span>

                              <strong>
                                {formatDateTime(
                                  grievance.createdAt,
                                )}
                              </strong>
                            </div>
                          </div>

                          <div className="mobile-card-actions">
                            {nextStatuses.length >
                            0
                              ? nextStatuses.map(
                                  (
                                    nextStatus,
                                  ) => {
                                    const nextMeta =
                                      getStatusMeta(
                                        nextStatus,
                                      );

                                    return (
                                      <button
                                        key={
                                          nextStatus
                                        }
                                        disabled={
                                          isUpdating
                                        }
                                        onClick={() =>
                                          handleStatusUpdate(
                                            grievance,
                                            nextStatus,
                                          )
                                        }
                                        style={{
                                          background:
                                            nextMeta.background,
                                          color:
                                            nextMeta.color,
                                          borderColor:
                                            nextMeta.border,
                                        }}
                                      >
                                        {isUpdating
                                          ? "Updating..."
                                          : `Mark ${nextMeta.label}`}
                                      </button>
                                    );
                                  },
                                )
                              : null}

                            <button
                              className="mobile-details"
                              onClick={() =>
                                openGrievance(
                                  grievance.id,
                                )
                              }
                            >
                              Open Details →
                            </button>
                          </div>
                        </div>
                      );
                    },
                  )}
                </div>
              </>
            )}
          </section>
        </main>

        {/* =====================================================
            FOOTER
            ===================================================== */}

        <footer className="dashboard-footer">
          <span>
            © {new Date().getFullYear()}{" "}
            Narsampet360
          </span>

          <span>
            Grievance Management System
          </span>

          <span>
            Administrative Workspace
          </span>
        </footer>
      </div>
    </>
  );
}
const styles = `
  * {
    box-sizing: border-box;
  }

  .dashboard-page {
    min-height: 100vh;
    background: #f8fafc;
    color: #0f172a;
    font-family:
      Inter,
      ui-sans-serif,
      system-ui,
      -apple-system,
      BlinkMacSystemFont,
      "Segoe UI",
      sans-serif;
  }

  .dashboard-header {
    min-height: 76px;
    padding: 0 34px;
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    position: sticky;
    top: 0;
    z-index: 20;
  }

  .brand-area {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .brand-mark {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    background: #0f172a;
    color: #ffffff;
    font-size: 18px;
    font-weight: 900;
    box-shadow: 0 6px 18px rgba(15, 23, 42, 0.15);
  }

  .brand-name {
    font-size: 14px;
    font-weight: 900;
    letter-spacing: 0.13em;
  }

  .brand-subtitle {
    margin-top: 2px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.15em;
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .admin-badge {
    height: 34px;
    padding: 0 12px;
    border: 1px solid #dbeafe;
    background: #eff6ff;
    color: #1d4ed8;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 0.06em;
  }

  .live-dot {
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: #22c55e;
    box-shadow: 0 0 0 4px #dcfce7;
  }

  .refresh-button {
    height: 36px;
    padding: 0 13px;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #ffffff;
    color: #334155;
    font-size: 12px;
    font-weight: 800;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    transition: 0.18s ease;
  }

  .refresh-button:hover:not(:disabled) {
    background: #f8fafc;
    border-color: #cbd5e1;
  }

  .refresh-button:disabled {
    opacity: 0.65;
    cursor: wait;
  }

  .refresh-icon {
    font-size: 17px;
    line-height: 1;
  }

  .spinning {
    animation: spin 0.9s linear infinite;
  }

  .updated-text {
    color: #94a3b8;
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
  }

  .dashboard-main {
    width: min(1480px, calc(100% - 48px));
    margin: 0 auto;
    padding: 30px 0 52px;
  }

  .hero-section {
    min-height: 220px;
    padding: 34px;
    border-radius: 24px;
    background:
      radial-gradient(
        circle at 90% 10%,
        rgba(59, 130, 246, 0.22),
        transparent 32%
      ),
      linear-gradient(
        135deg,
        #0f172a 0%,
        #172554 58%,
        #1d4ed8 100%
      );
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 40px;
    overflow: hidden;
    position: relative;
    box-shadow:
      0 20px 45px rgba(15, 23, 42, 0.15);
  }

  .hero-eyebrow {
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 0.18em;
    color: #93c5fd;
    margin-bottom: 10px;
  }

  .hero-section h1 {
    margin: 0;
    font-size: clamp(28px, 3vw, 44px);
    line-height: 1.05;
    letter-spacing: -0.035em;
  }

  .hero-section p {
    max-width: 650px;
    margin: 14px 0 0;
    color: #cbd5e1;
    font-size: 14px;
    line-height: 1.7;
  }

  .hero-metrics {
    min-width: 430px;
    padding: 22px 24px;
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 18px;
    background: rgba(255, 255, 255, 0.07);
    backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .hero-metric {
    min-width: 100px;
    text-align: center;
  }

  .hero-metric span {
    display: block;
    color: #bfdbfe;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.1em;
  }

  .hero-metric strong {
    display: block;
    margin-top: 6px;
    font-size: 28px;
    letter-spacing: -0.03em;
  }

  .hero-divider {
    width: 1px;
    height: 42px;
    background: rgba(255, 255, 255, 0.15);
    margin: 0 12px;
  }

  .error-banner {
    margin-top: 18px;
    padding: 15px 18px;
    border: 1px solid #fecaca;
    border-radius: 14px;
    background: #fef2f2;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
  }

  .error-banner div {
    display: flex;
    flex-direction: column;
    gap: 3px;
  }

  .error-banner strong {
    color: #991b1b;
    font-size: 13px;
  }

  .error-banner span {
    color: #b91c1c;
    font-size: 12px;
  }

  .error-banner button {
    border: 1px solid #fecaca;
    background: #ffffff;
    color: #991b1b;
    border-radius: 9px;
    padding: 8px 12px;
    font-weight: 800;
    cursor: pointer;
  }

  .kpi-grid {
    margin-top: 22px;
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
  }

  .kpi-card {
    min-height: 174px;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    background: #ffffff;
    padding: 20px;
    text-align: left;
    cursor: pointer;
    transition:
      transform 0.18s ease,
      box-shadow 0.18s ease,
      border-color 0.18s ease;
  }

  .kpi-card:hover {
    transform: translateY(-3px);
    border-color: #cbd5e1;
    box-shadow:
      0 14px 30px rgba(15, 23, 42, 0.08);
  }

  .kpi-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .kpi-icon {
    width: 38px;
    height: 38px;
    display: grid;
    place-items: center;
    border-radius: 11px;
    font-weight: 900;
    font-size: 18px;
  }

  .kpi-arrow {
    color: #cbd5e1;
    font-size: 18px;
    transition: 0.18s ease;
  }

  .kpi-card:hover .kpi-arrow {
    color: #64748b;
    transform: translateX(3px);
  }

  .kpi-value {
    margin-top: 18px;
    font-size: 32px;
    line-height: 1;
    font-weight: 900;
    letter-spacing: -0.04em;
  }

  .kpi-title {
    margin-top: 9px;
    font-size: 13px;
    font-weight: 900;
  }

  .kpi-description {
    margin-top: 4px;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 700;
  }

  .kpi-card.blue .kpi-icon {
    background: #eff6ff;
    color: #2563eb;
  }

  .kpi-card.orange .kpi-icon {
    background: #fff7ed;
    color: #ea580c;
  }

  .kpi-card.indigo .kpi-icon {
    background: #eef2ff;
    color: #4f46e5;
  }

  .kpi-card.violet .kpi-icon {
    background: #f5f3ff;
    color: #7c3aed;
  }

  .kpi-card.green .kpi-icon {
    background: #ecfdf5;
    color: #059669;
  }

  .kpi-card.red .kpi-icon {
    background: #fef2f2;
    color: #dc2626;
  }

  .kpi-card.slate .kpi-icon {
    background: #f1f5f9;
    color: #475569;
  }

  .kpi-card.teal .kpi-icon {
    background: #f0fdfa;
    color: #0f766e;
  }

  .section-block {
    margin-top: 38px;
  }

  .section-heading {
    margin-bottom: 16px;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
  }

  .section-eyebrow,
  .panel-eyebrow {
    color: #64748b;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 0.16em;
  }

  .section-heading h2 {
    margin: 5px 0 0;
    font-size: 22px;
    letter-spacing: -0.025em;
  }

  .section-note {
    color: #94a3b8;
    font-size: 11px;
    font-weight: 700;
  }

  .quick-actions {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
  }

  .quick-actions-limited {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .quick-action {
    min-height: 92px;
    padding: 16px;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    background: #ffffff;
    display: flex;
    align-items: center;
    gap: 12px;
    text-align: left;
    cursor: pointer;
    transition: 0.18s ease;
  }

  .quick-action:hover {
    transform: translateY(-2px);
    border-color: #bfdbfe;
    box-shadow:
      0 12px 26px rgba(15, 23, 42, 0.07);
  }

  .quick-icon {
    width: 38px;
    height: 38px;
    flex: 0 0 38px;
    border-radius: 11px;
    background: #eff6ff;
    color: #2563eb;
    display: grid;
    place-items: center;
    font-weight: 900;
  }

  .quick-action > span:nth-child(2) {
    min-width: 0;
    flex: 1;
  }

  .quick-action strong {
    display: block;
    color: #0f172a;
    font-size: 12px;
    font-weight: 900;
  }

  .quick-action small {
    display: block;
    margin-top: 4px;
    color: #94a3b8;
    font-size: 10px;
    line-height: 1.4;
  }

  .quick-action b {
    color: #cbd5e1;
    font-size: 17px;
  }

  .analytics-grid {
    margin-top: 22px;
    display: grid;
    grid-template-columns: 1.05fr 0.95fr;
    gap: 16px;
  }

  .panel {
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    background: #ffffff;
    padding: 22px;
  }

  .panel-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 15px;
  }

  .panel-header h3 {
    margin: 5px 0 0;
    font-size: 17px;
    letter-spacing: -0.02em;
  }

  .resolution-badge,
  .health-status {
    padding: 6px 9px;
    border-radius: 999px;
    background: #ecfdf5;
    color: #047857;
    border: 1px solid #a7f3d0;
    font-size: 10px;
    font-weight: 900;
  }

  .resolution-content {
    margin-top: 25px;
    display: grid;
    grid-template-columns: 190px 1fr;
    gap: 25px;
    align-items: center;
  }

  .resolution-ring-wrap {
    display: flex;
    justify-content: center;
  }

  .resolution-ring {
    width: 156px;
    height: 156px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background:
      conic-gradient(
        #2563eb var(--resolution),
        #e2e8f0 0
      );
    position: relative;
  }

  .resolution-ring::before {
    content: "";
    position: absolute;
    inset: 11px;
    border-radius: 50%;
    background: #ffffff;
  }

  .ring-inner {
    position: relative;
    z-index: 1;
    text-align: center;
  }

  .ring-inner strong {
    display: block;
    font-size: 28px;
    font-weight: 900;
  }

  .ring-inner span {
    display: block;
    margin-top: 2px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .resolution-list {
    display: flex;
    flex-direction: column;
  }

  .resolution-row {
    padding: 8px 0;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    font-size: 11px;
    font-weight: 700;
  }

  .resolution-row:last-child {
    border-bottom: 0;
  }

  .resolution-row span {
    display: flex;
    align-items: center;
    gap: 7px;
    color: #64748b;
  }

  .resolution-row strong {
    color: #0f172a;
  }

  .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    display: inline-block;
  }

  .dot.pending {
    background: #f97316;
  }

  .dot.assigned {
    background: #3b82f6;
  }

  .dot.progress {
    background: #8b5cf6;
  }

  .dot.resolved {
    background: #10b981;
  }

  .dot.rejected {
    background: #ef4444;
  }

  .dot.closed {
    background: #64748b;
  }

  .text-button,
  .view-all-button {
    border: 0;
    background: transparent;
    color: #2563eb;
    font-size: 11px;
    font-weight: 900;
    cursor: pointer;
  }

  .ranking-list {
    margin-top: 20px;
  }

  .ranking-row {
    display: flex;
    gap: 11px;
    align-items: center;
    padding: 11px 0;
    border-bottom: 1px solid #f1f5f9;
  }

  .ranking-row:last-child {
    border-bottom: 0;
  }

  .ranking-number {
    width: 26px;
    color: #94a3b8;
    font-size: 10px;
    font-weight: 900;
  }

  .ranking-main {
    min-width: 0;
    flex: 1;
  }

  .ranking-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 7px;
  }

  .ranking-title span {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #334155;
    font-size: 11px;
    font-weight: 800;
  }

  .ranking-title strong {
    color: #0f172a;
    font-size: 11px;
  }

  .progress-track {
    height: 7px;
    overflow: hidden;
    border-radius: 999px;
    background: #eef2f7;
  }

  .progress-fill {
    height: 100%;
    border-radius: inherit;
    background: #2563eb;
    transition: width 0.35s ease;
  }

  .secondary-grid {
    margin-top: 16px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }

  .compact-panel {
    min-height: 260px;
  }

  .empty-panel {
    min-height: 170px;
    display: grid;
    place-items: center;
    text-align: center;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 700;
  }

  .mandal-list {
    margin-top: 17px;
  }

  .mandal-row {
    padding: 12px 0;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
  }

  .mandal-row:last-child {
    border-bottom: 0;
  }

  .mandal-row div {
    min-width: 0;
  }

  .mandal-row strong {
    display: block;
    color: #334155;
    font-size: 12px;
    font-weight: 900;
  }

  .mandal-row span {
    display: block;
    margin-top: 3px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
  }

  .mandal-row b {
    min-width: 32px;
    height: 32px;
    display: grid;
    place-items: center;
    border-radius: 9px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: 11px;
  }

  .health-grid {
    margin-top: 21px;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }

  .health-item {
    padding: 14px;
    border: 1px solid #eef2f7;
    border-radius: 12px;
    background: #f8fafc;
  }

  .health-item span {
    display: block;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
  }

  .health-item strong {
    display: block;
    margin-top: 6px;
    color: #0f172a;
    font-size: 20px;
    font-weight: 900;
  }

  .health-progress {
    margin-top: 17px;
  }

  .health-progress-head {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 7px;
    color: #64748b;
    font-size: 10px;
    font-weight: 800;
  }

  .health-progress-head strong {
    color: #0f172a;
  }

  .recent-section {
    margin-top: 38px;
  }

  .grievance-table {
    width: 100%;
    max-width: 100%;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    overflow: hidden;
    background: #ffffff;
  }

  .grievance-table::-webkit-scrollbar {
    height: 11px;
  }

  .grievance-table::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 999px;
  }

  .grievance-table::-webkit-scrollbar-thumb {
    background: #94a3b8;
    border-radius: 999px;
    border: 2px solid #f1f5f9;
  }

  .grievance-table::-webkit-scrollbar-thumb:hover {
    background: #64748b;
  }

  .table-head,
  .table-row {
    display: grid;
    grid-template-columns: 24% 17% 17% 16% 12% 14%;
    gap: 8px;
    align-items: center;
    width: 100%;
    min-width: 0;
    box-sizing: border-box;
  }

.table-head > *,
.table-row > * {
  min-width: 0;
  max-width: 100%;
}

  .table-head {
    min-height: 44px;
    padding: 0 20px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    color: #94a3b8;
    font-size: 8px;
    font-weight: 900;
    letter-spacing: 0.12em;
    position: sticky;
    top: 0;
    z-index: 2;
  }

  .table-row {
    min-height: 104px;
    padding: 15px 20px;
    border-bottom: 1px solid #f1f5f9;
  }

  .table-row:last-child {
    border-bottom: 0;
  }

  .grievance-table {
    cursor: default;
  }

  .grievance-cell,
  .citizen-cell,
  .location-cell {
    min-width: 0;
  }

  .grievance-title-button {
    width: 100%;
    max-width: 100%;
    height: 54px;
    min-height: 54px;
    padding: 0 8px 0 0;
    border: 0;
    background: transparent;
    color: #0f172a;
    font-size: 12px;
    line-height: 1.5;
    font-weight: 900;
    text-align: left;
    cursor: pointer;
    overflow: hidden;
  }

  .grievance-title-scroll {
    display: block;
    width: 100%;
    height: 54px;
    max-height: 54px;
    overflow-x: auto;
    overflow-y: auto;
    white-space: normal;
    overflow-wrap: anywhere;
    word-break: break-word;
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 transparent;
    padding-right: 3px;
  }

  .grievance-title-scroll::-webkit-scrollbar {
    width: 5px;
  }

  .grievance-title-scroll::-webkit-scrollbar-track {
    background: transparent;
  }

  .grievance-title-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 999px;
  }

  .grievance-title-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }

  .grievance-title-button:hover,
  .mobile-title:hover {
    color: #2563eb;
  }

  .grievance-meta {
    margin-top: 8px;
    display: flex;
    align-items: center;
    gap: 7px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
  }

  .priority-pill,
  .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    width: fit-content;
    padding: 5px 8px;
    border: 1px solid;
    border-radius: 999px;
    font-size: 8px;
    font-weight: 900;
    white-space: nowrap;
  }

  .status-pill i {
    width: 5px;
    height: 5px;
    border-radius: 50%;
  }

  .citizen-cell strong,
  .location-cell strong {
    display: block;
    color: #334155;
    font-size: 10px;
    font-weight: 900;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .citizen-cell span,
  .location-cell span {
    display: block;
    margin-top: 4px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .department-cell {
    color: #475569;
    font-size: 10px;
    font-weight: 800;
  }

  .action-cell {
    min-width: 0;
  }

  .status-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
  }

  .status-action-button,
  .details-button {
    padding: 6px 8px;
    border: 1px solid;
    border-radius: 8px;
    font-size: 8px;
    font-weight: 900;
    cursor: pointer;
  }

  .status-action-button:disabled {
    opacity: 0.55;
    cursor: wait;
  }

  .details-button {
    border-color: #dbeafe;
    background: #eff6ff;
    color: #1d4ed8;
  }

  .empty-recent {
    min-height: 260px;
    border: 1px dashed #cbd5e1;
    border-radius: 18px;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
  }

  .empty-icon {
    width: 48px;
    height: 48px;
    display: grid;
    place-items: center;
    border-radius: 14px;
    background: #eff6ff;
    color: #2563eb;
    font-weight: 900;
    font-size: 20px;
  }

  .empty-recent h3 {
    margin: 13px 0 4px;
    font-size: 14px;
  }

  .empty-recent p {
    margin: 0;
    color: #94a3b8;
    font-size: 11px;
  }

  .mobile-grievances {
    display: none;
  }

  .dashboard-footer {
    width: min(1480px, calc(100% - 48px));
    margin: 0 auto;
    padding: 20px 0 30px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    gap: 15px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
  }

  .dashboard-loading {
    min-height: 100vh;
    width: min(1000px, calc(100% - 40px));
    margin: 0 auto;
    padding-top: 120px;
    text-align: center;
  }

  .loading-logo {
    width: 52px;
    height: 52px;
    margin: 0 auto 20px;
    display: grid;
    place-items: center;
    border-radius: 15px;
    background: #0f172a;
    color: #ffffff;
    font-weight: 900;
    font-size: 21px;
    animation: pulse 1.3s ease-in-out infinite;
  }

  .loading-line {
    height: 10px;
    margin: 10px auto;
    border-radius: 999px;
    background: #e2e8f0;
    animation: pulse 1.3s ease-in-out infinite;
  }

  .loading-line.large {
    width: 280px;
  }

  .loading-line.medium {
    width: 180px;
  }

  .loading-grid {
    margin-top: 30px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
  }

  .skeleton-card {
    height: 150px;
    border-radius: 17px;
    background: #e2e8f0;
    animation: pulse 1.3s ease-in-out infinite;
  }

  .dashboard-loading p {
    margin-top: 24px;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 700;
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  @keyframes pulse {
    0%,
    100% {
      opacity: 0.65;
    }

    50% {
      opacity: 1;
    }
  }

  @media (max-width: 1180px) {
    .kpi-grid,
    .quick-actions,
    .quick-actions-limited {
      grid-template-columns: repeat(2, 1fr);
    }

    .table-head,
  .table-row {
    display: grid;
    grid-template-columns: 24% 17% 17% 16% 12% 14%;
    gap: 8px;
    align-items: center;
    width: 100%;
    min-width: 0;
    box-sizing: border-box;
  }

.table-head > *,
.table-row > * {
  min-width: 0;
  max-width: 100%;
}
  }

  @media (max-width: 980px) {
    .hero-section {
      flex-direction: column;
      align-items: flex-start;
    }

    .hero-metrics {
      width: max(100%, 1320px);
  min-width: 1320px;
    }

    .analytics-grid,
    .secondary-grid {
      grid-template-columns: 1fr;
    }

    .grievance-table {
      display: none;
    }

    .mobile-grievances {
      display: grid;
      gap: 12px;
    }

    .mobile-grievance-card {
      padding: 17px;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      background: #ffffff;
    }

    .mobile-card-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .mobile-title {
      width: 100%;
      height: 82px;
      max-height: 82px;
      margin-top: 13px;
      padding: 0 8px 0 0;
      border: 0;
      background: transparent;
      color: #0f172a;
      text-align: left;
      font-size: 14px;
      line-height: 1.5;
      font-weight: 900;
      cursor: pointer;
      overflow: hidden;
    }

    .mobile-title-scroll {
      display: block;
      width: 100%;
      height: 82px;
      max-height: 82px;
      overflow-x: auto;
      overflow-y: auto;
      white-space: normal;
      overflow-wrap: anywhere;
      word-break: break-word;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 transparent;
      padding-right: 3px;
    }

    .mobile-title-scroll::-webkit-scrollbar {
      width: 5px;
    }

    .mobile-title-scroll::-webkit-scrollbar-track {
      background: transparent;
    }

    .mobile-title-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 999px;
    }

    .mobile-title-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }

    .mobile-info {
      margin-top: 15px;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 11px;
    }

    .mobile-info div {
      padding: 10px;
      border-radius: 11px;
      background: #f8fafc;
    }

    .mobile-info span {
      display: block;
      color: #94a3b8;
      font-size: 8px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.08em;
    }

    .mobile-info strong {
      display: block;
      margin-top: 4px;
      color: #334155;
      font-size: 10px;
      line-height: 1.4;
    }

    .mobile-card-actions {
      margin-top: 13px;
      display: flex;
      flex-wrap: wrap;
      gap: 7px;
    }

    .mobile-card-actions button {
      padding: 8px 10px;
      border: 1px solid #dbeafe;
      border-radius: 9px;
      font-size: 9px;
      font-weight: 900;
      cursor: pointer;
    }

    .mobile-card-actions button:disabled {
      opacity: 0.55;
      cursor: wait;
    }

    .mobile-card-actions .mobile-details {
      background: #ffffff;
      border-color: #e2e8f0;
      color: #334155;
    }
  }

  @media (max-width: 700px) {
    .dashboard-header {
      padding: 14px 18px;
      align-items: flex-start;
    }

    .header-right {
      flex-wrap: wrap;
      justify-content: flex-end;
    }

    .admin-badge {
      display: none;
    }

    .updated-text {
      width: 100%;
      text-align: right;
    }

    .dashboard-main {
      width: min(100% - 24px, 1480px);
      padding-top: 18px;
    }

    .hero-section {
      padding: 24px;
      border-radius: 20px;
    }

    .hero-section h1 {
      font-size: 28px;
    }

    .hero-metrics {
      padding: 17px 10px;
    }

    .hero-metric {
      min-width: 78px;
    }

    .hero-metric strong {
      font-size: 23px;
    }

    .hero-metric span {
      font-size: 8px;
    }

    .hero-divider {
      margin: 0 4px;
    }

    .kpi-grid,
    .quick-actions,
    .quick-actions-limited {
      grid-template-columns: 1fr;
    }

    .kpi-card {
      min-height: 145px;
    }

    .section-heading {
      align-items: flex-start;
      flex-direction: column;
    }

    .resolution-content {
      grid-template-columns: 1fr;
    }

    .resolution-ring-wrap {
      justify-content: flex-start;
    }

    .panel {
      padding: 18px;
    }

    .dashboard-footer {
      width: min(100% - 24px, 1480px);
      flex-direction: column;
    }
  }

  @media (max-width: 460px) {
    .brand-subtitle {
      display: none;
    }

    .brand-name {
      font-size: 12px;
    }

    .refresh-button {
      padding: 0 10px;
    }

    .mobile-info {
      grid-template-columns: 1fr;
    }

    .hero-metrics {
      justify-content: space-around;
    }
  }
`;

export default Dashboard;






