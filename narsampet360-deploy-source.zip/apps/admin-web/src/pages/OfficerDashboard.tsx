import {
  useEffect,
  useMemo,
  useState,
} from "react";
import { useNavigate } from "react-router-dom";
import client from "../api/client";
import Sidebar from "../components/Sidebar";

type Grievance = {
  id: string;
  title: string;
  status: string;
  priority?: string;

  citizenName?: string;
  citizenMobile?: string;

  village?: {
    name: string;
  };

  mandal?: {
    name: string;
  };

  department?: {
    name: string;
  };

  assignedTo?: {
    id?: string;
    _id?: string;
    name?: string;
    mobile?: string;
  };

  createdAt?: string;
};

type DashboardData = {
  total: number;
  pending: number;
  assigned: number;
  inProgress: number;
  resolved: number;
  rejected: number;
  closed: number;
};

const STATUS_META: Record<
  string,
  {
    label: string;
    bg: string;
    color: string;
    border: string;
    dot: string;
  }
> = {
  PENDING: {
    label: "Pending",
    bg: "#fff7ed",
    color: "#c2410c",
    border: "#fed7aa",
    dot: "#f97316",
  },

  ASSIGNED: {
    label: "Assigned",
    bg: "#eff6ff",
    color: "#1d4ed8",
    border: "#bfdbfe",
    dot: "#3b82f6",
  },

  IN_PROGRESS: {
    label: "In Progress",
    bg: "#ecfeff",
    color: "#0f766e",
    border: "#a5f3fc",
    dot: "#06b6d4",
  },

  RESOLVED: {
    label: "Resolved",
    bg: "#f0fdf4",
    color: "#15803d",
    border: "#bbf7d0",
    dot: "#22c55e",
  },

  REJECTED: {
    label: "Rejected",
    bg: "#fef2f2",
    color: "#b91c1c",
    border: "#fecaca",
    dot: "#ef4444",
  },

  CLOSED: {
    label: "Closed",
    bg: "#f8fafc",
    color: "#475569",
    border: "#e2e8f0",
    dot: "#64748b",
  },
};

const PRIORITY_META: Record<
  string,
  {
    bg: string;
    color: string;
    border: string;
  }
> = {
  HIGH: {
    bg: "#fef2f2",
    color: "#b91c1c",
    border: "#fecaca",
  },

  MEDIUM: {
    bg: "#fff7ed",
    color: "#c2410c",
    border: "#fed7aa",
  },

  LOW: {
    bg: "#f0fdf4",
    color: "#15803d",
    border: "#bbf7d0",
  },
};

function normalizeId(value: unknown): string {
  if (!value) return "";

  if (
    typeof value === "string" ||
    typeof value === "number"
  ) {
    return String(value).trim();
  }

  if (typeof value === "object") {
    const objectValue = value as any;

    return String(
      objectValue?.id ??
        objectValue?._id ??
        objectValue?.userId ??
        objectValue?.user?.id ??
        objectValue?.user?._id ??
        "",
    ).trim();
  }

  return "";
}

function getLoggedInUserId(): string {
  try {
    const directUserId =
      localStorage.getItem("userId");

    if (directUserId) {
      return directUserId.trim();
    }

    const rawUser =
      localStorage.getItem("user");

    if (!rawUser) {
      return "";
    }

    const user = JSON.parse(rawUser);

    return String(
      user?.id ??
        user?._id ??
        user?.userId ??
        user?.user?.id ??
        user?.user?._id ??
        "",
    ).trim();
  } catch {
    return "";
  }
}

function getOfficerName(): string {
  try {
    const rawUser =
      localStorage.getItem("user");

    if (!rawUser) {
      return "Officer";
    }

    const user = JSON.parse(rawUser);

    return (
      user?.name ||
      user?.fullName ||
      user?.user?.name ||
      "Officer"
    );
  } catch {
    return "Officer";
  }
}

function extractGrievances(
  response: any,
): Grievance[] {
  if (Array.isArray(response)) {
    return response;
  }

  if (Array.isArray(response?.data)) {
    return response.data;
  }

  if (Array.isArray(response?.data?.data)) {
    return response.data.data;
  }

  if (Array.isArray(response?.grievances)) {
    return response.grievances;
  }

  if (
    Array.isArray(
      response?.data?.grievances,
    )
  ) {
    return response.data.grievances;
  }

  if (
    Array.isArray(
      response?.data?.data?.grievances,
    )
  ) {
    return response.data.data.grievances;
  }

  return [];
}

function formatDate(value?: string) {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function getStatusMeta(status?: string) {
  const key =
    status?.toUpperCase() || "";

  return (
    STATUS_META[key] || {
      label: status || "Unknown",
      bg: "#f8fafc",
      color: "#475569",
      border: "#e2e8f0",
      dot: "#64748b",
    }
  );
}

function getPriorityMeta(priority?: string) {
  const key =
    priority?.toUpperCase() || "";

  return (
    PRIORITY_META[key] || {
      bg: "#f8fafc",
      color: "#475569",
      border: "#e2e8f0",
    }
  );
}

function StatIcon({
  type,
}: {
  type:
    | "total"
    | "assigned"
    | "progress"
    | "resolved"
    | "pending"
    | "rejected"
    | "closed";
}) {
  const common = {
    width: 21,
    height: 21,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };

  if (type === "total") {
    return (
      <svg {...common}>
        <rect
          x="4"
          y="3"
          width="16"
          height="18"
          rx="2"
        />
        <path d="M8 7h8M8 11h8M8 15h5" />
      </svg>
    );
  }

  if (type === "assigned") {
    return (
      <svg {...common}>
        <circle
          cx="9"
          cy="8"
          r="3"
        />
        <path d="M3.5 20a5.5 5.5 0 0 1 11 0" />
        <path d="m16 12 2 2 3.5-4" />
      </svg>
    );
  }

  if (type === "progress") {
    return (
      <svg {...common}>
        <circle
          cx="12"
          cy="12"
          r="8.5"
        />
        <path d="M12 7v5l3 2" />
      </svg>
    );
  }

  if (type === "resolved") {
    return (
      <svg {...common}>
        <circle
          cx="12"
          cy="12"
          r="8.5"
        />
        <path d="m8.5 12 2.3 2.3 4.8-5" />
      </svg>
    );
  }

  if (type === "pending") {
    return (
      <svg {...common}>
        <circle
          cx="12"
          cy="12"
          r="8.5"
        />
        <path d="M12 7v5l3 2" />
      </svg>
    );
  }

  if (type === "rejected") {
    return (
      <svg {...common}>
        <circle
          cx="12"
          cy="12"
          r="8.5"
        />
        <path d="m9 9 6 6M15 9l-6 6" />
      </svg>
    );
  }

  return (
    <svg {...common}>
      <path d="M5 5h14v14H5z" />
      <path d="m8 12 2.5 2.5L16 9" />
    </svg>
  );
}

function RefreshIcon() {
  return (
    <svg
      width="17"
      height="17"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 11a8 8 0 0 0-14.8-4L3 10" />
      <path d="M3 5v5h5" />
      <path d="M4 13a8 8 0 0 0 14.8 4L21 14" />
      <path d="M21 19v-5h-5" />
    </svg>
  );
}

function ArrowRightIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m13 6 6 6-6 6" />
    </svg>
  );
}

function BackIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  );
}

function UserIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle
        cx="12"
        cy="8"
        r="3.5"
      />
      <path d="M5 20a7 7 0 0 1 14 0" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M6.5 3.5h3l1.5 4-2 1.5a14 14 0 0 0 6 6l1.5-2 4 1.5v3c0 1.1-.9 2-2 2C10.5 19.5 4.5 13.5 4.5 6.5c0-1.1.9-2 2-2Z" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
      <circle
        cx="12"
        cy="10"
        r="2.5"
      />
    </svg>
  );
}

function BuildingIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 21V5l8-3 8 3v16" />
      <path d="M8 9h2M14 9h2M8 13h2M14 13h2M8 17h2M14 17h2" />
    </svg>
  );
}

export default function OfficerDashboard() {
  const navigate = useNavigate();

  const [grievances, setGrievances] =
    useState<Grievance[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [refreshing, setRefreshing] =
    useState(false);

  const [error, setError] =
    useState("");

  const [activeFilter, setActiveFilter] =
    useState<string>("ALL");

  const loadDashboard = async (
    isRefresh = false,
  ) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const response = await client.get(
        "/grievance",
      );

      const allGrievances =
        extractGrievances(
          response.data,
        );

      const currentOfficerId =
        getLoggedInUserId();

      if (!currentOfficerId) {
        setGrievances([]);
        return;
      }

      const myGrievances =
        allGrievances.filter(
          (grievance) => {
            const assignedId =
              normalizeId(
                grievance?.assignedTo,
              );

            return (
              assignedId ===
              currentOfficerId
            );
          },
        );

      setGrievances(myGrievances);
    } catch (err: any) {
      console.error(
        "OFFICER DASHBOARD ERROR:",
        err?.response?.data ||
          err?.message,
      );

      setError(
        err?.response?.data?.message ||
          "Failed to load officer dashboard",
      );

      setGrievances([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const dashboard: DashboardData =
    useMemo(() => {
      const counts: DashboardData = {
        total: grievances.length,
        pending: 0,
        assigned: 0,
        inProgress: 0,
        resolved: 0,
        rejected: 0,
        closed: 0,
      };

      grievances.forEach(
        (grievance) => {
          const status =
            grievance.status?.toUpperCase();

          if (status === "PENDING") {
            counts.pending++;
          }

          if (status === "ASSIGNED") {
            counts.assigned++;
          }

          if (
            status ===
            "IN_PROGRESS"
          ) {
            counts.inProgress++;
          }

          if (status === "RESOLVED") {
            counts.resolved++;
          }

          if (status === "REJECTED") {
            counts.rejected++;
          }

          if (status === "CLOSED") {
            counts.closed++;
          }
        },
      );

      return counts;
    }, [grievances]);

  const officerName = useMemo(
    () => getOfficerName(),
    [],
  );

  const resolutionRate =
    dashboard.total > 0
      ? Math.round(
          ((dashboard.resolved +
            dashboard.closed) /
            dashboard.total) *
            100,
        )
      : 0;

  const activeWorkload =
    dashboard.assigned +
    dashboard.inProgress;

  const completed =
    dashboard.resolved +
    dashboard.closed;

  const statusBreakdown =
    useMemo(() => {
      return [
        {
          key: "PENDING",
          label: "Pending",
          value: dashboard.pending,
        },
        {
          key: "ASSIGNED",
          label: "Assigned",
          value: dashboard.assigned,
        },
        {
          key: "IN_PROGRESS",
          label: "In Progress",
          value: dashboard.inProgress,
        },
        {
          key: "RESOLVED",
          label: "Resolved",
          value: dashboard.resolved,
        },
        {
          key: "REJECTED",
          label: "Rejected",
          value: dashboard.rejected,
        },
        {
          key: "CLOSED",
          label: "Closed",
          value: dashboard.closed,
        },
      ];
    }, [dashboard]);

  const recentGrievances =
    useMemo(() => {
      return [...grievances]
        .sort((a, b) => {
          const first = a.createdAt
            ? new Date(
                a.createdAt,
              ).getTime()
            : 0;

          const second = b.createdAt
            ? new Date(
                b.createdAt,
              ).getTime()
            : 0;

          return second - first;
        })
        .slice(0, 6);
    }, [grievances]);

  const filteredRecentGrievances =
    useMemo(() => {
      if (activeFilter === "ALL") {
        return recentGrievances;
      }

      return recentGrievances.filter(
        (item) =>
          item.status?.toUpperCase() ===
          activeFilter,
      );
    }, [
      recentGrievances,
      activeFilter,
    ]);

  function goToGrievances() {
    navigate("/grievances");
  }

  function filterAndView(
    status: string,
  ) {
    setActiveFilter(status);
  }

  function viewGrievance(
    grievanceId: string,
  ) {
    navigate(
      `/grievance/${encodeURIComponent(
        grievanceId,
      )}`,
    );
  }

  if (loading) {
    return (
      <div className="officer-layout">
        <Sidebar />

        <main className="officer-page">
          <div className="officer-shell">
            <div className="skeleton-header">
              <div>
                <div className="skeleton back-skeleton" />
                <div className="skeleton title-skeleton" />
                <div className="skeleton subtitle-skeleton" />
              </div>

              <div className="skeleton refresh-skeleton" />
            </div>

            <div className="skeleton-stats">
              {Array.from({
                length: 7,
              }).map((_, index) => (
                <div
                  className="skeleton skeleton-stat"
                  key={index}
                />
              ))}
            </div>

            <div className="skeleton-overview">
              <div className="skeleton skeleton-overview-card" />
              <div className="skeleton skeleton-overview-card" />
            </div>

            <div className="skeleton-main">
              {Array.from({
                length: 3,
              }).map((_, index) => (
                <div
                  className="skeleton skeleton-card"
                  key={index}
                />
              ))}
            </div>
          </div>
        </main>

        <style>{styles}</style>
      </div>
    );
  }

  if (error) {
    return (
      <div className="officer-layout">
        <Sidebar />

        <main className="officer-page">
          <div className="officer-shell">
            <button
              className="back-button"
              onClick={
                goToGrievances
              }
            >
              <BackIcon />
              Back to Grievances
            </button>

            <div className="error-card">
              <div className="error-icon">
                !
              </div>

              <div>
                <h2>
                  Unable to load dashboard
                </h2>

                <p>{error}</p>

                <button
                  className="primary-button"
                  onClick={() =>
                    loadDashboard()
                  }
                >
                  Try Again
                </button>
              </div>
            </div>
          </div>
        </main>

        <style>{styles}</style>
      </div>
    );
  }

  return (
    <div className="officer-layout">
      <Sidebar />

      <main className="officer-page">
        <div className="officer-shell">
          <header className="top-header">
            <div className="brand-area">
              <div className="brand-mark">
                N360
              </div>

              <div>
                <div className="brand-name">
                  NARSAMPET360
                </div>

                <div className="brand-subtitle">
                  Officer Workspace
                </div>
              </div>
            </div>

            <div className="header-right">
              <div className="header-user">
                <div className="user-avatar">
                  {officerName
                    .charAt(0)
                    .toUpperCase()}
                </div>

                <div>
                  <strong>
                    {officerName}
                  </strong>

                  <span>
                    Officer
                  </span>
                </div>
              </div>

              <div className="header-live">
                <span className="live-dot" />
                Live
              </div>
            </div>
          </header>

          <section className="hero">
            <div className="hero-left">
              <button
                className="back-button"
                onClick={
                  goToGrievances
                }
              >
                <BackIcon />
                Back to Grievances
              </button>

              <div className="eyebrow">
                OFFICER OVERVIEW
              </div>

              <h1>
                Welcome back,{" "}
                <span>
                  {officerName}
                </span>
              </h1>

              <p>
                Manage your assigned citizen
                grievances, monitor progress
                and keep every case moving
                toward resolution.
              </p>
            </div>

            <button
              className="refresh-button"
              onClick={() =>
                loadDashboard(true)
              }
              disabled={refreshing}
            >
              <span
                className={
                  refreshing
                    ? "spin"
                    : ""
                }
              >
                <RefreshIcon />
              </span>

              {refreshing
                ? "Refreshing..."
                : "Refresh"}
            </button>
          </section>

          <section className="stats-grid">
            {[
              {
                key: "total",
                label: "Total",
                value: dashboard.total,
                icon: "total" as const,
                tone: "blue",
                filter: "ALL",
              },
              {
                key: "assigned",
                label: "Assigned",
                value: dashboard.assigned,
                icon: "assigned" as const,
                tone: "indigo",
                filter: "ASSIGNED",
              },
              {
                key: "progress",
                label: "In Progress",
                value: dashboard.inProgress,
                icon: "progress" as const,
                tone: "cyan",
                filter: "IN_PROGRESS",
              },
              {
                key: "resolved",
                label: "Resolved",
                value: dashboard.resolved,
                icon: "resolved" as const,
                tone: "green",
                filter: "RESOLVED",
              },
              {
                key: "pending",
                label: "Pending",
                value: dashboard.pending,
                icon: "pending" as const,
                tone: "orange",
                filter: "PENDING",
              },
              {
                key: "rejected",
                label: "Rejected",
                value: dashboard.rejected,
                icon: "rejected" as const,
                tone: "red",
                filter: "REJECTED",
              },
              {
                key: "closed",
                label: "Closed",
                value: dashboard.closed,
                icon: "closed" as const,
                tone: "slate",
                filter: "CLOSED",
              },
            ].map((stat) => (
              <button
                className={`stat-card ${
                  activeFilter ===
                  stat.filter
                    ? "active"
                    : ""
                }`}
                key={stat.key}
                onClick={() =>
                  filterAndView(
                    stat.filter,
                  )
                }
              >
                <div className="stat-top">
                  <div
                    className={`stat-icon ${stat.tone}`}
                  >
                    <StatIcon
                      type={stat.icon}
                    />
                  </div>

                  <span className="stat-label">
                    {stat.label}
                  </span>
                </div>

                <div className="stat-value">
                  {stat.value}
                </div>

                <span className="stat-hint">
                  Click to filter
                </span>
              </button>
            ))}
          </section>

          <section className="overview-grid">
            <div className="panel performance-panel">
              <div className="panel-header">
                <div>
                  <div className="panel-eyebrow">
                    PERFORMANCE
                  </div>

                  <h2>
                    Case Resolution
                  </h2>

                  <p className="panel-description">
                    Overall completion
                    performance of your
                    assigned workload.
                  </p>
                </div>

                <div className="rate-circle">
                  <strong>
                    {resolutionRate}%
                  </strong>

                  <span>
                    completed
                  </span>
                </div>
              </div>

              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{
                    width: `${Math.min(
                      resolutionRate,
                      100,
                    )}%`,
                  }}
                />
              </div>

              <div className="performance-footer">
                <div>
                  <strong>
                    {activeWorkload}
                  </strong>

                  <span>
                    Active workload
                  </span>
                </div>

                <div>
                  <strong>
                    {completed}
                  </strong>

                  <span>
                    Completed
                  </span>
                </div>

                <div>
                  <strong>
                    {dashboard.total}
                  </strong>

                  <span>
                    Total assigned
                  </span>
                </div>
              </div>
            </div>

            <div className="panel">
              <div className="panel-header compact">
                <div>
                  <div className="panel-eyebrow">
                    STATUS
                  </div>

                  <h2>
                    Grievance Overview
                  </h2>
                </div>
              </div>

              <div className="status-list">
                {statusBreakdown.map(
                  (item) => {
                    const meta =
                      getStatusMeta(
                        item.key,
                      );

                    const percentage =
                      dashboard.total >
                      0
                        ? Math.round(
                            (item.value /
                              dashboard.total) *
                              100,
                          )
                        : 0;

                    return (
                      <button
                        className={`status-row ${
                          activeFilter ===
                          item.key
                            ? "selected"
                            : ""
                        }`}
                        key={item.key}
                        onClick={() =>
                          filterAndView(
                            item.key,
                          )
                        }
                      >
                        <div className="status-name">
                          <span
                            className="status-dot"
                            style={{
                              background:
                                meta.dot,
                            }}
                          />

                          {item.label}
                        </div>

                        <div className="status-bar">
                          <div
                            className="status-bar-fill"
                            style={{
                              width: `${percentage}%`,
                              background:
                                meta.dot,
                            }}
                          />
                        </div>

                        <strong>
                          {item.value}
                        </strong>
                      </button>
                    );
                  },
                )}
              </div>
            </div>
          </section>

          <section className="grievances-section">
            <div className="section-heading">
              <div>
                <div className="panel-eyebrow">
                  WORK QUEUE
                </div>

                <div className="title-row">
                  <h2>
                    My Assigned Grievances
                  </h2>

                  <span className="case-count">
                    {filteredRecentGrievances.length}
                  </span>
                </div>

                <p>
                  Latest citizen complaints
                  currently assigned to you.
                </p>
              </div>

              <div className="section-actions">
                {activeFilter !==
                  "ALL" && (
                  <button
                    className="clear-filter"
                    onClick={() =>
                      setActiveFilter(
                        "ALL",
                      )
                    }
                  >
                    Clear filter
                  </button>
                )}

                <button
                  className="outline-button"
                  onClick={
                    goToGrievances
                  }
                >
                  View All Grievances
                  <ArrowRightIcon />
                </button>
              </div>
            </div>

            {filteredRecentGrievances.length ===
            0 ? (
              <div className="empty-card">
                <div className="empty-icon">
                  ✓
                </div>

                <div>
                  <h3>
                    {activeFilter ===
                    "ALL"
                      ? "No grievances assigned"
                      : "No cases in this status"}
                  </h3>

                  <p>
                    {activeFilter ===
                    "ALL"
                      ? "You currently have no grievances assigned to your account."
                      : "There are no assigned grievances matching this status."}
                  </p>

                  <button
                    className="primary-button"
                    onClick={
                      activeFilter ===
                      "ALL"
                        ? goToGrievances
                        : () =>
                            setActiveFilter(
                              "ALL",
                            )
                    }
                  >
                    {activeFilter ===
                    "ALL"
                      ? "View Grievance Register"
                      : "Show All Cases"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="grievance-grid">
                {filteredRecentGrievances.map(
                  (grievance) => {
                    const status =
                      getStatusMeta(
                        grievance.status,
                      );

                    const priority =
                      getPriorityMeta(
                        grievance.priority,
                      );

                    return (
                      <article
                        className="grievance-card"
                        key={
                          grievance.id
                        }
                      >
                        <div className="card-top">
                          <div className="case-number">
                            CASE #
                            {String(
                              grievance.id,
                            ).slice(-8)}
                          </div>

                          <span
                            className="status-badge"
                            style={{
                              background:
                                status.bg,
                              color:
                                status.color,
                              borderColor:
                                status.border,
                            }}
                          >
                            <span
                              className="badge-dot"
                              style={{
                                background:
                                  status.dot,
                              }}
                            />

                            {status.label}
                          </span>
                        </div>

                        <h3 className="grievance-title">
                          {grievance.title ||
                            "Untitled Grievance"}
                        </h3>

                        <div className="meta-grid">
                          <div className="meta-item">
                            <span className="meta-icon">
                              <UserIcon />
                            </span>

                            <div>
                              <span>
                                Citizen
                              </span>

                              <strong>
                                {grievance.citizenName ||
                                  "-"}
                              </strong>
                            </div>
                          </div>

                          <div className="meta-item">
                            <span className="meta-icon">
                              <PhoneIcon />
                            </span>

                            <div>
                              <span>
                                Mobile
                              </span>

                              <strong>
                                {grievance.citizenMobile ||
                                  "-"}
                              </strong>
                            </div>
                          </div>
                        </div>

                        <div className="detail-line">
                          <span>
                            <LocationIcon />
                          </span>

                          <div>
                            <strong>
                              Location
                            </strong>

                            <p>
                              {grievance
                                .village
                                ?.name ||
                                "-"}

                              {grievance
                                .mandal
                                ?.name
                                ? ` • ${grievance.mandal.name}`
                                : ""}
                            </p>
                          </div>
                        </div>

                        <div className="detail-line">
                          <span>
                            <BuildingIcon />
                          </span>

                          <div>
                            <strong>
                              Department
                            </strong>

                            <p>
                              {grievance
                                .department
                                ?.name ||
                                "-"}
                            </p>
                          </div>
                        </div>

                        <div className="card-footer-info">
                          <div>
                            <span>
                              Priority
                            </span>

                            <b
                              className="priority-badge"
                              style={{
                                background:
                                  priority.bg,
                                color:
                                  priority.color,
                                borderColor:
                                  priority.border,
                              }}
                            >
                              {grievance.priority?.toUpperCase() ||
                                "MEDIUM"}
                            </b>
                          </div>

                          <div className="assigned-officer">
                            <span>
                              Assigned To
                            </span>

                            <strong>
                              {grievance
                                .assignedTo
                                ?.name ||
                                officerName}
                            </strong>
                          </div>
                        </div>

                        <div className="card-bottom">
                          <span className="registered-date">
                            Registered{" "}
                            {formatDate(
                              grievance.createdAt,
                            )}
                          </span>

                          <button
                            className="view-button"
                            onClick={() =>
                              viewGrievance(
                                grievance.id,
                              )
                            }
                          >
                            View Grievance
                            <ArrowRightIcon />
                          </button>
                        </div>
                      </article>
                    );
                  },
                )}
              </div>
            )}
          </section>

          <footer className="footer">
            <div>
              <strong>
                Narsampet360
              </strong>

              <span>
                Citizen Grievance Management
              </span>
            </div>

            <span>
              Officer Workspace
            </span>
          </footer>
        </div>
      </main>

      <style>{styles}</style>
    </div>
  );
}

const styles = `
  * {
    box-sizing: border-box;
  }

  .officer-layout {
    min-height: 100vh;
    background: #f6f8fc;
  }

  .officer-page {
    min-height: 100vh;
    margin-left: 220px;
    background:
      radial-gradient(
        circle at top right,
        rgba(37, 99, 235, 0.08),
        transparent 28%
      ),
      #f6f8fc;
    color: #0f172a;
    font-family:
      Inter,
      ui-sans-serif,
      system-ui,
      -apple-system,
      BlinkMacSystemFont,
      "Segoe UI",
      sans-serif;
    overflow-x: hidden;
  }

  .officer-shell {
    width: min(1440px, calc(100% - 40px));
    margin: 0 auto;
    padding: 22px 0 35px;
  }

  .top-header {
    min-height: 68px;
    padding: 0 22px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    border-radius: 18px;
    background:
      linear-gradient(
        135deg,
        #0f4cbd 0%,
        #2563eb 52%,
        #1d4ed8 100%
      );
    box-shadow:
      0 14px 35px rgba(30, 64, 175, 0.18);
    color: #fff;
  }

  .brand-area {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
  }

  .brand-mark {
    width: 43px;
    height: 43px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid rgba(255,255,255,0.28);
    border-radius: 12px;
    background: rgba(255,255,255,0.14);
    font-size: 12px;
    font-weight: 900;
    letter-spacing: -0.4px;
  }

  .brand-name {
    font-size: 14px;
    font-weight: 900;
    letter-spacing: 1.2px;
  }

  .brand-subtitle {
    margin-top: 2px;
    color: rgba(255,255,255,0.72);
    font-size: 11px;
    font-weight: 600;
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 14px;
  }

  .header-user {
    display: flex;
    align-items: center;
    gap: 9px;
  }

  .header-user strong {
    display: block;
    font-size: 11px;
    font-weight: 800;
  }

  .header-user span {
    display: block;
    margin-top: 2px;
    color: rgba(255,255,255,0.68);
    font-size: 9px;
  }

  .user-avatar {
    width: 35px;
    height: 35px;
    display: grid;
    place-items: center;
    border: 1px solid rgba(255,255,255,0.25);
    border-radius: 50%;
    background: rgba(255,255,255,0.15);
    font-size: 13px;
    font-weight: 900;
  }

  .header-live {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 999px;
    background: rgba(255,255,255,0.11);
    color: rgba(255,255,255,0.92);
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
  }

  .live-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #86efac;
    box-shadow:
      0 0 0 4px rgba(134,239,172,0.13);
  }

  .hero {
    margin-top: 25px;
    padding: 28px 30px;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 25px;
    border: 1px solid #dbe5f4;
    border-radius: 22px;
    background:
      linear-gradient(
        135deg,
        #ffffff 0%,
        #f8fbff 100%
      );
    box-shadow:
      0 8px 28px rgba(15,23,42,0.05);
  }

  .hero-left {
    min-width: 0;
  }

  .back-button {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 20px;
    padding: 0;
    border: none;
    background: transparent;
    color: #2563eb;
    cursor: pointer;
    font-size: 13px;
    font-weight: 800;
  }

  .back-button:hover {
    color: #1d4ed8;
  }

  .eyebrow,
  .panel-eyebrow {
    color: #2563eb;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.6px;
  }

  .hero h1 {
    margin: 7px 0 7px;
    color: #0f172a;
    font-size: clamp(27px, 3vw, 40px);
    line-height: 1.1;
    letter-spacing: -1.2px;
  }

  .hero h1 span {
    color: #2563eb;
  }

  .hero p {
    max-width: 680px;
    margin: 0;
    color: #64748b;
    font-size: 14px;
    line-height: 1.65;
  }

  .refresh-button,
  .primary-button,
  .outline-button,
  .view-button,
  .clear-filter {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    font-family: inherit;
    font-weight: 800;
    transition:
      transform 0.18s ease,
      box-shadow 0.18s ease,
      background 0.18s ease,
      border-color 0.18s ease;
  }

  .refresh-button {
    min-width: 112px;
    padding: 11px 16px;
    border: 1px solid #d8e1ee;
    border-radius: 11px;
    background: #fff;
    color: #1e3a8a;
    box-shadow:
      0 4px 14px rgba(15,23,42,0.05);
  }

  .refresh-button:hover:not(:disabled) {
    transform: translateY(-1px);
    border-color: #bfdbfe;
    box-shadow:
      0 7px 18px rgba(37,99,235,0.12);
  }

  .refresh-button:disabled {
    cursor: not-allowed;
    opacity: 0.7;
  }

  .spin {
    display: inline-flex;
    animation:
      spin 0.9s linear infinite;
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  .stats-grid {
    display: grid;
    grid-template-columns:
      repeat(7, minmax(0, 1fr));
    gap: 12px;
    margin-top: 16px;
  }

  .stat-card {
    min-width: 0;
    padding: 17px;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    background: #fff;
    box-shadow:
      0 5px 18px rgba(15,23,42,0.04);
    text-align: left;
    cursor: pointer;
    font-family: inherit;
    transition:
      transform 0.18s ease,
      box-shadow 0.18s ease,
      border-color 0.18s ease,
      background 0.18s ease;
  }

  .stat-card:hover {
    transform: translateY(-2px);
    border-color: #c9dafa;
    box-shadow:
      0 12px 28px rgba(15,23,42,0.08);
  }

  .stat-card.active {
    border-color: #93c5fd;
    background: #f8fbff;
    box-shadow:
      0 0 0 3px rgba(37,99,235,0.08),
      0 12px 28px rgba(37,99,235,0.08);
  }

  .stat-top {
    display: flex;
    align-items: center;
    gap: 9px;
  }

  .stat-icon {
    width: 35px;
    height: 35px;
    display: grid;
    place-items: center;
    border-radius: 10px;
  }

  .stat-icon.blue {
    background: #eff6ff;
    color: #2563eb;
  }

  .stat-icon.indigo {
    background: #eef2ff;
    color: #4f46e5;
  }

  .stat-icon.cyan {
    background: #ecfeff;
    color: #0891b2;
  }

  .stat-icon.green {
    background: #f0fdf4;
    color: #16a34a;
  }

  .stat-icon.orange {
    background: #fff7ed;
    color: #ea580c;
  }

  .stat-icon.red {
    background: #fef2f2;
    color: #dc2626;
  }

  .stat-icon.slate {
    background: #f8fafc;
    color: #475569;
  }

  .stat-label {
    min-width: 0;
    color: #64748b;
    font-size: 11px;
    font-weight: 800;
    line-height: 1.2;
  }

  .stat-value {
    margin-top: 14px;
    color: #0f172a;
    font-size: 29px;
    font-weight: 900;
    letter-spacing: -0.8px;
  }

  .stat-hint {
    display: block;
    margin-top: 4px;
    color: #cbd5e1;
    font-size: 8px;
    font-weight: 700;
  }

  .overview-grid {
    display: grid;
    grid-template-columns:
      minmax(0, 1.15fr)
      minmax(0, 0.85fr);
    gap: 16px;
    margin-top: 16px;
  }

  .panel {
    min-width: 0;
    padding: 23px;
    border: 1px solid #e2e8f0;
    border-radius: 19px;
    background: #fff;
    box-shadow:
      0 6px 22px rgba(15,23,42,0.04);
  }

  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
  }

  .panel-header.compact {
    margin-bottom: 18px;
  }

  .panel h2,
  .section-heading h2 {
    margin: 5px 0 0;
    color: #0f172a;
    font-size: 19px;
    letter-spacing: -0.3px;
  }

  .panel-description {
    margin: 6px 0 0;
    color: #94a3b8;
    font-size: 11px;
    line-height: 1.5;
  }

  .rate-circle {
    min-width: 76px;
    padding: 10px;
    border: 1px solid #dcfce7;
    border-radius: 14px;
    background: #f0fdf4;
    text-align: center;
  }

  .rate-circle strong {
    display: block;
    color: #16a34a;
    font-size: 22px;
    line-height: 1;
  }

  .rate-circle span {
    display: block;
    margin-top: 4px;
    color: #65a30d;
    font-size: 8px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .progress-track {
    height: 9px;
    margin-top: 24px;
    overflow: hidden;
    border-radius: 999px;
    background: #e8eef7;
  }

  .progress-fill {
    height: 100%;
    border-radius: inherit;
    background:
      linear-gradient(
        90deg,
        #2563eb,
        #22c55e
      );
    transition: width 0.45s ease;
  }

  .performance-footer {
    display: grid;
    grid-template-columns:
      repeat(3, minmax(0, 1fr));
    gap: 12px;
    margin-top: 21px;
  }

  .performance-footer > div {
    padding: 12px;
    border: 1px solid #edf2f7;
    border-radius: 12px;
    background: #f8fafc;
  }

  .performance-footer strong {
    display: block;
    color: #0f172a;
    font-size: 19px;
  }

  .performance-footer span {
    display: block;
    margin-top: 3px;
    color: #64748b;
    font-size: 10px;
    font-weight: 700;
  }

  .status-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .status-row {
    width: 100%;
    display: grid;
    grid-template-columns:
      105px minmax(70px, 1fr) 30px;
    align-items: center;
    gap: 10px;
    padding: 7px 5px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: transparent;
    cursor: pointer;
    font-family: inherit;
    text-align: left;
    transition:
      background 0.18s ease,
      border-color 0.18s ease;
  }

  .status-row:hover,
  .status-row.selected {
    border-color: #e2e8f0;
    background: #f8fafc;
  }

  .status-name {
    display: flex;
    align-items: center;
    gap: 7px;
    color: #475569;
    font-size: 11px;
    font-weight: 700;
  }

  .status-dot {
    width: 7px;
    height: 7px;
    flex: 0 0 auto;
    border-radius: 50%;
  }

  .status-bar {
    height: 6px;
    overflow: hidden;
    border-radius: 999px;
    background: #edf2f7;
  }

  .status-bar-fill {
    height: 100%;
    border-radius: inherit;
    transition: width 0.4s ease;
  }

  .status-row strong {
    color: #0f172a;
    font-size: 12px;
    text-align: right;
  }

  .grievances-section {
    margin-top: 26px;
  }

  .section-heading {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 15px;
  }

  .section-heading p {
    margin: 5px 0 0;
    color: #64748b;
    font-size: 12px;
  }

  .title-row {
    display: flex;
    align-items: center;
    gap: 9px;
  }

  .case-count {
    min-width: 25px;
    height: 22px;
    display: inline-grid;
    place-items: center;
    padding: 0 7px;
    border-radius: 999px;
    background: #eff6ff;
    color: #2563eb;
    font-size: 10px;
    font-weight: 900;
  }

  .section-actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .clear-filter {
    padding: 10px 12px;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #fff;
    color: #64748b;
    font-size: 11px;
  }

  .clear-filter:hover {
    border-color: #cbd5e1;
    background: #f8fafc;
  }

  .outline-button {
    padding: 10px 14px;
    border: 1px solid #d7e0ec;
    border-radius: 10px;
    background: #fff;
    color: #1d4ed8;
    font-size: 12px;
  }

  .outline-button:hover {
    transform: translateY(-1px);
    border-color: #bfdbfe;
    background: #eff6ff;
  }

  .grievance-grid {
    display: grid;
    grid-template-columns:
      repeat(3, minmax(0, 1fr));
    gap: 15px;
  }

  .grievance-card {
    min-width: 0;
    padding: 19px;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    background: #fff;
    box-shadow:
      0 6px 22px rgba(15,23,42,0.04);
    transition:
      transform 0.18s ease,
      border-color 0.18s ease,
      box-shadow 0.18s ease;
  }

  .grievance-card:hover {
    transform: translateY(-3px);
    border-color: #c9dafa;
    box-shadow:
      0 15px 32px rgba(15,23,42,0.08);
  }

  .card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .case-number {
    color: #94a3b8;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 1px;
  }

  .status-badge,
  .priority-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
    border: 1px solid;
    font-weight: 800;
  }

  .status-badge {
    padding: 5px 8px;
    border-radius: 999px;
    font-size: 9px;
  }

  .badge-dot {
    width: 5px;
    height: 5px;
    border-radius: 50%;
  }

  .grievance-title {
    min-height: 42px;
    margin: 13px 0 16px;
    color: #111827;
    font-size: 15px;
    line-height: 1.4;
    overflow-wrap: anywhere;
  }

  .meta-grid {
    display: grid;
    grid-template-columns:
      repeat(2, minmax(0, 1fr));
    gap: 9px;
    margin-bottom: 13px;
  }

  .meta-item {
    min-width: 0;
    display: flex;
    align-items: flex-start;
    gap: 8px;
    padding: 10px;
    border: 1px solid #edf2f7;
    border-radius: 11px;
    background: #f8fafc;
  }

  .meta-icon {
    display: flex;
    color: #2563eb;
    margin-top: 1px;
  }

  .meta-item > div {
    min-width: 0;
  }

  .meta-item span:not(.meta-icon) {
    display: block;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
  }

  .meta-item strong {
    display: block;
    margin-top: 2px;
    color: #334155;
    font-size: 11px;
    overflow-wrap: anywhere;
  }

  .detail-line {
    display: flex;
    align-items: flex-start;
    gap: 9px;
    padding: 10px 0;
    border-bottom: 1px solid #f1f5f9;
  }

  .detail-line > span {
    display: flex;
    margin-top: 1px;
    color: #64748b;
  }

  .detail-line strong {
    display: block;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .detail-line p {
    margin: 2px 0 0;
    color: #475569;
    font-size: 11px;
    font-weight: 700;
    overflow-wrap: anywhere;
  }

  .card-footer-info {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 15px;
    margin-top: 13px;
  }

  .card-footer-info > div > span,
  .assigned-officer > span {
    display: block;
    margin-bottom: 5px;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }

  .priority-badge {
    padding: 4px 8px;
    border-radius: 7px;
    font-size: 9px;
  }

  .assigned-officer {
    min-width: 0;
    text-align: right;
  }

  .assigned-officer strong {
    display: block;
    max-width: 130px;
    color: #334155;
    font-size: 11px;
    overflow-wrap: anywhere;
  }

  .card-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-top: 16px;
    padding-top: 14px;
    border-top: 1px solid #edf2f7;
  }

  .registered-date {
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
  }

  .view-button {
    padding: 8px 11px;
    border: none;
    border-radius: 9px;
    background: #2563eb;
    color: #fff;
    font-size: 10px;
  }

  .view-button:hover {
    transform: translateY(-1px);
    background: #1d4ed8;
    box-shadow:
      0 6px 14px rgba(37,99,235,0.22);
  }

  .empty-card,
  .error-card {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 28px;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    background: #fff;
  }

  .empty-icon,
  .error-icon {
    width: 44px;
    height: 44px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border-radius: 13px;
    font-size: 18px;
    font-weight: 900;
  }

  .empty-icon {
    background: #f0fdf4;
    color: #16a34a;
  }

  .error-icon {
    background: #fef2f2;
    color: #dc2626;
  }

  .empty-card h3,
  .error-card h2 {
    margin: 0;
    color: #0f172a;
    font-size: 16px;
  }

  .empty-card p,
  .error-card p {
    margin: 4px 0 12px;
    color: #64748b;
    font-size: 12px;
  }

  .primary-button {
    padding: 10px 14px;
    border: none;
    border-radius: 9px;
    background: #2563eb;
    color: #fff;
    font-size: 11px;
  }

  .primary-button:hover {
    transform: translateY(-1px);
    background: #1d4ed8;
  }

  .footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-top: 28px;
    padding: 18px 3px 5px;
    border-top: 1px solid #e2e8f0;
    color: #94a3b8;
    font-size: 10px;
  }

  .footer div {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .footer strong {
    color: #64748b;
    font-size: 11px;
  }

  .skeleton {
    position: relative;
    overflow: hidden;
    background: #e7edf5;
    border-radius: 10px;
  }

  .skeleton::after {
    content: "";
    position: absolute;
    inset: 0;
    transform: translateX(-100%);
    background:
      linear-gradient(
        90deg,
        transparent,
        rgba(255,255,255,0.65),
        transparent
      );
    animation:
      shimmer 1.25s infinite;
  }

  @keyframes shimmer {
    100% {
      transform: translateX(100%);
    }
  }

  .skeleton-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
    min-height: 180px;
    padding: 30px;
    border: 1px solid #e2e8f0;
    border-radius: 22px;
    background: #fff;
  }

  .back-skeleton {
    width: 145px;
    height: 14px;
    margin-bottom: 24px;
  }

  .title-skeleton {
    width: min(420px, 70vw);
    height: 35px;
    margin-bottom: 12px;
  }

  .subtitle-skeleton {
    width: min(600px, 75vw);
    height: 15px;
  }

  .refresh-skeleton {
    width: 105px;
    height: 40px;
  }

  .skeleton-stats {
    display: grid;
    grid-template-columns:
      repeat(7, minmax(0, 1fr));
    gap: 12px;
    margin-top: 16px;
  }

  .skeleton-stat {
    height: 110px;
    border-radius: 16px;
  }

  .skeleton-overview {
    display: grid;
    grid-template-columns:
      repeat(2, minmax(0, 1fr));
    gap: 16px;
    margin-top: 16px;
  }

  .skeleton-overview-card {
    height: 245px;
    border-radius: 19px;
  }

  .skeleton-main {
    display: grid;
    grid-template-columns:
      repeat(3, minmax(0, 1fr));
    gap: 15px;
    margin-top: 26px;
  }

  .skeleton-card {
    height: 330px;
    border-radius: 18px;
  }

  @media (max-width: 1250px) {
    .stats-grid {
      grid-template-columns:
        repeat(4, minmax(0, 1fr));
    }

    .skeleton-stats {
      grid-template-columns:
        repeat(4, minmax(0, 1fr));
    }

    .grievance-grid {
      grid-template-columns:
        repeat(2, minmax(0, 1fr));
    }

    .skeleton-main {
      grid-template-columns:
        repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 980px) {
    .officer-page {
      margin-left: 0;
    }

    .overview-grid {
      grid-template-columns: 1fr;
    }

    .hero {
      align-items: flex-start;
      flex-direction: column;
    }

    .refresh-button {
      width: 100%;
    }
  }

  @media (max-width: 680px) {
    .officer-shell {
      width: min(100% - 20px, 620px);
      padding-top: 10px;
    }

    .top-header {
      padding: 12px 14px;
      border-radius: 15px;
    }

    .header-right {
      gap: 8px;
    }

    .header-user > div:last-child {
      display: none;
    }

    .header-live {
      padding: 7px 9px;
    }

    .hero {
      margin-top: 13px;
      padding: 21px;
      border-radius: 17px;
    }

    .hero h1 {
      font-size: 27px;
    }

    .stats-grid {
      grid-template-columns:
        repeat(2, minmax(0, 1fr));
    }

    .stats-grid .stat-card:first-child {
      grid-column: span 2;
    }

    .skeleton-stats {
      grid-template-columns:
        repeat(2, minmax(0, 1fr));
    }

    .skeleton-overview {
      grid-template-columns: 1fr;
    }

    .skeleton-main {
      grid-template-columns: 1fr;
    }

    .panel {
      padding: 18px;
      border-radius: 16px;
    }

    .performance-footer {
      grid-template-columns: 1fr;
    }

    .status-row {
      grid-template-columns:
        92px minmax(45px, 1fr) 25px;
    }

    .section-heading {
      align-items: stretch;
      flex-direction: column;
    }

    .section-actions {
      align-items: stretch;
      flex-direction: column;
    }

    .clear-filter,
    .outline-button {
      width: 100%;
    }

    .grievance-grid {
      grid-template-columns: 1fr;
    }

    .empty-card,
    .error-card {
      align-items: flex-start;
      flex-direction: column;
    }

    .footer {
      align-items: flex-start;
      flex-direction: column;
    }
  }

  @media (max-width: 420px) {
    .officer-shell {
      width: calc(100% - 14px);
    }

    .top-header {
      min-height: 60px;
    }

    .brand-name {
      font-size: 12px;
    }

    .brand-subtitle {
      font-size: 9px;
    }

    .brand-mark {
      width: 38px;
      height: 38px;
    }

    .hero {
      padding: 18px;
    }

    .stats-grid {
      gap: 8px;
    }

    .stat-card {
      padding: 13px;
    }

    .stat-value {
      font-size: 25px;
    }

    .meta-grid {
      grid-template-columns: 1fr;
    }

    .card-footer-info {
      align-items: flex-start;
      flex-direction: column;
    }

    .assigned-officer {
      text-align: left;
    }

    .assigned-officer strong {
      max-width: 100%;
    }

    .card-bottom {
      align-items: stretch;
      flex-direction: column;
    }

    .view-button {
      width: 100%;
    }
  }
`;