import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import client from "../api/client";


export default function UserDetails(){

const { id } = useParams();

const navigate = useNavigate();

const [user,setUser]=useState<any>(null);



async function loadUser(){

try{

const res =
await client.get(`/users/${id}`);

setUser(res.data);


}catch(err:any){

}

}



useEffect(()=>{

if(id){

loadUser();

}

},[id]);





if(!user){

return(

<div style={{padding:40}}>

<h3>
Loading user details...
</h3>

</div>

);

}





return(

<div style={{padding:40}}>


<button

onClick={()=>navigate("/users")}

style={{

padding:"10px 20px",

cursor:"pointer"

}}

>

← Back

</button>




<h1>
User Details
</h1>



<hr/>



<p>
<b>Name:</b> {user.name}
</p>



<p>
<b>Mobile:</b> {user.mobile}
</p>



<p>
<b>Email:</b> {user.email || "-"}
</p>



<p>
<b>Role:</b> {user.role}
</p>



<p>
<b>Status:</b>

{" "}

{
user.isActive
?
"Active"
:
"Inactive"
}

</p>



<p>
<b>Department:</b>

{" "}

{
user.department?.name || "-"
}

</p>



<p>
<b>Constituency:</b>

{" "}

{
user.constituency?.name || "-"
}

</p>



<p>
<b>Mandal:</b>

{" "}

{
user.mandal?.name || "-"
}

</p>



<p>
<b>Village:</b>

{" "}

{
user.village?.name || "-"
}

</p>



<p>
<b>Created Date:</b>

{" "}

{
new Date(
user.createdAt
).toLocaleString()
}

</p>


<hr/>

<h2>
Actions
</h2>

<button
onClick={()=>{
navigate(`/user/${user.id}/edit`);
}}
style={{
padding:"10px 20px",
marginRight:10,
cursor:"pointer"
}}
>
Edit User
</button>
<button
onClick={async()=>{

if(!window.confirm("Deactivate this user?"))
return;

try{

await client.delete(`/users/${user.id}`);

alert("User deactivated successfully");

navigate("/users");

}catch(err:any){

alert(
err.response?.data?.message ||
"Deactivate failed"
);

}

}}
style={{
padding:"10px 20px",
cursor:"pointer"
}}
>
Deactivate User
</button>

</div>

);

}