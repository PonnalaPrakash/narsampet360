import { useEffect, useMemo, useState } from "react";
import client from "../api/client";

export default function Constituency() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [districtFilter, setDistrictFilter] =
    useState("");
  const [stateFilter, setStateFilter] =
    useState("");

  async function load() {
    try {
      setLoading(true);

      const res = await client.get(
        "/constituencies"
      );

      setData(
        Array.isArray(res.data)
          ? res.data
          : Array.isArray(res.data?.data)
          ? res.data.data
          : []
      );
    } catch (err: any) {

      setData([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const districts = useMemo(() => {
    return Array.from(
      new Set(
        data
          .map((c) => c.district)
          .filter(Boolean)
      )
    ).sort();
  }, [data]);

  const states = useMemo(() => {
    return Array.from(
      new Set(
        data
          .map((c) => c.state)
          .filter(Boolean)
      )
    ).sort();
  }, [data]);

  const filteredData = useMemo(() => {
    const query = search
      .trim()
      .toLowerCase();

    return data.filter((c) => {
      const name = String(
        c.name || ""
      ).toLowerCase();

      const district = String(
        c.district || ""
      ).toLowerCase();

      const state = String(
        c.state || ""
      ).toLowerCase();

      const mlaName = String(
        c.mlaName || ""
      ).toLowerCase();

      const matchesSearch =
        !query ||
        name.includes(query) ||
        district.includes(query) ||
        state.includes(query) ||
        mlaName.includes(query);

      const matchesDistrict =
        !districtFilter ||
        String(c.district || "") ===
          districtFilter;

      const matchesState =
        !stateFilter ||
        String(c.state || "") ===
          stateFilter;

      return (
        matchesSearch &&
        matchesDistrict &&
        matchesState
      );
    });
  }, [
    data,
    search,
    districtFilter,
    stateFilter,
  ]);

  function clearFilters() {
    setSearch("");
    setDistrictFilter("");
    setStateFilter("");
  }

  function formatDate(value: any) {
    if (!value) {
      return "-";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return "-";
    }

    return date.toLocaleDateString();
  }

  return (
    <div className="constituency-page">
      <style>{`
        * {
          box-sizing: border-box;
        }

        .constituency-page {
          min-height: 100vh;
          background: #f5f7fb;
          color: #172033;
          padding-bottom: 40px;
        }

        .constituency-header {
          background: linear-gradient(
            135deg,
            #0d47a1 0%,
            #1565c0 45%,
            #1976d2 100%
          );
          color: white;
          padding: 30px 40px;
          position: relative;
          overflow: hidden;
        }

        .constituency-header::after {
          content: "";
          position: absolute;
          width: 280px;
          height: 280px;
          border-radius: 50%;
          background: rgba(255,255,255,0.07);
          right: -90px;
          top: -120px;
        }

        .header-inner {
          max-width: 1500px;
          margin: 0 auto;
          position: relative;
          z-index: 1;
        }

        .brand-title {
          margin: 0;
          font-size: 30px;
          font-weight: 800;
          letter-spacing: -0.5px;
        }

        .brand-subtitle {
          margin: 7px 0 0;
          color: rgba(255,255,255,0.82);
          font-size: 14px;
        }

        .content {
          max-width: 1500px;
          margin: 0 auto;
          padding: 28px 40px;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 18px;
          margin-bottom: 26px;
        }

        .stat-card {
          background: white;
          border: 1px solid #e6eaf0;
          border-radius: 16px;
          padding: 20px;
          box-shadow: 0 5px 18px rgba(20,35,60,0.05);
          transition: all 0.2s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 9px 25px rgba(20,35,60,0.08);
        }

        .stat-label {
          color: #687386;
          font-size: 13px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .stat-value {
          margin-top: 7px;
          font-size: 28px;
          font-weight: 800;
          color: #172033;
        }

        .section-card {
          background: white;
          border: 1px solid #e5e9f0;
          border-radius: 18px;
          box-shadow: 0 7px 24px rgba(20,35,60,0.05);
          overflow: hidden;
        }

        .section-header {
          padding: 20px 22px;
          border-bottom: 1px solid #edf0f4;
        }

        .section-title {
          margin: 0;
          font-size: 19px;
          font-weight: 800;
        }

        .section-description {
          margin: 5px 0 0;
          font-size: 13px;
          color: #7a8494;
        }

        .filters {
          padding: 20px 22px;
          background: #fbfcfe;
          border-bottom: 1px solid #edf0f4;
        }

        .filter-grid {
          display: grid;
          grid-template-columns: 1.5fr 1fr 1fr auto;
          gap: 12px;
          align-items: end;
        }

        .field {
          display: flex;
          flex-direction: column;
          gap: 7px;
        }

        .field label {
          font-size: 12px;
          font-weight: 700;
          color: #4e596b;
        }

        .input,
        .select {
          width: 100%;
          height: 46px;
          border: 1px solid #dce2ea;
          border-radius: 10px;
          background: white;
          padding: 0 13px;
          font-size: 14px;
          color: #172033;
          outline: none;
          transition: all 0.2s ease;
        }

        .input:focus,
        .select:focus {
          border-color: #1976d2;
          box-shadow: 0 0 0 3px rgba(25,118,210,0.10);
        }

        .clear-btn {
          height: 46px;
          padding: 0 17px;
          border: 1px solid #d9e0e9;
          border-radius: 10px;
          background: white;
          color: #455166;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .clear-btn:hover {
          background: #f1f4f8;
        }

        .table-wrap {
          width: 100%;
          overflow-x: auto;
        }

        .constituency-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          min-width: 850px;
        }

        .constituency-table th {
          background: #f8fafc;
          color: #667085;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          font-weight: 800;
          text-align: left;
          padding: 15px 20px;
          border-bottom: 1px solid #e7ebf0;
          white-space: nowrap;
        }

        .constituency-table td {
          padding: 17px 20px;
          border-bottom: 1px solid #edf0f4;
          font-size: 14px;
          vertical-align: middle;
        }

        .constituency-table tbody tr {
          transition: background 0.18s ease;
        }

        .constituency-table tbody tr:hover {
          background: #f8fbff;
        }

        .constituency-name {
          font-weight: 800;
          color: #172033;
        }

        .constituency-id {
          color: #9aa3b1;
          font-size: 11px;
          margin-top: 4px;
          word-break: break-all;
        }

        .district-text,
        .state-text {
          color: #4d596b;
          font-weight: 600;
        }

        .mla-badge {
          display: inline-flex;
          align-items: center;
          padding: 7px 11px;
          border-radius: 9px;
          background: #eef5ff;
          color: #155db5;
          font-size: 12px;
          font-weight: 800;
        }

        .no-mla {
          color: #9aa3b1;
        }

        .date-text {
          color: #687386;
          font-weight: 600;
          white-space: nowrap;
        }

        .empty-state,
        .loading-state {
          padding: 55px 20px;
          text-align: center;
          color: #7b8493;
        }

        .empty-icon {
          font-size: 34px;
          margin-bottom: 8px;
        }

        .mobile-list {
          display: none;
        }

        .mobile-card {
          border: 1px solid #e7ebf0;
          border-radius: 14px;
          padding: 17px;
          background: white;
          margin-bottom: 12px;
        }

        .mobile-card:last-child {
          margin-bottom: 0;
        }

        .mobile-name {
          font-size: 17px;
          font-weight: 800;
          color: #172033;
        }

        .mobile-id {
          color: #9aa3b1;
          font-size: 11px;
          margin-top: 4px;
          word-break: break-all;
        }

        .mobile-row {
          display: flex;
          justify-content: space-between;
          gap: 15px;
          padding: 11px 0;
          border-bottom: 1px solid #f0f2f5;
          font-size: 13px;
        }

        .mobile-row:last-child {
          border-bottom: none;
        }

        .mobile-label {
          color: #8992a0;
          font-weight: 700;
        }

        .mobile-value {
          color: #344054;
          font-weight: 700;
          text-align: right;
        }

        @media (max-width: 1000px) {
          .content {
            padding: 24px;
          }

          .constituency-header {
            padding: 26px 24px;
          }

          .filter-grid {
            grid-template-columns: 1fr 1fr;
          }

          .clear-btn {
            width: 100%;
          }
        }

        @media (max-width: 680px) {
          .constituency-header {
            padding: 22px 16px;
          }

          .content {
            padding: 18px 14px;
          }

          .brand-title {
            font-size: 24px;
          }

          .brand-subtitle {
            font-size: 12px;
          }

          .stats-grid {
            grid-template-columns: 1fr;
            gap: 10px;
          }

          .stat-card {
            padding: 15px;
          }

          .stat-value {
            font-size: 24px;
          }

          .section-card {
            border-radius: 15px;
          }

          .section-header {
            padding: 17px;
          }

          .filters {
            padding: 17px;
          }

          .filter-grid {
            grid-template-columns: 1fr;
          }

          .table-wrap {
            display: none;
          }

          .mobile-list {
            display: block;
            padding: 15px;
          }
        }
      `}</style>

      {/* Premium Header */}
      <header className="constituency-header">
        <div className="header-inner">
          <h1 className="brand-title">
            Narsampet360
          </h1>

          <p className="brand-subtitle">
            Constituency Management
          </p>
        </div>
      </header>

      <main className="content">
        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-label">
              Total Constituencies
            </div>

            <div className="stat-value">
              {data.length}
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">
              Districts
            </div>

            <div className="stat-value">
              {districts.length}
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">
              States
            </div>

            <div className="stat-value">
              {states.length}
            </div>
          </div>
        </div>

        {/* Constituency List */}
        <section className="section-card">
          <div className="section-header">
            <h2 className="section-title">
              Constituencies
            </h2>

            <p className="section-description">
              View and manage constituency
              information.
            </p>
          </div>

          {/* Filters */}
          <div className="filters">
            <div className="filter-grid">
              <div className="field">
                <label>
                  Search
                </label>

                <input
                  className="input"
                  placeholder="Search constituency, district, state or MLA..."
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                />
              </div>

              <div className="field">
                <label>
                  District
                </label>

                <select
                  className="select"
                  value={districtFilter}
                  onChange={(e) =>
                    setDistrictFilter(
                      e.target.value
                    )
                  }
                >
                  <option value="">
                    All Districts
                  </option>

                  {districts.map(
                    (district: any) => (
                      <option
                        key={district}
                        value={district}
                      >
                        {district}
                      </option>
                    )
                  )}
                </select>
              </div>

              <div className="field">
                <label>
                  State
                </label>

                <select
                  className="select"
                  value={stateFilter}
                  onChange={(e) =>
                    setStateFilter(
                      e.target.value
                    )
                  }
                >
                  <option value="">
                    All States
                  </option>

                  {states.map(
                    (state: any) => (
                      <option
                        key={state}
                        value={state}
                      >
                        {state}
                      </option>
                    )
                  )}
                </select>
              </div>

              <button
                className="clear-btn"
                onClick={clearFilters}
              >
                Clear Filters
              </button>
            </div>
          </div>

          {/* Loading */}
          {loading ? (
            <div className="loading-state">
              <h3>
                Loading constituencies...
              </h3>

              <p>
                Please wait while constituency
                data is being loaded.
              </p>
            </div>
          ) : filteredData.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">
                🗺️
              </div>

              <h3>
                No constituencies found
              </h3>

              <p>
                Try changing your search or
                filters.
              </p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="table-wrap">
                <table className="constituency-table">
                  <thead>
                    <tr>
                      <th>
                        Constituency
                      </th>

                      <th>
                        District
                      </th>

                      <th>
                        State
                      </th>

                      <th>
                        MLA Name
                      </th>

                      <th>
                        Created
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredData.map(
                      (c) => (
                        <tr key={c.id}>
                          <td>
                            <div className="constituency-name">
                              {c.name}
                            </div>

                            <div className="constituency-id">
                              ID: {c.id}
                            </div>
                          </td>

                          <td>
                            <span className="district-text">
                              {c.district ||
                                "-"}
                            </span>
                          </td>

                          <td>
                            <span className="state-text">
                              {c.state ||
                                "-"}
                            </span>
                          </td>

                          <td>
                            {c.mlaName ? (
                              <span className="mla-badge">
                                {c.mlaName}
                              </span>
                            ) : (
                              <span className="no-mla">
                                -
                              </span>
                            )}
                          </td>

                          <td>
                            <span className="date-text">
                              {formatDate(
                                c.createdAt
                              )}
                            </span>
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="mobile-list">
                {filteredData.map(
                  (c) => (
                    <div
                      className="mobile-card"
                      key={c.id}
                    >
                      <div className="mobile-name">
                        {c.name}
                      </div>

                      <div className="mobile-id">
                        ID: {c.id}
                      </div>

                      <div className="mobile-row">
                        <span className="mobile-label">
                          District
                        </span>

                        <span className="mobile-value">
                          {c.district ||
                            "-"}
                        </span>
                      </div>

                      <div className="mobile-row">
                        <span className="mobile-label">
                          State
                        </span>

                        <span className="mobile-value">
                          {c.state ||
                            "-"}
                        </span>
                      </div>

                      <div className="mobile-row">
                        <span className="mobile-label">
                          MLA
                        </span>

                        <span className="mobile-value">
                          {c.mlaName ||
                            "-"}
                        </span>
                      </div>

                      <div className="mobile-row">
                        <span className="mobile-label">
                          Created
                        </span>

                        <span className="mobile-value">
                          {formatDate(
                            c.createdAt
                          )}
                        </span>
                      </div>
                    </div>
                  )
                )}
              </div>
            </>
          )}
        </section>
      </main>
    </div>
  );
}