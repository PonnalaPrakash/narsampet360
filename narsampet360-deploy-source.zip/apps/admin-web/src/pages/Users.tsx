
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import client from "../api/client";

type User = {
  id: string | number;
  name?: string;
  mobile?: string;
  email?: string;
  role?: string;
  department?: {
    name?: string;
  };
  isActive?: boolean;
};

const ROLE_OPTIONS = [
  "ALL",
  "ADMIN",
  "MLA",
  "PA",
  "OFFICER",
  "VILLAGE_COORDINATOR",
  "MANDAL_INCHARGE",
];

const STATUS_OPTIONS = [
  "ALL",
  "ACTIVE",
  "INACTIVE",
];

const getRoleLabel = (role?: string) => {
  if (!role) return "-";

  return role
    .toString()
    .replace(/_/g, " ")
    .toUpperCase();
};

const getRoleClass = (role?: string) => {
  switch (role?.toUpperCase()) {
    case "ADMIN":
      return "role-admin";

    case "MLA":
      return "role-mla";

    case "PA":
      return "role-pa";

    case "OFFICER":
      return "role-officer";

    case "VILLAGE_COORDINATOR":
      return "role-coordinator";

    case "MANDAL_INCHARGE":
      return "role-mandal";

    default:
      return "role-default";
  }
};

export default function Users() {
  const navigate = useNavigate();

  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [departmentFilter, setDepartmentFilter] =
    useState("ALL");
  const [statusFilter, setStatusFilter] =
    useState("ALL");

  const [actionLoading, setActionLoading] =
    useState<string | number | null>(null);

  // ============================================================
  // LOAD USERS
  // ============================================================

  async function loadUsers(
    customSearch?: string,
    customRole?: string,
    customStatus?: string
  ) {
    try {
      setLoading(true);

      const currentSearch =
        customSearch !== undefined
          ? customSearch
          : search;

      const currentRole =
        customRole !== undefined
          ? customRole
          : roleFilter;

      const currentStatus =
        customStatus !== undefined
          ? customStatus
          : statusFilter;

      const params = {
        page: 1,
        limit: 50,

        search:
          currentSearch.trim() || undefined,

        role:
          currentRole !== "ALL"
            ? currentRole
            : undefined,

        status:
          currentStatus !== "ALL"
            ? currentStatus
            : undefined,
      };

      const res = await client.get(
        "/users",
        {
          params,
        }
      );

      const data =
        res.data?.data ??
        res.data ??
        [];

      setUsers(
        Array.isArray(data)
          ? data
          : []
      );
    } catch (err: any) {

      setUsers([]);

      alert(
        err.response?.data?.message ||
          "Failed to load users."
      );
    } finally {
      setLoading(false);
    }
  }

  // ============================================================
  // INITIAL LOAD + ROLE / STATUS FILTER CHANGE
  // ============================================================

  useEffect(() => {
    loadUsers();
  }, [
    roleFilter,
    statusFilter,
  ]);

  // ============================================================
  // SEARCH
  // ============================================================

  function handleSearch() {
    loadUsers(
      search,
      roleFilter,
      statusFilter
    );
  }

  // ============================================================
  // FILTER CHANGE
  // ============================================================

  function handleRoleChange(
    value: string
  ) {
    setRoleFilter(value);
  }

  function handleStatusChange(
    value: string
  ) {
    setStatusFilter(value);
  }

  // ============================================================
  // DEPARTMENTS
  // ============================================================

  const departments = useMemo(() => {
    const values = users
      .map(
        (user) =>
          user.department?.name
      )
      .filter(Boolean) as string[];

    return [
      "ALL",
      ...Array.from(
        new Set(values)
      ),
    ];
  }, [users]);

  // ============================================================
  // LOCAL DEPARTMENT FILTER
  // ============================================================

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const matchesDepartment =
        departmentFilter === "ALL" ||
        user.department?.name ===
          departmentFilter;

      return matchesDepartment;
    });
  }, [
    users,
    departmentFilter,
  ]);

  // ============================================================
  // STATS
  // ============================================================

  const totalUsers =
    users.length;

  const activeUsers =
    users.filter(
      (user) =>
        user.isActive === true
    ).length;

  const officerUsers =
    users.filter((user) =>
      [
        "OFFICER",
        "MLA",
        "PA",
      ].includes(
        user.role?.toUpperCase() ||
          ""
      )
    ).length;

  const coordinatorUsers =
    users.filter(
      (user) =>
        user.role?.toUpperCase() ===
        "VILLAGE_COORDINATOR"
    ).length;

  // ============================================================
  // CLEAR FILTERS
  // ============================================================

  const clearFilters = () => {
    setSearch("");
    setRoleFilter("ALL");
    setDepartmentFilter("ALL");
    setStatusFilter("ALL");

    /*
     * Explicit reload is important.
     * Otherwise, if role/status were already ALL,
     * useEffect may not run again.
     */

    loadUsers(
      "",
      "ALL",
      "ALL"
    );
  };

  // ============================================================
  // ACTIVATE / DEACTIVATE
  // ============================================================

  async function toggleUserStatus(
    user: User
  ) {
    const nextStatus =
      !user.isActive;

    const actionText =
      nextStatus
        ? "activate"
        : "deactivate";

    const confirmed =
      window.confirm(
        `Are you sure you want to ${actionText} ${
          user.name ||
          "this user"
        }?`
      );

    if (!confirmed) {
      return;
    }

    try {
      setActionLoading(user.id);

      await client.patch(
        `/users/${user.id}/status`,
        {
          isActive: nextStatus,
        }
      );

      alert(
        nextStatus
          ? "User activated successfully."
          : "User deactivated successfully."
      );

      /*
       * Reload using the CURRENT filters.
       * This means:
       *
       * ALL      -> Active + Inactive
       * ACTIVE   -> Only Active
       * INACTIVE -> Only Inactive
       */

      await loadUsers(
        search,
        roleFilter,
        statusFilter
      );
    } catch (err: any) {

      alert(
        err.response?.data?.message ||
          `Unable to ${actionText} user.`
      );
    } finally {
      setActionLoading(null);
    }
  }

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        .users-page {
          min-height: 100vh;
          background:
            radial-gradient(circle at top right, rgba(37, 99, 235, 0.08), transparent 28%),
            #f6f8fc;
          padding: 28px;
          color: #172033;
        }

        .users-container {
          width: 100%;
          max-width: 1500px;
          margin: 0 auto;
        }

        .premium-header {
          position: relative;
          overflow: hidden;
          border-radius: 22px;
          padding: 28px 30px;
          margin-bottom: 22px;
          background:
            linear-gradient(135deg, #0f3d91 0%, #1556c0 48%, #1976d2 100%);
          box-shadow: 0 16px 40px rgba(15, 61, 145, 0.18);
          color: white;
        }

        .premium-header::after {
          content: "";
          position: absolute;
          width: 240px;
          height: 240px;
          right: -80px;
          top: -120px;
          border-radius: 50%;
          background: rgba(255,255,255,0.08);
        }

        .header-content {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
        }

        .brand-section {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .brand-icon {
          width: 54px;
          height: 54px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 16px;
          background: rgba(255,255,255,0.16);
          border: 1px solid rgba(255,255,255,0.2);
          font-size: 25px;
          font-weight: 800;
        }

        .brand-title {
          margin: 0;
          font-size: 25px;
          font-weight: 800;
          letter-spacing: -0.5px;
        }

        .brand-subtitle {
          margin: 5px 0 0;
          color: rgba(255,255,255,0.78);
          font-size: 13px;
        }

        .add-user-btn {
          border: 0;
          border-radius: 12px;
          padding: 12px 18px;
          background: white;
          color: #1556c0;
          font-size: 14px;
          font-weight: 800;
          cursor: pointer;
          box-shadow: 0 8px 20px rgba(0,0,0,0.12);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          white-space: nowrap;
        }

        .add-user-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 24px rgba(0,0,0,0.16);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }

        .stat-card {
          background: white;
          border: 1px solid #e5eaf2;
          border-radius: 17px;
          padding: 19px;
          box-shadow: 0 6px 18px rgba(25, 40, 70, 0.05);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px rgba(25, 40, 70, 0.08);
        }

        .stat-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        .stat-label {
          color: #68758a;
          font-size: 13px;
          font-weight: 700;
        }

        .stat-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eef4ff;
          color: #1556c0;
          font-size: 17px;
          font-weight: 800;
        }

        .stat-value {
          margin-top: 9px;
          font-size: 28px;
          line-height: 1;
          font-weight: 800;
          color: #172033;
        }

        .toolbar-card {
          background: white;
          border: 1px solid #e3e8f0;
          border-radius: 18px;
          padding: 18px;
          margin-bottom: 20px;
          box-shadow: 0 6px 18px rgba(25, 40, 70, 0.04);
        }

        .search-row {
          display: flex;
          gap: 10px;
          align-items: stretch;
        }

        .search-box {
          position: relative;
          flex: 1;
        }

        .search-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #8a95a8;
          font-size: 17px;
          pointer-events: none;
        }

        .search-input {
          width: 100%;
          height: 46px;
          border: 1px solid #dce2eb;
          border-radius: 11px;
          padding: 0 14px 0 42px;
          outline: none;
          color: #172033;
          background: #fbfcfe;
          font-size: 14px;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .search-input:focus {
          border-color: #3478dc;
          box-shadow: 0 0 0 3px rgba(52, 120, 220, 0.1);
          background: white;
        }

        .search-btn {
          height: 46px;
          padding: 0 22px;
          border: 0;
          border-radius: 11px;
          background: #1556c0;
          color: white;
          font-weight: 800;
          cursor: pointer;
          transition: background 0.2s ease, transform 0.2s ease;
        }

        .search-btn:hover {
          background: #10479f;
          transform: translateY(-1px);
        }

        .search-btn:disabled {
          opacity: 0.65;
          cursor: not-allowed;
          transform: none;
        }

        .filters-row {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr)) auto;
          gap: 10px;
          margin-top: 12px;
        }

        .filter-select {
          height: 43px;
          width: 100%;
          border: 1px solid #dce2eb;
          border-radius: 10px;
          padding: 0 12px;
          background: #fbfcfe;
          color: #344054;
          outline: none;
          font-size: 13px;
          cursor: pointer;
        }

        .filter-select:focus {
          border-color: #3478dc;
        }

        .clear-btn {
          height: 43px;
          padding: 0 16px;
          border: 1px solid #dce2eb;
          border-radius: 10px;
          background: white;
          color: #526071;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        .clear-btn:hover {
          background: #f7f9fc;
        }

        .table-card {
          background: white;
          border: 1px solid #e3e8f0;
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 7px 22px rgba(25, 40, 70, 0.05);
        }

        .table-header {
          padding: 17px 20px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          border-bottom: 1px solid #edf0f5;
        }

        .table-title {
          margin: 0;
          font-size: 16px;
          font-weight: 800;
        }

        .result-count {
          color: #7a8495;
          font-size: 12px;
          font-weight: 700;
        }

        .table-wrapper {
          width: 100%;
          overflow-x: auto;
        }

        table {
          width: 100%;
          min-width: 1050px;
          border-collapse: separate;
          border-spacing: 0;
        }

        th {
          padding: 13px 18px;
          text-align: left;
          background: #f8faff;
          color: #697586;
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom: 1px solid #e8edf4;
          white-space: nowrap;
        }

        td {
          padding: 15px 18px;
          border-bottom: 1px solid #edf0f4;
          color: #344054;
          font-size: 13px;
          vertical-align: middle;
        }

        tbody tr {
          cursor: pointer;
          transition: background 0.18s ease;
        }

        tbody tr:hover {
          background: #f8fbff;
        }

        tbody tr:last-child td {
          border-bottom: 0;
        }

        .user-cell {
          display: flex;
          align-items: center;
          gap: 11px;
          min-width: 180px;
        }

        .avatar {
          width: 38px;
          height: 38px;
          min-width: 38px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #eaf1ff;
          color: #1556c0;
          font-size: 14px;
          font-weight: 800;
          border: 1px solid #d8e5ff;
        }

        .user-name {
          color: #172033;
          font-weight: 800;
          line-height: 1.2;
        }

        .user-id {
          margin-top: 3px;
          color: #929baa;
          font-size: 10px;
        }

        .role-badge {
          display: inline-flex;
          align-items: center;
          min-height: 26px;
          padding: 4px 9px;
          border-radius: 7px;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.3px;
          white-space: nowrap;
        }

        .role-admin {
          background: #f0e9ff;
          color: #7042bd;
        }

        .role-mla {
          background: #fff1dc;
          color: #b56b00;
        }

        .role-pa {
          background: #e8f5ff;
          color: #1769aa;
        }

        .role-officer {
          background: #e9f8ef;
          color: #197544;
        }

        .role-coordinator {
          background: #eaf1ff;
          color: #2857a4;
        }

        .role-mandal {
          background: #fff0e6;
          color: #a84d00;
        }

        .role-default {
          background: #f0f2f5;
          color: #596273;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 800;
        }

        .status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
        }

        .status-active {
          color: #198754;
        }

        .status-active .status-dot {
          background: #20a464;
          box-shadow: 0 0 0 3px rgba(32, 164, 100, 0.1);
        }

        .status-inactive {
          color: #8a94a5;
        }

        .status-inactive .status-dot {
          background: #9aa3b1;
        }

        .action-cell {
          text-align: right;
          white-space: nowrap;
        }

        .action-btn {
          border: 1px solid #dce2eb;
          background: white;
          color: #3e4b5e;
          border-radius: 8px;
          padding: 7px 10px;
          margin-left: 6px;
          cursor: pointer;
          font-size: 11px;
          font-weight: 800;
          transition: all 0.18s ease;
        }

        .action-btn:hover {
          background: #f1f6ff;
          border-color: #b9cdf1;
          color: #1556c0;
        }

        .action-btn.status-action {
          color: #198754;
          border-color: #cfe8da;
        }

        .action-btn.status-action:hover {
          background: #effaf3;
          border-color: #a8d8b9;
          color: #146c43;
        }

        .action-btn.deactivate-action {
          color: #b42318;
          border-color: #f1c8c5;
        }

        .action-btn.deactivate-action:hover {
          background: #fff5f4;
          border-color: #e8a7a2;
          color: #912018;
        }

        .action-btn:disabled {
          opacity: 0.55;
          cursor: not-allowed;
          transform: none;
        }

        .empty-state,
        .loading-state {
          padding: 55px 20px;
          text-align: center;
          color: #758094;
        }

        .empty-icon {
          width: 48px;
          height: 48px;
          margin: 0 auto 12px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f4f8;
          color: #8a95a8;
          font-size: 20px;
        }

        .empty-title {
          margin: 0;
          color: #344054;
          font-size: 15px;
          font-weight: 800;
        }

        .empty-text {
          margin: 6px 0 0;
          font-size: 12px;
        }

        .mobile-cards {
          display: none;
        }

        .mobile-user-card {
          border-bottom: 1px solid #edf0f4;
          padding: 16px;
          cursor: pointer;
          transition: background 0.18s ease;
        }

        .mobile-user-card:last-child {
          border-bottom: 0;
        }

        .mobile-user-card:hover {
          background: #f8fbff;
        }

        .mobile-card-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
        }

        .mobile-details {
          margin-top: 13px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 11px;
        }

        .mobile-detail-label {
          display: block;
          margin-bottom: 3px;
          color: #8a94a5;
          font-size: 9px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.4px;
        }

        .mobile-detail-value {
          color: #344054;
          font-size: 12px;
          word-break: break-word;
        }

        .mobile-actions {
          display: flex;
          flex-wrap: wrap;
          gap: 7px;
          margin-top: 14px;
        }

        .mobile-actions .action-btn {
          margin-left: 0;
        }

        @media (max-width: 1000px) {
          .stats-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .filters-row {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .clear-btn {
            width: 100%;
          }
        }

        @media (max-width: 700px) {
          .users-page {
            padding: 14px;
          }

          .premium-header {
            padding: 20px;
            border-radius: 17px;
          }

          .header-content {
            align-items: flex-start;
          }

          .brand-title {
            font-size: 20px;
          }

          .brand-subtitle {
            font-size: 11px;
          }

          .brand-icon {
            width: 45px;
            height: 45px;
            font-size: 20px;
          }

          .add-user-btn {
            padding: 10px 12px;
            font-size: 12px;
          }

          .stats-grid {
            gap: 10px;
          }

          .stat-card {
            padding: 14px;
            border-radius: 14px;
          }

          .stat-value {
            font-size: 23px;
          }

          .stat-label {
            font-size: 11px;
          }

          .toolbar-card,
          .table-card {
            border-radius: 14px;
          }

          .search-row {
            flex-direction: column;
          }

          .search-btn {
            width: 100%;
          }

          .filters-row {
            grid-template-columns: 1fr;
          }

          .table-wrapper {
            display: none;
          }

          .mobile-cards {
            display: block;
          }

          .table-header {
            padding: 14px 16px;
          }
        }

        @media (max-width: 430px) {
          .header-content {
            flex-direction: column;
          }

          .add-user-btn {
            width: 100%;
          }

          .stats-grid {
            grid-template-columns: 1fr 1fr;
          }

          .mobile-details {
            grid-template-columns: 1fr;
          }
        }
      `}</style>

      <div className="users-page">
        <div className="users-container">

          {/* ================================================== */}
          {/* HEADER */}
          {/* ================================================== */}

          <section className="premium-header">
            <div className="header-content">

              <div className="brand-section">

                <div className="brand-icon">
                  N
                </div>

                <div>

                  <h1 className="brand-title">
                    Narsampet360
                  </h1>

                  <p className="brand-subtitle">
                    User Management • Administration Portal
                  </p>

                </div>

              </div>

              <button
                className="add-user-btn"
                onClick={() => {
                  navigate("/users/create");
                }}
              >
                + Add User
              </button>

            </div>
          </section>

          {/* ================================================== */}
          {/* STATS */}
          {/* ================================================== */}

          <section className="stats-grid">

            <div className="stat-card">

              <div className="stat-top">

                <span className="stat-label">
                  Total Users
                </span>

                <div className="stat-icon">
                  👥
                </div>

              </div>

              <div className="stat-value">
                {totalUsers}
              </div>

            </div>

            <div className="stat-card">

              <div className="stat-top">

                <span className="stat-label">
                  Active Users
                </span>

                <div className="stat-icon">
                  ✓
                </div>

              </div>

              <div className="stat-value">
                {activeUsers}
              </div>

            </div>

            <div className="stat-card">

              <div className="stat-top">

                <span className="stat-label">
                  Officers
                </span>

                <div className="stat-icon">
                  ★
                </div>

              </div>

              <div className="stat-value">
                {officerUsers}
              </div>

            </div>

            <div className="stat-card">

              <div className="stat-top">

                <span className="stat-label">
                  Coordinators
                </span>

                <div className="stat-icon">
                  ⌂
                </div>

              </div>

              <div className="stat-value">
                {coordinatorUsers}
              </div>

            </div>

          </section>

          {/* ================================================== */}
          {/* TOOLBAR */}
          {/* ================================================== */}

          <section className="toolbar-card">

            <div className="search-row">

              <div className="search-box">

                <span className="search-icon">
                  🔎
                </span>

                <input
                  className="search-input"
                  type="text"
                  placeholder="Search name, mobile or email..."
                  value={search}
                  onChange={(e) =>
                    setSearch(
                      e.target.value
                    )
                  }
                  onKeyDown={(e) => {

                    if (
                      e.key === "Enter"
                    ) {
                      handleSearch();
                    }

                  }}
                />

              </div>

              <button
                className="search-btn"
                onClick={handleSearch}
                disabled={loading}
              >
                {loading
                  ? "Loading..."
                  : "Search"}
              </button>

            </div>

            <div className="filters-row">

              {/* ROLE */}

              <select
                className="filter-select"
                value={roleFilter}
                onChange={(e) =>
                  handleRoleChange(
                    e.target.value
                  )
                }
              >

                {ROLE_OPTIONS.map(
                  (role) => (

                    <option
                      key={role}
                      value={role}
                    >
                      {role === "ALL"
                        ? "All Roles"
                        : getRoleLabel(role)}
                    </option>

                  )
                )}

              </select>

              {/* DEPARTMENT */}

              <select
                className="filter-select"
                value={departmentFilter}
                onChange={(e) =>
                  setDepartmentFilter(
                    e.target.value
                  )
                }
              >

                {departments.map(
                  (department) => (

                    <option
                      key={department}
                      value={department}
                    >
                      {department === "ALL"
                        ? "All Departments"
                        : department}
                    </option>

                  )
                )}

              </select>

              {/* STATUS */}

              <select
                className="filter-select"
                value={statusFilter}
                onChange={(e) =>
                  handleStatusChange(
                    e.target.value
                  )
                }
              >

                {STATUS_OPTIONS.map(
                  (status) => (

                    <option
                      key={status}
                      value={status}
                    >
                      {status === "ALL"
                        ? "All Status"
                        : status === "ACTIVE"
                        ? "Active"
                        : "Inactive"}
                    </option>

                  )
                )}

              </select>

              {/* CLEAR */}

              <button
                className="clear-btn"
                onClick={clearFilters}
              >
                Clear Filters
              </button>

            </div>

          </section>

          {/* ================================================== */}
          {/* TABLE */}
          {/* ================================================== */}

          <section className="table-card">

            <div className="table-header">

              <h2 className="table-title">
                Users
              </h2>

              <span className="result-count">
                {filteredUsers.length} result
                {filteredUsers.length !== 1
                  ? "s"
                  : ""}
              </span>

            </div>

            {loading ? (

              <div className="loading-state">
                Loading users...
              </div>

            ) : filteredUsers.length ===
              0 ? (

              <div className="empty-state">

                <div className="empty-icon">
                  👤
                </div>

                <p className="empty-title">
                  No users found
                </p>

                <p className="empty-text">
                  Try changing your search or filters.
                </p>

              </div>

            ) : (

              <>

                {/* ================================================== */}
                {/* DESKTOP TABLE */}
                {/* ================================================== */}

                <div className="table-wrapper">

                  <table>

                    <thead>

                      <tr>

                        <th>
                          Name
                        </th>

                        <th>
                          Mobile
                        </th>

                        <th>
                          Email
                        </th>

                        <th>
                          Role
                        </th>

                        <th>
                          Department
                        </th>

                        <th>
                          Status
                        </th>

                        <th>
                          Actions
                        </th>

                      </tr>

                    </thead>

                    <tbody>

                      {filteredUsers.map(
                        (user) => (

                          <tr
                            key={user.id}
                            onClick={() => {

                              navigate(
                                `/user/${user.id}`
                              );

                            }}
                          >

                            {/* NAME */}

                            <td>

                              <div className="user-cell">

                                <div className="avatar">

                                  {(user.name ||
                                    "U")
                                    .trim()
                                    .charAt(0)
                                    .toUpperCase()}

                                </div>

                                <div>

                                  <div className="user-name">
                                    {user.name ||
                                      "Unnamed User"}
                                  </div>

                                  <div className="user-id">
                                    ID: {user.id}
                                  </div>

                                </div>

                              </div>

                            </td>

                            {/* MOBILE */}

                            <td>
                              {user.mobile ||
                                "-"}
                            </td>

                            {/* EMAIL */}

                            <td>
                              {user.email ||
                                "-"}
                            </td>

                            {/* ROLE */}

                            <td>

                              <span
                                className={`role-badge ${getRoleClass(
                                  user.role
                                )}`}
                              >
                                {getRoleLabel(
                                  user.role
                                )}
                              </span>

                            </td>

                            {/* DEPARTMENT */}

                            <td>
                              {user.department
                                ?.name ||
                                "-"}
                            </td>

                            {/* STATUS */}

                            <td>

                              <span
                                className={`status-badge ${
                                  user.isActive
                                    ? "status-active"
                                    : "status-inactive"
                                }`}
                              >

                                <span className="status-dot" />

                                {user.isActive
                                  ? "Active"
                                  : "Inactive"}

                              </span>

                            </td>

                            {/* ACTIONS */}

                            <td
                              className="action-cell"
                              onClick={(e) =>
                                e.stopPropagation()
                              }
                            >

                              <button
                                className="action-btn"
                                onClick={() => {

                                  navigate(
                                    `/user/${user.id}`
                                  );

                                }}
                              >
                                👁 View
                              </button>

                              <button
                                className="action-btn"
                                onClick={() => {

                                  navigate(
                                    `/user/${user.id}/edit`
                                  );

                                }}
                              >
                                ✎ Edit
                              </button>

                              <button
                                disabled={
                                  actionLoading ===
                                  user.id
                                }
                                className={`action-btn ${
                                  user.isActive
                                    ? "deactivate-action"
                                    : "status-action"
                                }`}
                                onClick={() =>
                                  toggleUserStatus(
                                    user
                                  )
                                }
                              >

                                {actionLoading ===
                                user.id
                                  ? "..."
                                  : user.isActive
                                  ? "Deactivate"
                                  : "Activate"}

                              </button>

                            </td>

                          </tr>

                        )
                      )}

                    </tbody>

                  </table>

                </div>

                {/* ================================================== */}
                {/* MOBILE CARDS */}
                {/* ================================================== */}

                <div className="mobile-cards">

                  {filteredUsers.map(
                    (user) => (

                      <div
                        className="mobile-user-card"
                        key={user.id}
                        onClick={() => {

                          navigate(
                            `/user/${user.id}`
                          );

                        }}
                      >

                        <div className="mobile-card-top">

                          <div className="user-cell">

                            <div className="avatar">

                              {(user.name ||
                                "U")
                                .trim()
                                .charAt(0)
                                .toUpperCase()}

                            </div>

                            <div>

                              <div className="user-name">
                                {user.name ||
                                  "Unnamed User"}
                              </div>

                              <div className="user-id">
                                ID: {user.id}
                              </div>

                            </div>

                          </div>

                          <span
                            className={`role-badge ${getRoleClass(
                              user.role
                            )}`}
                          >
                            {getRoleLabel(
                              user.role
                            )}
                          </span>

                        </div>

                        <div className="mobile-details">

                          <div>

                            <span className="mobile-detail-label">
                              Mobile
                            </span>

                            <span className="mobile-detail-value">
                              {user.mobile ||
                                "-"}
                            </span>

                          </div>

                          <div>

                            <span className="mobile-detail-label">
                              Email
                            </span>

                            <span className="mobile-detail-value">
                              {user.email ||
                                "-"}
                            </span>

                          </div>

                          <div>

                            <span className="mobile-detail-label">
                              Department
                            </span>

                            <span className="mobile-detail-value">
                              {user.department
                                ?.name ||
                                "-"}
                            </span>

                          </div>

                          <div>

                            <span className="mobile-detail-label">
                              Status
                            </span>

                            <span
                              className={`status-badge ${
                                user.isActive
                                  ? "status-active"
                                  : "status-inactive"
                              }`}
                            >

                              <span className="status-dot" />

                              {user.isActive
                                ? "Active"
                                : "Inactive"}

                            </span>

                          </div>

                        </div>

                        {/* MOBILE ACTIONS */}

                        <div
                          className="mobile-actions"
                          onClick={(e) =>
                            e.stopPropagation()
                          }
                        >

                          <button
                            className="action-btn"
                            onClick={() => {

                              navigate(
                                `/user/${user.id}`
                              );

                            }}
                          >
                            👁 View
                          </button>

                          <button
                            className="action-btn"
                            onClick={() => {

                              navigate(
                                `/user/${user.id}/edit`
                              );

                            }}
                          >
                            ✎ Edit
                          </button>

                          <button
                            disabled={
                              actionLoading ===
                              user.id
                            }
                            className={`action-btn ${
                              user.isActive
                                ? "deactivate-action"
                                : "status-action"
                            }`}
                            onClick={() =>
                              toggleUserStatus(
                                user
                              )
                            }
                          >

                            {actionLoading ===
                            user.id
                              ? "..."
                              : user.isActive
                              ? "Deactivate"
                              : "Activate"}

                          </button>

                        </div>

                      </div>

                    )
                  )}

                </div>

              </>

            )}

          </section>

        </div>
      </div>
    </>
  );
}
