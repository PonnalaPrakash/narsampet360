
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getMyGrievances } from "../api/grievanceApi";
import Sidebar from "../components/Sidebar";

type Grievance = {
  id: string;
  title: string;
  description?: string;
  status?: string;
  priority?: string;

  village?: {
    name?: string;
  };

  mandal?: {
    name?: string;
  };

  department?: {
    name?: string;
  };
};

export default function OfficerGrievances() {
  const navigate = useNavigate();

  const [data, setData] = useState<Grievance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [priorityFilter, setPriorityFilter] = useState("ALL");

  const [isMobile, setIsMobile] = useState(
    typeof window !== "undefined"
      ? window.innerWidth <= 768
      : false
  );

  useEffect(() => {
    function handleResize() {
      setIsMobile(window.innerWidth <= 768);
    }

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  async function load() {
    try {
      setLoading(true);
      setError("");

      const response = await getMyGrievances();

      let grievances: any[] = [];

      if (Array.isArray(response)) {
        grievances = response;
      } else if (Array.isArray(response?.data)) {
        grievances = response.data;
      } else if (Array.isArray(response?.grievances)) {
        grievances = response.grievances;
      } else if (
        Array.isArray(response?.data?.grievances)
      ) {
        grievances = response.data.grievances;
      }

      const normalizedGrievances: Grievance[] = grievances
        .map((g: any) => {
          const grievanceId =
            g?.id ??
            g?.grievanceId ??
            g?._id ??
            g?.data?.id ??
            g?.data?.grievanceId ??
            g?.grievance?.id ??
            g?.grievance?._id;

          return {
            ...g,
            id:
              grievanceId !== undefined &&
              grievanceId !== null
                ? String(grievanceId)
                : "",
          };
        })
        .filter((g: Grievance) => g.id !== "");

      setData(normalizedGrievances);
    } catch (err: any) {
      console.error(
        "MY GRIEVANCES ERROR:",
        err?.response?.data || err?.message
      );

      setError(
        err?.response?.data?.message ||
          "Failed to load assigned grievances"
      );

      setData([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const role = localStorage.getItem("role");

    if (role !== "OFFICER") {
      navigate("/dashboard", {
        replace: true,
      });

      return;
    }

    load();
  }, []);

  const filteredData = useMemo(() => {
    const searchValue = search.trim().toLowerCase();

    return data.filter((g) => {
      const matchesSearch =
        !searchValue ||
        g.title?.toLowerCase().includes(searchValue) ||
        g.description?.toLowerCase().includes(searchValue) ||
        g.village?.name?.toLowerCase().includes(searchValue) ||
        g.mandal?.name?.toLowerCase().includes(searchValue) ||
        g.department?.name
          ?.toLowerCase()
          .includes(searchValue);

      const matchesStatus =
        statusFilter === "ALL" ||
        g.status?.toUpperCase() === statusFilter;

      const matchesPriority =
        priorityFilter === "ALL" ||
        g.priority?.toUpperCase() === priorityFilter;

      return (
        matchesSearch &&
        matchesStatus &&
        matchesPriority
      );
    });
  }, [
    data,
    search,
    statusFilter,
    priorityFilter,
  ]);

  function clearFilters() {
    setSearch("");
    setStatusFilter("ALL");
    setPriorityFilter("ALL");
  }

  const hasFilters =
    search.trim() !== "" ||
    statusFilter !== "ALL" ||
    priorityFilter !== "ALL";

  function handleViewGrievance(id: string) {
    if (!id) {
      console.error(
        "Cannot navigate: grievance ID is missing"
      );
      return;
    }

    navigate(
      `/grievance/${encodeURIComponent(id)}`
    );
  }

  function getStatusClass(status?: string) {
    switch (status?.toUpperCase()) {
      case "RESOLVED":
        return "status-resolved";

      case "CLOSED":
        return "status-closed";

      case "IN_PROGRESS":
        return "status-progress";

      case "ASSIGNED":
        return "status-assigned";

      case "REJECTED":
        return "status-rejected";

      default:
        return "status-pending";
    }
  }

  function getPriorityClass(priority?: string) {
    switch (priority?.toUpperCase()) {
      case "HIGH":
        return "priority-high";

      case "MEDIUM":
        return "priority-medium";

      default:
        return "priority-low";
    }
  }

  const statusCounts = {
    all: data.length,
    pending: data.filter(
      (g) => g.status?.toUpperCase() === "PENDING"
    ).length,
    assigned: data.filter(
      (g) => g.status?.toUpperCase() === "ASSIGNED"
    ).length,
    progress: data.filter(
      (g) => g.status?.toUpperCase() === "IN_PROGRESS"
    ).length,
    resolved: data.filter(
      (g) => g.status?.toUpperCase() === "RESOLVED"
    ).length,
  };

  function renderFilters() {
    return (
      <div className="filter-card">
        <div className="filter-header">
          <div>
            <h3>Find Grievances</h3>
            <p>
              Search and filter your assigned complaints
            </p>
          </div>

          {hasFilters && (
            <button
              className="clear-filter"
              onClick={clearFilters}
            >
              ✕ Clear filters
            </button>
          )}
        </div>

        <div className="filter-grid">
          <div className="search-wrapper">
            <span className="search-icon">⌕</span>

            <input
              type="text"
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              placeholder="Search by title, village, mandal..."
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(e.target.value)
            }
          >
            <option value="ALL">All Statuses</option>
            <option value="PENDING">Pending</option>
            <option value="ASSIGNED">Assigned</option>
            <option value="IN_PROGRESS">
              In Progress
            </option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
            <option value="REJECTED">Rejected</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) =>
              setPriorityFilter(e.target.value)
            }
          >
            <option value="ALL">All Priorities</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>

        <div className="result-count">
          Showing{" "}
          <strong>{filteredData.length}</strong> of{" "}
          <strong>{data.length}</strong> grievances
        </div>
      </div>
    );
  }

  function renderMobileCard(g: Grievance) {
    return (
      <div className="grievance-card" key={g.id}>
        <div className="card-top">
          <div className="grievance-icon">
            ⚑
          </div>

          <div className="card-title">
            <h3>{g.title || "Untitled Grievance"}</h3>

            <span className="grievance-id">
              ID: {g.id}
            </span>
          </div>

          <span
            className={`badge ${getStatusClass(
              g.status
            )}`}
          >
            {g.status || "PENDING"}
          </span>
        </div>

        {g.description && (
          <p className="card-description">
            {g.description}
          </p>
        )}

        <div className="mobile-details">
          <MobileDetail
            label="Village"
            value={g.village?.name}
            icon="⌂"
          />

          <MobileDetail
            label="Mandal"
            value={g.mandal?.name}
            icon="◉"
          />

          <MobileDetail
            label="Department"
            value={g.department?.name}
            icon="▦"
          />

          <MobileDetail
            label="Priority"
            value={g.priority}
            icon="!"
            valueClass={getPriorityClass(
              g.priority
            )}
          />
        </div>

        <button
          className="view-button full"
          onClick={() =>
            handleViewGrievance(g.id)
          }
        >
          View Grievance
          <span>→</span>
        </button>
      </div>
    );
  }

  function renderDesktopTable() {
    return (
      <div className="table-card">
        <div className="table-header">
          <div>
            <h3>Assigned Grievances</h3>
            <p>
              Manage and review grievances assigned
              to you
            </p>
          </div>

          <div className="table-total">
            {filteredData.length} Records
          </div>
        </div>

        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>GRIEVANCE</th>
                <th>LOCATION</th>
                <th>DEPARTMENT</th>
                <th>STATUS</th>
                <th>PRIORITY</th>
                <th>ACTION</th>
              </tr>
            </thead>

            <tbody>
              {filteredData.map((g) => (
                <tr key={g.id}>
                  <td>
                    <div className="grievance-cell">
                      <div className="table-icon">
                        ⚑
                      </div>

                      <div>
                        <strong>
                          {g.title ||
                            "Untitled Grievance"}
                        </strong>

                        <span>
                          ID: {g.id}
                        </span>

                        {g.description && (
                          <small>
                            {g.description}
                          </small>
                        )}
                      </div>
                    </div>
                  </td>

                  <td>
                    <div className="location-cell">
                      <span>
                        {g.village?.name || "-"}
                      </span>

                      <small>
                        {g.mandal?.name || "-"}
                      </small>
                    </div>
                  </td>

                  <td>
                    {g.department?.name || "-"}
                  </td>

                  <td>
                    <span
                      className={`badge ${getStatusClass(
                        g.status
                      )}`}
                    >
                      <span className="badge-dot" />
                      {g.status || "PENDING"}
                    </span>
                  </td>

                  <td>
                    <span
                      className={`priority-badge ${getPriorityClass(
                        g.priority
                      )}`}
                    >
                      {g.priority || "-"}
                    </span>
                  </td>

                  <td>
                    <button
                      className="view-button"
                      onClick={() =>
                        handleViewGrievance(
                          g.id
                        )
                      }
                    >
                      View
                      <span>→</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        .officer-page {
          min-height: 100vh;
          background:
            radial-gradient(
              circle at top right,
              rgba(37, 99, 235, 0.08),
              transparent 28%
            ),
            #f6f8fc;
          font-family:
            Inter,
            -apple-system,
            BlinkMacSystemFont,
            "Segoe UI",
            Arial,
            sans-serif;
          color: #172033;
        }

        .officer-content {
          margin-left: 220px;
          min-height: 100vh;
          padding: 32px;
          width: calc(100% - 220px);
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 28px;
          gap: 20px;
        }

        .header-left {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .page-logo {
          width: 50px;
          height: 50px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 22px;
          background:
            linear-gradient(
              135deg,
              #2563eb,
              #4f46e5
            );
          box-shadow:
            0 10px 22px
            rgba(37, 99, 235, 0.22);
        }

        .page-title {
          margin: 0;
          font-size: 29px;
          font-weight: 750;
          letter-spacing: -0.7px;
          color: #172033;
        }

        .page-subtitle {
          margin: 5px 0 0;
          color: #718096;
          font-size: 14px;
        }

        .refresh-button {
          border: none;
          border-radius: 10px;
          padding: 12px 18px;
          background: #2563eb;
          color: white;
          font-weight: 650;
          font-size: 14px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow:
            0 7px 16px
            rgba(37, 99, 235, 0.2);
          transition: 0.2s ease;
        }

        .refresh-button:hover {
          transform: translateY(-1px);
          background: #1d4ed8;
        }

        .refresh-button:disabled {
          opacity: 0.65;
          cursor: not-allowed;
          transform: none;
        }

        .stats-grid {
          display: grid;
          grid-template-columns:
            repeat(5, minmax(0, 1fr));
          gap: 16px;
          margin-bottom: 22px;
        }

        .stat-card {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 14px;
          padding: 18px;
          display: flex;
          align-items: center;
          gap: 13px;
          box-shadow:
            0 5px 18px
            rgba(15, 23, 42, 0.035);
        }

        .stat-icon {
          width: 43px;
          height: 43px;
          flex-shrink: 0;
          border-radius: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          background: #eff6ff;
          color: #2563eb;
        }

        .stat-card:nth-child(2)
          .stat-icon {
          background: #fff7ed;
          color: #ea580c;
        }

        .stat-card:nth-child(3)
          .stat-icon {
          background: #eef2ff;
          color: #4f46e5;
        }

        .stat-card:nth-child(4)
          .stat-icon {
          background: #ecfeff;
          color: #0891b2;
        }

        .stat-card:nth-child(5)
          .stat-icon {
          background: #ecfdf5;
          color: #059669;
        }

        .stat-label {
          color: #718096;
          font-size: 12px;
          margin-bottom: 3px;
        }

        .stat-number {
          font-size: 22px;
          font-weight: 750;
          color: #172033;
        }

        .filter-card {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 14px;
          padding: 20px;
          margin-bottom: 20px;
          box-shadow:
            0 5px 18px
            rgba(15, 23, 42, 0.035);
        }

        .filter-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
          gap: 10px;
        }

        .filter-header h3,
        .table-header h3 {
          margin: 0;
          font-size: 16px;
          font-weight: 700;
        }

        .filter-header p,
        .table-header p {
          margin: 4px 0 0;
          color: #8792a5;
          font-size: 12px;
        }

        .clear-filter {
          border: none;
          background: #fef2f2;
          color: #dc2626;
          border-radius: 8px;
          padding: 8px 11px;
          font-size: 12px;
          cursor: pointer;
          font-weight: 600;
        }

        .filter-grid {
          display: grid;
          grid-template-columns:
            minmax(240px, 2fr)
            minmax(160px, 1fr)
            minmax(160px, 1fr);
          gap: 12px;
        }

        .search-wrapper {
          position: relative;
        }

        .search-wrapper input,
        .filter-grid select {
          width: 100%;
          height: 44px;
          border: 1px solid #dfe4ec;
          border-radius: 9px;
          background: #fbfcfe;
          padding: 0 13px;
          color: #273247;
          outline: none;
          font-size: 13px;
          transition: 0.2s ease;
        }

        .search-wrapper input {
          padding-left: 39px;
        }

        .search-wrapper input:focus,
        .filter-grid select:focus {
          border-color: #2563eb;
          background: white;
          box-shadow:
            0 0 0 3px
            rgba(37, 99, 235, 0.08);
        }

        .search-icon {
          position: absolute;
          left: 14px;
          top: 11px;
          color: #94a3b8;
          font-size: 19px;
          z-index: 1;
        }

        .result-count {
          margin-top: 13px;
          color: #8792a5;
          font-size: 12px;
        }

        .result-count strong {
          color: #334155;
        }

        .table-card {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 14px;
          overflow: hidden;
          box-shadow:
            0 7px 22px
            rgba(15, 23, 42, 0.045);
        }

        .table-header {
          padding: 20px 22px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid #edf0f5;
        }

        .table-total {
          background: #f1f5f9;
          color: #475569;
          padding: 7px 11px;
          border-radius: 7px;
          font-size: 11px;
          font-weight: 650;
        }

        .table-scroll {
          overflow-x: auto;
        }

        table {
          width: 100%;
          border-collapse: collapse;
          min-width: 900px;
        }

        thead {
          background: #f8fafc;
        }

        th {
          text-align: left;
          padding: 13px 18px;
          color: #8994a7;
          font-size: 10px;
          letter-spacing: 0.6px;
          font-weight: 750;
          border-bottom: 1px solid #edf0f5;
        }

        td {
          padding: 16px 18px;
          border-bottom: 1px solid #f0f2f6;
          font-size: 13px;
          color: #3c4759;
          vertical-align: middle;
        }

        tbody tr {
          transition: 0.15s ease;
        }

        tbody tr:hover {
          background: #fbfdff;
        }

        tbody tr:last-child td {
          border-bottom: none;
        }

        .grievance-cell {
          display: flex;
          align-items: flex-start;
          gap: 11px;
          min-width: 250px;
        }

        .table-icon {
          width: 35px;
          height: 35px;
          flex-shrink: 0;
          border-radius: 9px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eff6ff;
          color: #2563eb;
        }

        .grievance-cell strong {
          display: block;
          color: #1e293b;
          font-size: 13px;
          max-width: 280px;
          overflow-wrap: anywhere;
        }

        .grievance-cell span {
          display: block;
          margin-top: 3px;
          color: #94a3b8;
          font-size: 10px;
        }

        .grievance-cell small {
          display: block;
          color: #8a94a5;
          font-size: 11px;
          margin-top: 5px;
          max-width: 280px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .location-cell span {
          display: block;
          color: #334155;
          font-weight: 600;
        }

        .location-cell small {
          display: block;
          color: #94a3b8;
          margin-top: 3px;
        }

        .badge,
        .priority-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 9px;
          border-radius: 7px;
          font-size: 10px;
          font-weight: 750;
          white-space: nowrap;
        }

        .badge-dot {
          width: 5px;
          height: 5px;
          border-radius: 50%;
          background: currentColor;
        }

        .status-resolved {
          background: #ecfdf3;
          color: #087443;
        }

        .status-closed {
          background: #f1f5f9;
          color: #475569;
        }

        .status-progress {
          background: #ecfeff;
          color: #087f8c;
        }

        .status-assigned {
          background: #eff6ff;
          color: #1d4ed8;
        }

        .status-rejected {
          background: #fef2f2;
          color: #b91c1c;
        }

        .status-pending {
          background: #fff7ed;
          color: #c2410c;
        }

        .priority-high {
          background: #fef2f2;
          color: #dc2626;
        }

        .priority-medium {
          background: #fffbeb;
          color: #b45309;
        }

        .priority-low {
          background: #ecfdf5;
          color: #047857;
        }

        .view-button {
          border: none;
          background: #eff6ff;
          color: #2563eb;
          padding: 8px 11px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          transition: 0.18s ease;
        }

        .view-button:hover {
          background: #2563eb;
          color: white;
        }

        .view-button span {
          font-size: 15px;
        }

        .empty-state,
        .error-state,
        .loading-state {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 14px;
          padding: 55px 25px;
          text-align: center;
          box-shadow:
            0 5px 18px
            rgba(15, 23, 42, 0.035);
        }

        .empty-icon {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: #eff6ff;
          color: #2563eb;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 15px;
          font-size: 25px;
        }

        .empty-state h2,
        .loading-state h3 {
          margin: 0;
          font-size: 19px;
        }

        .empty-state p {
          color: #8792a5;
          font-size: 13px;
          margin: 8px 0 18px;
        }

        .empty-state button {
          border: none;
          background: #2563eb;
          color: white;
          padding: 9px 15px;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 650;
        }

        .error-state {
          background: #fff7f7;
          border-color: #fecaca;
          color: #b91c1c;
          font-size: 14px;
        }

        .grievance-card {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 14px;
          padding: 17px;
          margin-bottom: 13px;
          box-shadow:
            0 5px 17px
            rgba(15, 23, 42, 0.045);
        }

        .card-top {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }

        .grievance-icon {
          width: 37px;
          height: 37px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 9px;
          background: #eff6ff;
          color: #2563eb;
        }

        .card-title {
          flex: 1;
          min-width: 0;
        }

        .card-title h3 {
          margin: 1px 0 3px;
          font-size: 15px;
          line-height: 1.35;
          overflow-wrap: anywhere;
        }

        .grievance-id {
          color: #94a3b8;
          font-size: 10px;
        }

        .card-description {
          color: #6b7280;
          font-size: 12px;
          line-height: 1.55;
          margin: 13px 0;
          overflow-wrap: anywhere;
        }

        .mobile-details {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 13px;
          border-top: 1px solid #f0f2f6;
          padding-top: 14px;
          margin-top: 5px;
        }

        .mobile-detail-label {
          color: #94a3b8;
          font-size: 10px;
          font-weight: 650;
          margin-bottom: 4px;
        }

        .mobile-detail-value {
          color: #334155;
          font-size: 12px;
          overflow-wrap: anywhere;
        }

        .full {
          width: 100%;
          justify-content: center;
          margin-top: 15px;
          height: 40px;
        }

        .filter-mobile-hidden {
          display: none;
        }

        @media (max-width: 1100px) {
          .stats-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
          }

          .filter-grid {
            grid-template-columns: 1fr 1fr;
          }

          .search-wrapper {
            grid-column: 1 / -1;
          }
        }

        @media (max-width: 768px) {
          .officer-content {
            margin-left: 0;
            width: 100%;
            padding: 18px 14px 28px;
          }

          .page-header {
            align-items: flex-start;
            flex-direction: column;
            margin-bottom: 20px;
          }

          .header-left {
            width: 100%;
          }

          .page-logo {
            width: 44px;
            height: 44px;
            border-radius: 12px;
          }

          .page-title {
            font-size: 22px;
          }

          .page-subtitle {
            font-size: 12px;
          }

          .refresh-button {
            width: 100%;
            justify-content: center;
          }

          .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 10px;
          }

          .stat-card {
            padding: 13px;
          }

          .stat-card:last-child {
            grid-column: 1 / -1;
          }

          .stat-icon {
            width: 36px;
            height: 36px;
          }

          .stat-number {
            font-size: 19px;
          }

          .filter-card {
            padding: 15px;
          }

          .filter-header {
            align-items: flex-start;
            flex-direction: column;
          }

          .clear-filter {
            width: 100%;
          }

          .filter-grid {
            grid-template-columns: 1fr;
          }

          .search-wrapper {
            grid-column: auto;
          }

          .table-card {
            display: none;
          }

          .badge {
            font-size: 9px;
            padding: 5px 7px;
          }

          .card-title h3 {
            font-size: 14px;
          }
        }

        @media (min-width: 769px) {
          .mobile-list {
            display: none;
          }
        }
      `}</style>

      <div className="officer-page">
        <Sidebar />

        <main className="officer-content">
          <div className="page-header">
            <div className="header-left">
              <div className="page-logo">⚑</div>

              <div>
                <h1 className="page-title">
                  My Assigned Grievances
                </h1>

                <p className="page-subtitle">
                  Track, review and manage grievances
                  assigned to you
                </p>
              </div>
            </div>

            <button
              className="refresh-button"
              onClick={load}
              disabled={loading}
            >
              ↻
              {loading
                ? "Refreshing..."
                : "Refresh Data"}
            </button>
          </div>

          {!loading && !error && (
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon">▦</div>

                <div>
                  <div className="stat-label">
                    Total
                  </div>

                  <div className="stat-number">
                    {statusCounts.all}
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon">◷</div>

                <div>
                  <div className="stat-label">
                    Pending
                  </div>

                  <div className="stat-number">
                    {statusCounts.pending}
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon">✓</div>

                <div>
                  <div className="stat-label">
                    Assigned
                  </div>

                  <div className="stat-number">
                    {statusCounts.assigned}
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon">↻</div>

                <div>
                  <div className="stat-label">
                    In Progress
                  </div>

                  <div className="stat-number">
                    {statusCounts.progress}
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon">✓</div>

                <div>
                  <div className="stat-label">
                    Resolved
                  </div>

                  <div className="stat-number">
                    {statusCounts.resolved}
                  </div>
                </div>
              </div>
            </div>
          )}

          {!loading &&
            !error &&
            data.length > 0 &&
            renderFilters()}

          {loading && (
            <div className="loading-state">
              <h3>
                Loading your grievances...
              </h3>

              <p
                style={{
                  color: "#94a3b8",
                  fontSize: 13,
                }}
              >
                Please wait while we fetch the
                latest data.
              </p>
            </div>
          )}

          {!loading && error && (
            <div className="error-state">
              ⚠ {error}
            </div>
          )}

          {!loading &&
            !error &&
            data.length === 0 && (
              <div className="empty-state">
                <div className="empty-icon">
                  ✓
                </div>

                <h2>
                  No grievances assigned
                </h2>

                <p>
                  You currently have no grievances
                  assigned to you.
                </p>

                <button onClick={load}>
                  Refresh
                </button>
              </div>
            )}

          {!loading &&
            !error &&
            data.length > 0 &&
            filteredData.length === 0 && (
              <div className="empty-state">
                <div className="empty-icon">
                  ⌕
                </div>

                <h2>
                  No matching grievances
                </h2>

                <p>
                  Try changing your search or
                  filter options.
                </p>

                <button onClick={clearFilters}>
                  Clear Filters
                </button>
              </div>
            )}

          {!loading &&
            !error &&
            filteredData.length > 0 &&
            isMobile && (
              <div className="mobile-list">
                {filteredData.map(
                  renderMobileCard
                )}
              </div>
            )}

          {!loading &&
            !error &&
            filteredData.length > 0 &&
            !isMobile &&
            renderDesktopTable()}
        </main>
      </div>
    </>
  );
}

type MobileDetailProps = {
  label: string;
  value?: string;
  icon?: string;
  valueClass?: string;
};

function MobileDetail({
  label,
  value,
  valueClass,
}: MobileDetailProps) {
  return (
    <div>
      <div className="mobile-detail-label">
        {label}
      </div>

      <div
        className={`mobile-detail-value ${
          valueClass || ""
        }`}
        style={
          valueClass
            ? {
                display: "inline-block",
                padding: "4px 7px",
                borderRadius: 6,
                fontWeight: 700,
                fontSize: 10,
              }
            : undefined
        }
      >
        {value || "-"}
      </div>
    </div>
  );
}
