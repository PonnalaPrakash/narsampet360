
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  useNavigate,
  useSearchParams,
} from "react-router-dom";

import {
  assignGrievance,
  getGrievances,
  getOfficers,
  undoGrievance,
  updateGrievanceStatus,
} from "../api/grievanceApi";

/* =====================================================
   TYPES
===================================================== */

type UserRole =
  | "ADMIN"
  | "MLA"
  | "PA"
  | "MANDAL_INCHARGE"
  | "VILLAGE_COORDINATOR"
  | "OFFICER"
  | "";

type ToastType = "success" | "error" | "info";

interface ToastState {
  type: ToastType;
  message: string;
}

interface StatusMeta {
  label: string;
  bg: string;
  color: string;
  border: string;
  dot: string;
}

interface PriorityMeta {
  label: string;
  bg: string;
  color: string;
  border: string;
}

interface StatusAction {
  status: string;
  label: string;
  variant: "primary" | "success" | "danger" | "neutral";
}

interface Grievance {
  id: string | number;
  title?: string;
  description?: string;

  citizenName?: string;
  citizenMobile?: string;

  status?: string;
  priority?: string;
  createdAt?: string;

  department?: {
    id?: string | number;
    name?: string;
  };

  village?: {
    id?: string | number;
    name?: string;
  };

  mandal?: {
    id?: string | number;
    name?: string;
  };

  assignedTo?: {
    id?: string | number;
    name?: string;
    mobile?: string;
  };

  createdBy?: {
    id?: string | number;
    name?: string;
  };
}

interface Officer {
  id: string;
  name: string;
  mobile?: string;
  role?: string;
  department?: {
    id?: string;
    name?: string;
  };
  isActive?: boolean;
}

/* =====================================================
   STATUS / PRIORITY META
===================================================== */

const STATUS_META: Record<string, StatusMeta> = {
  PENDING: {
    label: "Pending",
    bg: "#fff7ed",
    color: "#c2410c",
    border: "#fed7aa",
    dot: "#f97316",
  },

  ASSIGNED: {
    label: "Assigned",
    bg: "#eff6ff",
    color: "#2563eb",
    border: "#bfdbfe",
    dot: "#3b82f6",
  },

  IN_PROGRESS: {
    label: "In Progress",
    bg: "#f5f3ff",
    color: "#7c3aed",
    border: "#ddd6fe",
    dot: "#8b5cf6",
  },

  RESOLVED: {
    label: "Resolved",
    bg: "#ecfdf5",
    color: "#047857",
    border: "#a7f3d0",
    dot: "#10b981",
  },

  REJECTED: {
    label: "Rejected",
    bg: "#fef2f2",
    color: "#b91c1c",
    border: "#fecaca",
    dot: "#ef4444",
  },

  CLOSED: {
    label: "Closed",
    bg: "#f1f5f9",
    color: "#475569",
    border: "#cbd5e1",
    dot: "#64748b",
  },
};

const PRIORITY_META: Record<string, PriorityMeta> = {
  HIGH: {
    label: "High",
    bg: "#fff1f2",
    color: "#be123c",
    border: "#fecdd3",
  },

  MEDIUM: {
    label: "Medium",
    bg: "#fffbeb",
    color: "#b45309",
    border: "#fde68a",
  },

  LOW: {
    label: "Low",
    bg: "#f0fdf4",
    color: "#15803d",
    border: "#bbf7d0",
  },
};

/* =====================================================
   STATUS ACTIONS
===================================================== */

const ACTIONS_BY_STATUS: Record<
  string,
  StatusAction[]
> = {
  PENDING: [],

  ASSIGNED: [
    {
      status: "IN_PROGRESS",
      label: "Start",
      variant: "primary",
    },
  ],

  IN_PROGRESS: [
    {
      status: "RESOLVED",
      label: "Resolve",
      variant: "success",
    },
    {
      status: "REJECTED",
      label: "Reject",
      variant: "danger",
    },
  ],

  RESOLVED: [
    {
      status: "CLOSED",
      label: "Close",
      variant: "neutral",
    },
  ],

  REJECTED: [],

  CLOSED: [],
};

/* =====================================================
   ICONS
===================================================== */

const SearchIcon = () => (
  <svg
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

const RefreshIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M20 11a8.1 8.1 0 0 0-15.5-3" />
    <path d="M4 4v4h4" />
    <path d="M4 13a8.1 8.1 0 0 0 15.5 3" />
    <path d="M20 20v-4h-4" />
  </svg>
);

const FilterIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M4 6h16" />
    <path d="M7 12h10" />
    <path d="M10 18h4" />
  </svg>
);

const ArrowRightIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M5 12h14" />
    <path d="m13 6 6 6-6 6" />
  </svg>
);

const MapPinIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
    <circle cx="12" cy="10" r="2.5" />
  </svg>
);

const CalendarIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect x="3" y="4" width="18" height="17" rx="2" />
    <path d="M16 2v4M8 2v4M3 10h18" />
  </svg>
);

const UserIcon = () => (
  <svg
    width="13"
    height="13"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21a8 8 0 0 1 16 0" />
  </svg>
);

const AlertIcon = () => (
  <svg
    width="18"
    height="18"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M10.3 3.9 2.6 17a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
    <path d="M12 9v4" />
    <path d="M12 17h.01" />
  </svg>
);

const UndoIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M9 14 4 9l5-5" />
    <path d="M4 9h10a6 6 0 0 1 0 12h-1" />
  </svg>
);

const CheckIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="m5 12 4 4L19 6" />
  </svg>
);

const CloseIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

/* =====================================================
   HELPERS
===================================================== */

const formatDate = (
  value?: string,
) => {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return date.toLocaleDateString(
    "en-IN",
    {
      day: "2-digit",
      month: "short",
      year: "numeric",
    },
  );
};

const formatStatus = (
  value?: string,
) => {
  const normalized =
    normalizeStatus(value);

  return (
    STATUS_META[normalized]
      ?.label ||
    String(value || "")
      .replace(/_/g, " ")
      .toLowerCase()
      .replace(/\b\w/g, (char) =>
        char.toUpperCase(),
      )
  );
};

const normalizeStatus = (
  value?: string,
) => {
  const normalized =
    String(value || "")
      .trim()
      .toUpperCase()
      .replace(/[\s-]+/g, "_");

  if (
    normalized ===
    "INPROGRESS"
  ) {
    return "IN_PROGRESS";
  }

  return normalized;
};

const normalizePriority = (
  value?: string,
) => {
  const normalized =
    String(value || "")
      .trim()
      .toUpperCase();

  if (
    normalized === "URGENT"
  ) {
    return "HIGH";
  }

  if (
    normalized === "NORMAL"
  ) {
    return "MEDIUM";
  }

  return normalized;
};

const getInitials = (
  name?: string,
) => {
  const value =
    String(name || "")
      .trim();

  if (!value) {
    return "C";
  }

  const parts =
    value.split(/\s+/);

  if (parts.length === 1) {
    return parts[0]
      .slice(0, 2)
      .toUpperCase();
  }

  return (
    parts[0][0] +
    parts[parts.length - 1][0]
  ).toUpperCase();
};

const normalizeGrievance = (
  item: any,
): Grievance => {
  return {
    id: String(
      item?.id ??
        item?.grievanceId ??
        "",
    ),

    title:
      item?.title ||
      item?.subject ||
      "",

    description:
      item?.description ||
      "",

    citizenName:
      item?.citizenName ||
      item?.citizen?.name ||
      item?.complainantName ||
      "",

    citizenMobile:
      item?.citizenMobile ||
      item?.citizen?.mobile ||
      item?.mobile ||
      "",

    status:
      item?.status ||
      "PENDING",

    priority:
      item?.priority ||
      "MEDIUM",

    createdAt:
      item?.createdAt ||
      item?.created_at ||
      item?.registeredAt ||
      "",

    department:
      item?.department
        ? {
            id:
              item.department.id !==
              undefined
                ? String(
                    item.department.id,
                  )
                : undefined,

            name:
              item.department.name ||
              "",
          }
        : undefined,

    village:
      item?.village
        ? {
            id:
              item.village.id !==
              undefined
                ? String(
                    item.village.id,
                  )
                : undefined,

            name:
              item.village.name ||
              "",
          }
        : undefined,

    mandal:
      item?.mandal
        ? {
            id:
              item.mandal.id !==
              undefined
                ? String(
                    item.mandal.id,
                  )
                : undefined,

            name:
              item.mandal.name ||
              "",
          }
        : undefined,

    assignedTo:
      item?.assignedTo
        ? {
            id:
              item.assignedTo.id !==
              undefined
                ? String(
                    item.assignedTo.id,
                  )
                : undefined,

            name:
              item.assignedTo.name ||
              item.assignedTo.fullName ||
              "Officer",

            mobile:
              item.assignedTo.mobile ||
              "",
          }
        : undefined,

    createdBy:
      item?.createdBy
        ? {
            id:
              item.createdBy.id !==
              undefined
                ? String(
                    item.createdBy.id,
                  )
                : undefined,

            name:
              item.createdBy.name ||
              item.createdBy.fullName ||
              "",
          }
        : undefined,
  };
};

const extractArray = (
  response: any,
): any[] => {
  if (Array.isArray(response)) {
    return response;
  }

  if (
    Array.isArray(
      response?.data,
    )
  ) {
    return response.data;
  }

  if (
    Array.isArray(
      response?.data?.data,
    )
  ) {
    return response.data.data;
  }

  if (
    Array.isArray(
      response?.data?.items,
    )
  ) {
    return response.data.items;
  }

  if (
    Array.isArray(
      response?.items,
    )
  ) {
    return response.items;
  }

  if (
    Array.isArray(
      response?.results,
    )
  ) {
    return response.results;
  }

  return [];
};

/* =====================================================
   COMPONENT
===================================================== */

export default function Grievances() {
  const navigate =
    useNavigate();

  const [
    searchParams,
    setSearchParams,
  ] = useSearchParams();

  /* ===================================================
     ROLE
  =================================================== */

  const role =
    (
      localStorage.getItem(
        "role",
      ) || ""
    ).toUpperCase() as UserRole;

  const canAssign =
    role === "ADMIN" ||
    role === "MLA" ||
    role === "PA";

  const canUndo =
    role === "ADMIN" ||
    role === "MLA" ||
    role === "PA";

  /* ===================================================
     QUERY PARAMS
  =================================================== */

  const statusQuery =
    searchParams.get(
      "status",
    ) || "";

  const dateQuery =
    searchParams.get(
      "date",
    ) || "";

  /* ===================================================
     STATE
  =================================================== */

  const [
    grievances,
    setGrievances,
  ] = useState<Grievance[]>([]);

  const [
    officers,
    setOfficers,
  ] = useState<Officer[]>([]);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");

  const [
    search,
    setSearch,
  ] = useState("");

  const [
    statusFilter,
    setStatusFilter,
  ] = useState(statusQuery);

  const [
    priorityFilter,
    setPriorityFilter,
  ] = useState("");

  const [
    departmentFilter,
    setDepartmentFilter,
  ] = useState("");

  const [
    mandalFilter,
    setMandalFilter,
  ] = useState("");

  const [
    villageFilter,
    setVillageFilter,
  ] = useState("");

  const [
    showFilters,
    setShowFilters,
  ] = useState(false);

  const [
    assigningId,
    setAssigningId,
  ] = useState<string | null>(
    null,
  );

  const [
    selectedOfficer,
    setSelectedOfficer,
  ] = useState<
    Record<string, string>
  >({});

  const [
    actionId,
    setActionId,
  ] = useState<string | null>(
    null,
  );

  const [
    toast,
    setToast,
  ] = useState<ToastState | null>(
    null,
  );

  /* ===================================================
     TOAST
  =================================================== */

  const showToast =
    useCallback(
      (
        type: ToastType,
        message: string,
      ) => {
        setToast({
          type,
          message,
        });
      },
      [],
    );

  /* ===================================================
     ROLE BASED ACTIONS
  =================================================== */

  const getAllowedActions =
    useCallback(
      (
        status?: string,
      ): StatusAction[] => {
        const normalized =
          normalizeStatus(status);

        const actions =
          ACTIONS_BY_STATUS[
            normalized
          ] || [];

        if (
          role === "OFFICER"
        ) {
          return actions.filter(
            (action) =>
              action.status ===
                "IN_PROGRESS" ||
              action.status ===
                "RESOLVED",
          );
        }

        if (
          role === "ADMIN" ||
          role === "PA"
        ) {
          return actions.filter(
            (action) =>
              action.status ===
                "REJECTED" ||
              action.status ===
                "CLOSED",
          );
        }

        return [];
      },
      [role],
    );

  /* ===================================================
     LOAD GRIEVANCES
  =================================================== */

  const loadGrievances =
    useCallback(
      async (
        isRefresh = false,
      ) => {
        try {
          if (isRefresh) {
            setRefreshing(true);
          } else {
            setLoading(true);
          }

          setError("");

          const params: Record<
            string,
            string
          > = {};

          if (statusQuery) {
            params.status =
              statusQuery;
          }

          if (dateQuery) {
            params.date =
              dateQuery;
          }

          const response =
            await getGrievances(
              params,
            );

          const list =
            extractArray(
              response,
            ).map(
              normalizeGrievance,
            );

          setGrievances(list);
        } catch (err: any) {
          console.error(
            "Failed to load grievances:",
            err,
          );

          const message =
            err?.response
              ?.data?.message ||
            err?.message ||
            "Failed to load grievances.";

          setError(
            Array.isArray(message)
              ? message.join(", ")
              : String(message),
          );
        } finally {
          setLoading(false);
          setRefreshing(false);
        }
      },
      [
        statusQuery,
        dateQuery,
      ],
    );

  /* ===================================================
     LOAD OFFICERS
  =================================================== */

  const loadOfficers =
    useCallback(
      async () => {
        if (!canAssign) {
          setOfficers([]);
          return;
        }

        try {
          const response =
            await getOfficers();

          const list =
            extractArray(
              response,
            );

          const normalized =
            list
              .map(
                (item: any) => ({
                  id: String(
                    item?.id ?? "",
                  ),

                  name:
                    item?.name ||
                    item?.fullName ||
                    "Officer",

                  mobile:
                    item?.mobile ||
                    "",

                  role:
                    item?.role ||
                    "",

                  department:
                    item?.department
                      ? {
                          id:
                            item
                              .department
                              ?.id !==
                            undefined
                              ? String(
                                  item
                                    .department
                                    .id,
                                )
                              : undefined,

                          name:
                            item
                              .department
                              ?.name ||
                            "",
                        }
                      : undefined,

                  isActive:
                    item?.isActive !==
                    false,
                }),
              )
              .filter(
                (
                  item: Officer,
                ) =>
                  item.id &&
                  item.isActive !==
                    false,
              );

          setOfficers(
            normalized,
          );
        } catch (err) {
          console.error(
            "Failed to load officers:",
            err,
          );

          setOfficers([]);
        }
      },
      [canAssign],
    );

  /* ===================================================
     EFFECTS
  =================================================== */

  useEffect(() => {
    void loadGrievances();
  }, [loadGrievances]);

  useEffect(() => {
    void loadOfficers();
  }, [loadOfficers]);

  useEffect(() => {
    setStatusFilter(
      statusQuery,
    );
  }, [statusQuery]);

  /* ===================================================
     FILTER OPTIONS
  =================================================== */

  const departments =
    useMemo(() => {
      const values =
        new Map<
          string,
          string
        >();

      grievances.forEach(
        (item) => {
          const id =
            String(
              item.department
                ?.id ?? "",
            );

          const name =
            item.department
              ?.name || "";

          if (id && name) {
            values.set(
              id,
              name,
            );
          }
        },
      );

      return Array.from(
        values.entries(),
      ).map(
        ([id, name]) => ({
          id,
          name,
        }),
      );
    }, [grievances]);

  const mandals =
    useMemo(() => {
      const values =
        new Map<
          string,
          string
        >();

      grievances.forEach(
        (item) => {
          const id =
            String(
              item.mandal?.id ??
                "",
            );

          const name =
            item.mandal?.name ||
            "";

          if (id && name) {
            values.set(
              id,
              name,
            );
          }
        },
      );

      return Array.from(
        values.entries(),
      ).map(
        ([id, name]) => ({
          id,
          name,
        }),
      );
    }, [grievances]);

  const villages =
    useMemo(() => {
      const values =
        new Map<
          string,
          string
        >();

      grievances.forEach(
        (item) => {
          const id =
            String(
              item.village
                ?.id ?? "",
            );

          const name =
            item.village
              ?.name || "";

          if (id && name) {
            values.set(
              id,
              name,
            );
          }
        },
      );

      return Array.from(
        values.entries(),
      ).map(
        ([id, name]) => ({
          id,
          name,
        }),
      );
    }, [grievances]);

  /* ===================================================
     STATS
  =================================================== */

  const stats =
    useMemo(() => {
      const total =
        grievances.length;

      let pending = 0;
      let assigned = 0;
      let inProgress = 0;
      let resolved = 0;
      let closed = 0;
      let rejected = 0;
      let highPriority = 0;

      grievances.forEach(
        (item) => {
          const status =
            normalizeStatus(
              item.status,
            );

          const priority =
            normalizePriority(
              item.priority,
            );

          if (
            status === "PENDING"
          ) {
            pending++;
          }

          if (
            status === "ASSIGNED"
          ) {
            assigned++;
          }

          if (
            status ===
            "IN_PROGRESS"
          ) {
            inProgress++;
          }

          if (
            status === "RESOLVED"
          ) {
            resolved++;
          }

          if (
            status === "CLOSED"
          ) {
            closed++;
          }

          if (
            status === "REJECTED"
          ) {
            rejected++;
          }

          if (
            priority === "HIGH"
          ) {
            highPriority++;
          }
        },
      );

      return {
        total,
        pending,
        assigned,
        inProgress,
        resolved,
        closed,
        rejected,
        highPriority,
      };
    }, [grievances]);

  /* ===================================================
     FILTERED GRIEVANCES
  =================================================== */

  const filteredGrievances =
    useMemo(() => {
      const query =
        search
          .trim()
          .toLowerCase();

      return grievances.filter(
        (item) => {
          const matchesSearch =
            !query ||
            [
              item.id,
              item.title,
              item.description,
              item.citizenName,
              item.citizenMobile,
              item.village
                ?.name,
              item.mandal
                ?.name,
              item.department
                ?.name,
              item.assignedTo
                ?.name,
            ]
              .filter(Boolean)
              .some(
                (value) =>
                  String(value)
                    .toLowerCase()
                    .includes(
                      query,
                    ),
              );

          const matchesStatus =
            !statusFilter ||
            normalizeStatus(
              item.status,
            ) ===
              normalizeStatus(
                statusFilter,
              );

          const matchesPriority =
            !priorityFilter ||
            normalizePriority(
              item.priority,
            ) ===
              normalizePriority(
                priorityFilter,
              );

          const matchesDepartment =
            !departmentFilter ||
            String(
              item.department
                ?.id ?? "",
            ) ===
              String(
                departmentFilter,
              );

          const matchesMandal =
            !mandalFilter ||
            String(
              item.mandal
                ?.id ?? "",
            ) ===
              String(
                mandalFilter,
              );

          const matchesVillage =
            !villageFilter ||
            String(
              item.village
                ?.id ?? "",
            ) ===
              String(
                villageFilter,
              );

          return (
            matchesSearch &&
            matchesStatus &&
            matchesPriority &&
            matchesDepartment &&
            matchesMandal &&
            matchesVillage
          );
        },
      );
    }, [
      grievances,
      search,
      statusFilter,
      priorityFilter,
      departmentFilter,
      mandalFilter,
      villageFilter,
    ]);

  /* ===================================================
     FILTER HELPERS
  =================================================== */

  const hasFilters =
    Boolean(
      search.trim() ||
      statusFilter ||
      priorityFilter ||
      departmentFilter ||
      mandalFilter ||
      villageFilter ||
      dateQuery,
    );

  const activeFilterCount =
    [
      statusFilter,
      priorityFilter,
      departmentFilter,
      mandalFilter,
      villageFilter,
      dateQuery,
    ].filter(Boolean).length;

  const clearFilters =
    useCallback(() => {
      setSearch("");
      setStatusFilter("");
      setPriorityFilter("");
      setDepartmentFilter("");
      setMandalFilter("");
      setVillageFilter("");

      setSearchParams({});
    }, [setSearchParams]);

  const removeDateFilter =
    () => {
      const next =
        new URLSearchParams(
          searchParams,
        );

      next.delete("date");

      setSearchParams(next);
    };

  const setStatusQuery =
    (value: string) => {
      setStatusFilter(value);

      const next =
        new URLSearchParams(
          searchParams,
        );

      if (value) {
        next.set(
          "status",
          value,
        );
      } else {
        next.delete(
          "status",
        );
      }

      setSearchParams(next);
    };

  /* ===================================================
     STATUS CHANGE
  =================================================== */

  const changeStatus =
    async (
      id: string,
      nextStatus: string,
    ) => {
      const grievance =
        grievances.find(
          (item) =>
            String(item.id) ===
            id,
        );

      if (!grievance) {
        return;
      }

      const allowedActions =
        getAllowedActions(
          grievance.status,
        );

      const allowed =
        allowedActions.some(
          (action) =>
            action.status ===
            nextStatus,
        );

      if (!allowed) {
        showToast(
          "error",
          "You are not allowed to perform this status action.",
        );
        return;
      }

      if (
        nextStatus ===
        "REJECTED"
      ) {
        const confirmed =
          window.confirm(
            "Are you sure you want to reject this grievance?",
          );

        if (!confirmed) {
          return;
        }
      }

      if (
        nextStatus ===
        "CLOSED"
      ) {
        const confirmed =
          window.confirm(
            "Are you sure you want to close this grievance?",
          );

        if (!confirmed) {
          return;
        }
      }

      try {
        setActionId(id);

        await updateGrievanceStatus(
          id,
          { status: nextStatus },
        );

        showToast(
          "success",
          `Grievance status changed to ${formatStatus(
            nextStatus,
          )}.`,
        );

        await loadGrievances(
          true,
        );
      } catch (err: any) {
        console.error(
          "Failed to update grievance status:",
          err,
        );

        const message =
          err?.response
            ?.data?.message ||
          err?.message ||
          "Failed to update grievance status.";

        showToast(
          "error",
          Array.isArray(message)
            ? message.join(", ")
            : String(message),
        );
      } finally {
        setActionId(null);
      }
    };

  /* ===================================================
     ASSIGN OFFICER
  =================================================== */

  const assignOfficer =
    async (
      id: string,
    ) => {
      if (!canAssign) {
        showToast(
          "error",
          "You are not allowed to assign grievances.",
        );
        return;
      }

      const officerId =
        selectedOfficer[id];

      if (!officerId) {
        showToast(
          "error",
          "Please select an officer.",
        );
        return;
      }

      const grievance =
        grievances.find(
          (item) =>
            String(item.id) ===
            id,
        );

      if (
        !grievance ||
        normalizeStatus(
          grievance.status,
        ) !== "PENDING"
      ) {
        showToast(
          "error",
          "Only pending grievances can be assigned.",
        );
        return;
      }

      const officer =
        officers.find(
          (item) =>
            String(item.id) ===
            String(officerId),
        );

      if (!officer) {
        showToast(
          "error",
          "Selected officer is not available.",
        );
        return;
      }

      try {
        setAssigningId(id);

        await assignGrievance(
          id,
          {
            assignedToId:
              officer.id,
          },
        );

        showToast(
          "success",
          `Grievance assigned to ${officer.name}.`,
        );

        setSelectedOfficer(
          (current) => {
            const next = {
              ...current,
            };

            delete next[id];

            return next;
          },
        );

        await loadGrievances(
          true,
        );
      } catch (err: any) {
        console.error(
          "Failed to assign grievance:",
          err,
        );

        const message =
          err?.response
            ?.data?.message ||
          err?.message ||
          "Failed to assign grievance.";

        showToast(
          "error",
          Array.isArray(message)
            ? message.join(", ")
            : String(message),
        );
      } finally {
        setAssigningId(null);
      }
    };

  /* ===================================================
     UNDO
  =================================================== */

  const undoStatus =
    async (
      id: string,
    ) => {
      if (!canUndo) {
        showToast(
          "error",
          "You are not allowed to undo this change.",
        );
        return;
      }

      const grievance =
        grievances.find(
          (item) =>
            String(item.id) ===
            id,
        );

      if (!grievance) {
        return;
      }

      const status =
        normalizeStatus(
          grievance.status,
        );

      if (
        status === "PENDING" ||
        status === "CLOSED"
      ) {
        showToast(
          "error",
          "This grievance cannot be undone.",
        );
        return;
      }

      const confirmed =
        window.confirm(
          "Undo the last grievance status change?",
        );

      if (!confirmed) {
        return;
      }

      try {
        setActionId(id);

        await undoGrievance(id);

        showToast(
          "success",
          "Last grievance change was undone.",
        );

        await loadGrievances(
          true,
        );
      } catch (err: any) {
        console.error(
          "Failed to undo grievance:",
          err,
        );

        const message =
          err?.response
            ?.data?.message ||
          err?.message ||
          "Failed to undo grievance.";

        showToast(
          "error",
          Array.isArray(message)
            ? message.join(", ")
            : String(message),
        );
      } finally {
        setActionId(null);
      }
    };

  /* ===================================================
     NAVIGATION
  =================================================== */

  const openDetails =
    (
      id: string | number,
    ) => {
      navigate(
        `/grievance/${encodeURIComponent(
          String(id),
        )}`,
      );
    };

  const openToday =
    () => {
      navigate(
        "/grievances?date=today",
      );
    };

  /* ===================================================
     REFRESH
  =================================================== */

  const handleRefresh =
    async () => {
      await Promise.all([
        loadGrievances(true),
        loadOfficers(),
      ]);
    };

  /* ===================================================
     LOADING UI
  =================================================== */

  if (loading) {
    return (
      <div className="loading-page">
        <div className="loading-inner">
          <div className="loading-brand">
            <div className="loading-logo">
              N
            </div>

            <div>
              <div className="loading-line brand-line" />
              <div className="loading-line small-line" />
            </div>
          </div>

          <div className="loading-hero">
            <div className="loading-line title-line" />
            <div className="loading-line text-line" />
          </div>

          <div className="loading-grid">
            {[1, 2, 3, 4].map(
              (item) => (
                <div
                  className="loading-card"
                  key={item}
                />
              ),
            )}
          </div>

          <div className="loading-table">
            {[1, 2, 3, 4, 5].map(
              (item) => (
                <div
                  className="loading-row"
                  key={item}
                >
                  <div />
                  <div />
                  <div />
                  <div />
                </div>
              ),
            )}
          </div>
        </div>

        <style>
          {loadingStyles}
        </style>
      </div>
    );
  }

  /* ===================================================
     ERROR UI
  =================================================== */

  if (
    error &&
    !grievances.length
  ) {
    return (
      <div className="error-page">
        <div className="error-card">
          <div className="error-icon">
            <AlertIcon />
          </div>

          <h2>
            Unable to load grievances
          </h2>

          <p>{error}</p>

          <button
            className="primary-button"
            onClick={() =>
              void loadGrievances()
            }
          >
            Try Again
          </button>
        </div>

        <style>
          {errorStyles}
        </style>
      </div>
    );
  }

  /* ===================================================
     RENDER
  =================================================== */

  return (
    <div className="grievances-page">
      <div className="page-shell">

        {/* TOP BAR */}

        <div className="page-topbar">
          <div>
            <div className="page-kicker">
              {role || "USER"} WORKSPACE
            </div>

            <h1 className="page-title">
              Grievances
            </h1>

            <p className="page-subtitle">
              Review, assign and track constituency
              grievances from one place.
            </p>
          </div>

          <div className="topbar-actions">
            <button
              type="button"
              className="refresh-button"
              onClick={() =>
                void handleRefresh()
              }
              disabled={refreshing}
            >
              <RefreshIcon />

              {refreshing
                ? "Refreshing..."
                : "Refresh"}
            </button>

            <button
              type="button"
              className="primary-button"
              onClick={() =>
                navigate(
                  "/grievance/new",
                )
              }
            >
              + New Grievance
            </button>
          </div>
        </div>

        {/* HERO */}

        <section className="grievances-hero">
          <div>
            <div className="hero-eyebrow">
              {role || "USER"} OVERVIEW
            </div>

            <h2>
              Grievance Management
            </h2>

            <p>
              Monitor complaints, track progress,
              and take actions allowed for your role.
            </p>
          </div>

          <button
            type="button"
            className="hero-today-button"
            onClick={openToday}
          >
            <CalendarIcon />
            Today's Grievances
            <ArrowRightIcon />
          </button>
        </section>

        {/* STATS */}

        <section className="stats-grid">
          <button
            type="button"
            className="stat-card"
            onClick={() =>
              setStatusQuery("")
            }
          >
            <div className="stat-card-top">
              <span className="stat-label">
                Total
              </span>

              <span className="stat-icon stat-icon-total">
                #
              </span>
            </div>

            <strong>
              {stats.total}
            </strong>

            <span className="stat-foot">
              All grievances
            </span>
          </button>

          <button
            type="button"
            className="stat-card"
            onClick={() =>
              setStatusQuery(
                "PENDING",
              )
            }
          >
            <div className="stat-card-top">
              <span className="stat-label">
                Pending
              </span>

              <span className="stat-icon stat-icon-pending">
                !
              </span>
            </div>

            <strong>
              {stats.pending}
            </strong>

            <span className="stat-foot">
              Awaiting assignment
            </span>
          </button>

          <button
            type="button"
            className="stat-card"
            onClick={() =>
              setStatusQuery(
                "IN_PROGRESS",
              )
            }
          >
            <div className="stat-card-top">
              <span className="stat-label">
                In Progress
              </span>

              <span className="stat-icon stat-icon-progress">
                ↗
              </span>
            </div>

            <strong>
              {stats.inProgress}
            </strong>

            <span className="stat-foot">
              Currently active
            </span>
          </button>

          <button
            type="button"
            className="stat-card"
            onClick={() =>
              setStatusQuery(
                "RESOLVED",
              )
            }
          >
            <div className="stat-card-top">
              <span className="stat-label">
                Resolved
              </span>

              <span className="stat-icon stat-icon-resolved">
                ✓
              </span>
            </div>

            <strong>
              {stats.resolved}
            </strong>

            <span className="stat-foot">
              Successfully resolved
            </span>
          </button>

          <button
            type="button"
            className="stat-card"
            onClick={() =>
              setStatusQuery(
                "CLOSED",
              )
            }
          >
            <div className="stat-card-top">
              <span className="stat-label">
                Closed
              </span>

              <span className="stat-icon stat-icon-closed">
                ✓
              </span>
            </div>

            <strong>
              {stats.closed}
            </strong>

            <span className="stat-foot">
              Completed cases
            </span>
          </button>

          <div className="stat-card stat-card-static">
            <div className="stat-card-top">
              <span className="stat-label">
                High Priority
              </span>

              <span className="stat-icon stat-icon-high">
                ↑
              </span>
            </div>

            <strong>
              {stats.highPriority}
            </strong>

            <span className="stat-foot">
              Need attention
            </span>
          </div>
        </section>

        {/* WORKSPACE */}

        <section className="workspace-card">
          <div className="workspace-header">
            <div>
              <h2>
                All Grievances
              </h2>

              <p>
                Search and filter the grievance
                register.
              </p>
            </div>

            <button
              type="button"
              className="filter-toggle"
              onClick={() =>
                setShowFilters(
                  (value) =>
                    !value,
                )
              }
            >
              <FilterIcon />
              Filters

              {activeFilterCount >
                0 && (
                <span className="filter-count">
                  {
                    activeFilterCount
                  }
                </span>
              )}
            </button>
          </div>

          {/* SEARCH */}

          <div className="search-row">
            <div className="search-box">
              <SearchIcon />

              <input
                type="search"
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value,
                  )
                }
                placeholder="Search by ID, citizen, title, village, mandal or department..."
              />

              {search && (
                <button
                  type="button"
                  className="search-clear"
                  onClick={() =>
                    setSearch("")
                  }
                  aria-label="Clear search"
                >
                  <CloseIcon />
                </button>
              )}
            </div>
          </div>

          {/* FILTER PANEL */}

          {showFilters && (
            <div className="filters-panel">
              <div className="filter-field">
                <label>Status</label>

                <select
                  value={
                    statusFilter
                  }
                  onChange={(
                    event,
                  ) =>
                    setStatusQuery(
                      event.target
                        .value,
                    )
                  }
                >
                  <option value="">
                    All Statuses
                  </option>

                  {[
                    "PENDING",
                    "ASSIGNED",
                    "IN_PROGRESS",
                    "RESOLVED",
                    "REJECTED",
                    "CLOSED",
                  ].map(
                    (status) => (
                      <option
                        key={status}
                        value={status}
                      >
                        {formatStatus(
                          status,
                        )}
                      </option>
                    ),
                  )}
                </select>
              </div>

              <div className="filter-field">
                <label>
                  Priority
                </label>

                <select
                  value={
                    priorityFilter
                  }
                  onChange={(
                    event,
                  ) =>
                    setPriorityFilter(
                      event.target
                        .value,
                    )
                  }
                >
                  <option value="">
                    All Priorities
                  </option>

                  <option value="LOW">
                    Low
                  </option>

                  <option value="MEDIUM">
                    Medium
                  </option>

                  <option value="HIGH">
                    High
                  </option>
                </select>
              </div>

              <div className="filter-field">
                <label>
                  Department
                </label>

                <select
                  value={
                    departmentFilter
                  }
                  onChange={(
                    event,
                  ) =>
                    setDepartmentFilter(
                      event.target
                        .value,
                    )
                  }
                >
                  <option value="">
                    All Departments
                  </option>

                  {departments.map(
                    (
                      department,
                    ) => (
                      <option
                        key={
                          department.id
                        }
                        value={
                          department.id
                        }
                      >
                        {
                          department.name
                        }
                      </option>
                    ),
                  )}
                </select>
              </div>

              <div className="filter-field">
                <label>
                  Mandal
                </label>

                <select
                  value={
                    mandalFilter
                  }
                  onChange={(
                    event,
                  ) =>
                    setMandalFilter(
                      event.target
                        .value,
                    )
                  }
                >
                  <option value="">
                    All Mandals
                  </option>

                  {mandals.map(
                    (mandal) => (
                      <option
                        key={
                          mandal.id
                        }
                        value={
                          mandal.id
                        }
                      >
                        {
                          mandal.name
                        }
                      </option>
                    ),
                  )}
                </select>
              </div>

              <div className="filter-field">
                <label>
                  Village
                </label>

                <select
                  value={
                    villageFilter
                  }
                  onChange={(
                    event,
                  ) =>
                    setVillageFilter(
                      event.target
                        .value,
                    )
                  }
                >
                  <option value="">
                    All Villages
                  </option>

                  {villages.map(
                    (village) => (
                      <option
                        key={
                          village.id
                        }
                        value={
                          village.id
                        }
                      >
                        {
                          village.name
                        }
                      </option>
                    ),
                  )}
                </select>
              </div>

              <button
                type="button"
                className="clear-filters-button"
                onClick={
                  clearFilters
                }
              >
                Clear Filters
              </button>
            </div>
          )}

          {/* MOBILE FILTERS */}

          <div className="mobile-filters">
            <select
              value={
                statusFilter
              }
              onChange={(event) =>
                setStatusQuery(
                  event.target
                    .value,
                )
              }
            >
              <option value="">
                Status: All
              </option>

              {[
                "PENDING",
                "ASSIGNED",
                "IN_PROGRESS",
                "RESOLVED",
                "REJECTED",
                "CLOSED",
              ].map(
                (status) => (
                  <option
                    key={status}
                    value={status}
                  >
                    {formatStatus(
                      status,
                    )}
                  </option>
                ),
              )}
            </select>

            <select
              value={
                priorityFilter
              }
              onChange={(event) =>
                setPriorityFilter(
                  event.target
                    .value,
                )
              }
            >
              <option value="">
                Priority: All
              </option>

              <option value="LOW">
                Low
              </option>

              <option value="MEDIUM">
                Medium
              </option>

              <option value="HIGH">
                High
              </option>
            </select>

            {canAssign && (
              <select
                value={
                  departmentFilter
                }
                onChange={(event) =>
                  setDepartmentFilter(
                    event.target
                      .value,
                  )
                }
              >
                <option value="">
                  Department: All
                </option>

                {departments.map(
                  (
                    department,
                  ) => (
                    <option
                      key={
                        department.id
                      }
                      value={
                        department.id
                      }
                    >
                      {
                        department.name
                      }
                    </option>
                  ),
                )}
              </select>
            )}
          </div>

          {/* ACTIVE FILTERS */}

          {hasFilters && (
            <div className="active-filters">
              <span className="active-label">
                Active filters:
              </span>

              {search && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setSearch("")
                  }
                >
                  Search: {search}
                  <CloseIcon />
                </button>
              )}

              {statusFilter && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setStatusQuery(
                      "",
                    )
                  }
                >
                  Status:{" "}
                  {formatStatus(
                    statusFilter,
                  )}
                  <CloseIcon />
                </button>
              )}

              {priorityFilter && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setPriorityFilter(
                      "",
                    )
                  }
                >
                  Priority:{" "}
                  {
                    PRIORITY_META[
                      normalizePriority(
                        priorityFilter,
                      )
                    ]?.label
                  }
                  <CloseIcon />
                </button>
              )}

              {departmentFilter && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setDepartmentFilter(
                      "",
                    )
                  }
                >
                  Department
                  <CloseIcon />
                </button>
              )}

              {mandalFilter && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setMandalFilter(
                      "",
                    )
                  }
                >
                  Mandal
                  <CloseIcon />
                </button>
              )}

              {villageFilter && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={() =>
                    setVillageFilter(
                      "",
                    )
                  }
                >
                  Village
                  <CloseIcon />
                </button>
              )}

              {dateQuery ===
                "today" && (
                <button
                  type="button"
                  className="filter-chip"
                  onClick={
                    removeDateFilter
                  }
                >
                  Date: Today
                  <CloseIcon />
                </button>
              )}

              <button
                type="button"
                className="clear-inline"
                onClick={
                  clearFilters
                }
              >
                Clear all
              </button>
            </div>
          )}

          {/* RESULTS */}

          <div className="results-bar">
            <div className="results-count">
              <strong>
                {
                  filteredGrievances.length
                }
              </strong>

              <span>
                {filteredGrievances.length ===
                1
                  ? "grievance"
                  : "grievances"}{" "}
                found
              </span>
            </div>

            {error && (
              <span className="inline-error">
                {error}
              </span>
            )}
          </div>

          {/* EMPTY */}

          {!filteredGrievances.length ? (
            <div className="empty-state">
              <div className="empty-icon">
                ◎
              </div>

              <h3>
                No grievances found
              </h3>

              <p>
                {hasFilters
                  ? "Try changing or clearing your filters."
                  : "There are no grievances available for your account."}
              </p>

              {hasFilters && (
                <button
                  type="button"
                  className="primary-button"
                  onClick={
                    clearFilters
                  }
                >
                  Clear Filters
                </button>
              )}
            </div>
          ) : (
            <>
              {/* DESKTOP TABLE */}

              <div className="table-wrap">
                <table className="grievance-table">
                  <thead>
                    <tr>
                      <th>
                        Case / Citizen
                      </th>
                      <th>
                        Location
                      </th>
                      <th>
                        Department / Officer
                      </th>
                      <th>Status</th>
                      <th>
                        Priority
                      </th>
                      <th>
                        Registered
                      </th>
                      <th>Action</th>
                      <th />
                    </tr>
                  </thead>

                  <tbody>
                    {filteredGrievances.map(
                      (item) => {
                        const id =
                          String(
                            item.id,
                          );

                        const status =
                          normalizeStatus(
                            item.status,
                          );

                        const priority =
                          normalizePriority(
                            item.priority,
                          );

                        const statusMeta =
                          STATUS_META[
                            status
                          ] ||
                          STATUS_META.PENDING;

                        const priorityMeta =
                          PRIORITY_META[
                            priority
                          ] ||
                          PRIORITY_META.MEDIUM;

                        const actions =
                          getAllowedActions(
                            status,
                          );

                        const isBusy =
                          actionId ===
                          id;

                        const isAssigning =
                          assigningId ===
                          id;

                        const hasAssignedOfficer =
                          Boolean(
                            item
                              .assignedTo
                              ?.id,
                          );

                        return (
                          <tr key={id}>
                            <td>
                              <div className="case-cell">
                                <div className="case-avatar">
                                  {getInitials(
                                    item.citizenName,
                                  )}
                                </div>

                                <div className="case-info">
                                  <button
                                    type="button"
                                    className="case-title"
                                    onClick={() =>
                                      openDetails(
                                        id,
                                      )
                                    }
                                  >
                                    {item.title ||
                                      "Untitled grievance"}
                                  </button>

                                  <div className="case-id">
                                    #{id}
                                  </div>

                                  <div className="citizen-name">
                                    <UserIcon />

                                    {item.citizenName ||
                                      "Citizen"}

                                    {item.citizenMobile && (
                                      <>
                                        {" · "}
                                        {
                                          item.citizenMobile
                                        }
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>

                            <td>
                              <div className="location-cell">
                                <div className="location-line">
                                  <MapPinIcon />

                                  <span>
                                    {item
                                      .village
                                      ?.name ||
                                      "—"}
                                  </span>
                                </div>

                                <div className="location-sub">
                                  {item
                                    .mandal
                                    ?.name ||
                                    "Mandal —"}
                                </div>
                              </div>
                            </td>

                            <td>
                              <div className="department-cell">
                                <strong>
                                  {item
                                    .department
                                    ?.name ||
                                    "Unassigned"}
                                </strong>

                                {hasAssignedOfficer ? (
                                  <span className="assigned-officer">
                                    <UserIcon />

                                    {item
                                      .assignedTo
                                      ?.name ||
                                      "Officer"}
                                  </span>
                                ) : (
                                  <span className="unassigned-text">
                                    No officer assigned
                                  </span>
                                )}
                              </div>
                            </td>

                            <td>
                              <span
                                className="status-badge"
                                style={{
                                  background:
                                    statusMeta.bg,
                                  color:
                                    statusMeta.color,
                                  borderColor:
                                    statusMeta.border,
                                }}
                              >
                                <span
                                  className="status-dot"
                                  style={{
                                    background:
                                      statusMeta.dot,
                                  }}
                                />

                                {
                                  statusMeta.label
                                }
                              </span>
                            </td>

                            <td>
                              <span
                                className="priority-badge"
                                style={{
                                  background:
                                    priorityMeta.bg,
                                  color:
                                    priorityMeta.color,
                                  borderColor:
                                    priorityMeta.border,
                                }}
                              >
                                {
                                  priorityMeta.label
                                }
                              </span>
                            </td>

                            <td>
                              <div className="date-cell">
                                <CalendarIcon />

                                {formatDate(
                                  item.createdAt,
                                )}
                              </div>
                            </td>

                            <td>
                              {canAssign &&
                              status ===
                                "PENDING" ? (
                                <div className="assign-box">
                                  <select
                                    value={
                                      selectedOfficer[
                                        id
                                      ] ||
                                      ""
                                    }
                                    onChange={(
                                      event,
                                    ) =>
                                      setSelectedOfficer(
                                        (
                                          current,
                                        ) => ({
                                          ...current,
                                          [id]:
                                            event
                                              .target
                                              .value,
                                        }),
                                      )
                                    }
                                    disabled={
                                      isAssigning
                                    }
                                  >
                                    <option value="">
                                      Select officer
                                    </option>

                                    {officers.map(
                                      (
                                        officer,
                                      ) => (
                                        <option
                                          key={
                                            officer.id
                                          }
                                          value={
                                            officer.id
                                          }
                                        >
                                          {
                                            officer.name
                                          }
                                        </option>
                                      ),
                                    )}
                                  </select>

                                  <button
                                    type="button"
                                    className="small-primary"
                                    onClick={() =>
                                      void assignOfficer(
                                        id,
                                      )
                                    }
                                    disabled={
                                      isAssigning ||
                                      !selectedOfficer[
                                        id
                                      ]
                                    }
                                  >
                                    {isAssigning
                                      ? "Assigning..."
                                      : "Assign"}
                                  </button>
                                </div>
                              ) : actions.length >
                                0 ? (
                                <div className="action-buttons">
                                  {actions.map(
                                    (
                                      action,
                                    ) => (
                                      <button
                                        key={
                                          action.status
                                        }
                                        type="button"
                                        className={`status-action ${action.variant}`}
                                        onClick={() =>
                                          void changeStatus(
                                            id,
                                            action.status,
                                          )
                                        }
                                        disabled={
                                          isBusy
                                        }
                                      >
                                        {isBusy
                                          ? "Updating..."
                                          : action.label}
                                      </button>
                                    ),
                                  )}
                                </div>
                              ) : (
                                <span className="no-action">
                                  —
                                </span>
                              )}
                            </td>

                            <td>
                              <div className="row-actions">
                                <button
                                  type="button"
                                  className="view-button"
                                  onClick={() =>
                                    openDetails(
                                      id,
                                    )
                                  }
                                >
                                  View
                                </button>

                                {canUndo &&
                                  status !==
                                    "PENDING" &&
                                  status !==
                                    "CLOSED" && (
                                    <button
                                      type="button"
                                      className="undo-button"
                                      onClick={() =>
                                        void undoStatus(
                                          id,
                                        )
                                      }
                                      disabled={
                                        isBusy
                                      }
                                      title="Undo last assignment/status change"
                                    >
                                      <UndoIcon />
                                    </button>
                                  )}
                              </div>
                            </td>
                          </tr>
                        );
                      },
                    )}
                  </tbody>
                </table>
              </div>

              {/* MOBILE CARDS */}

              <div className="mobile-cards">
                {filteredGrievances.map(
                  (item) => {
                    const id =
                      String(
                        item.id,
                      );

                    const status =
                      normalizeStatus(
                        item.status,
                      );

                    const priority =
                      normalizePriority(
                        item.priority,
                      );

                    const statusMeta =
                      STATUS_META[
                        status
                      ] ||
                      STATUS_META.PENDING;

                    const priorityMeta =
                      PRIORITY_META[
                        priority
                      ] ||
                      PRIORITY_META.MEDIUM;

                    const actions =
                      getAllowedActions(
                        status,
                      );

                    const isBusy =
                      actionId ===
                      id;

                    const isAssigning =
                      assigningId ===
                      id;

                    return (
                      <article
                        className="mobile-grievance-card"
                        key={id}
                      >
                        <div className="mobile-card-top">
                          <div className="mobile-case-main">
                            <div className="case-avatar">
                              {getInitials(
                                item.citizenName,
                              )}
                            </div>

                            <div>
                              <button
                                type="button"
                                className="case-title"
                                onClick={() =>
                                  openDetails(
                                    id,
                                  )
                                }
                              >
                                {item.title ||
                                  "Untitled grievance"}
                              </button>

                              <div className="case-id">
                                #{id}
                              </div>
                            </div>
                          </div>

                          <span
                            className="status-badge"
                            style={{
                              background:
                                statusMeta.bg,
                              color:
                                statusMeta.color,
                              borderColor:
                                statusMeta.border,
                            }}
                          >
                            <span
                              className="status-dot"
                              style={{
                                background:
                                  statusMeta.dot,
                              }}
                            />

                            {
                              statusMeta.label
                            }
                          </span>
                        </div>

                        <div className="mobile-citizen">
                          <UserIcon />

                          <strong>
                            {item.citizenName ||
                              "Citizen"}
                          </strong>

                          {item.citizenMobile && (
                            <span>
                              ·{" "}
                              {
                                item.citizenMobile
                              }
                            </span>
                          )}
                        </div>

                        <div className="mobile-details-grid">
                          <div>
                            <span>
                              Location
                            </span>

                            <strong>
                              {item
                                .village
                                ?.name ||
                                "—"}
                            </strong>

                            <small>
                              {item
                                .mandal
                                ?.name ||
                                "—"}
                            </small>
                          </div>

                          <div>
                            <span>
                              Department
                            </span>

                            <strong>
                              {item
                                .department
                                ?.name ||
                                "Unassigned"}
                            </strong>

                            <small>
                              {item
                                .assignedTo
                                ?.name ||
                                "No officer"}
                            </small>
                          </div>

                          <div>
                            <span>
                              Priority
                            </span>

                            <strong
                              style={{
                                color:
                                  priorityMeta.color,
                              }}
                            >
                              {
                                priorityMeta.label
                              }
                            </strong>
                          </div>

                          <div>
                            <span>
                              Registered
                            </span>

                            <strong>
                              {formatDate(
                                item.createdAt,
                              )}
                            </strong>
                          </div>
                        </div>

                        {canAssign &&
                          status ===
                            "PENDING" && (
                            <div className="mobile-assign">
                              <select
                                value={
                                  selectedOfficer[
                                    id
                                  ] ||
                                  ""
                                }
                                onChange={(
                                  event,
                                ) =>
                                  setSelectedOfficer(
                                    (
                                      current,
                                    ) => ({
                                      ...current,
                                      [id]:
                                        event
                                          .target
                                          .value,
                                    }),
                                  )
                                }
                                disabled={
                                  isAssigning
                                }
                              >
                                <option value="">
                                  Select officer
                                </option>

                                {officers.map(
                                  (
                                    officer,
                                  ) => (
                                    <option
                                      key={
                                        officer.id
                                      }
                                      value={
                                        officer.id
                                      }
                                    >
                                      {
                                        officer.name
                                      }
                                    </option>
                                  ),
                                )}
                              </select>

                              <button
                                type="button"
                                className="small-primary"
                                onClick={() =>
                                  void assignOfficer(
                                    id,
                                  )
                                }
                                disabled={
                                  isAssigning ||
                                  !selectedOfficer[
                                    id
                                  ]
                                }
                              >
                                {isAssigning
                                  ? "Assigning..."
                                  : "Assign"}
                              </button>
                            </div>
                          )}

                        <div className="mobile-actions">
                          <button
                            type="button"
                            className="view-button"
                            onClick={() =>
                              openDetails(
                                id,
                              )
                            }
                          >
                            View Details
                          </button>

                          {actions.map(
                            (
                              action,
                            ) => (
                              <button
                                key={
                                  action.status
                                }
                                type="button"
                                className={`status-action ${action.variant}`}
                                onClick={() =>
                                  void changeStatus(
                                    id,
                                    action.status,
                                  )
                                }
                                disabled={
                                  isBusy
                                }
                              >
                                {isBusy
                                  ? "Updating..."
                                  : action.label}
                              </button>
                            ),
                          )}

                          {canUndo &&
                            status !==
                              "PENDING" &&
                            status !==
                              "CLOSED" && (
                              <button
                                type="button"
                                className="undo-mobile-button"
                                onClick={() =>
                                  void undoStatus(
                                    id,
                                  )
                                }
                                disabled={
                                  isBusy
                                }
                              >
                                <UndoIcon />
                                Undo
                              </button>
                            )}
                        </div>
                      </article>
                    );
                  },
                )}
              </div>
            </>
          )}

          {/* FOOTER */}

          <div className="table-footer">
            <span>
              Showing{" "}
              <strong>
                {
                  filteredGrievances.length
                }
              </strong>{" "}
              of{" "}
              <strong>
                {grievances.length}
              </strong>{" "}
              grievances
            </span>

            <span className="footer-role">
              Access scope:{" "}
              <strong>
                {role || "USER"}
              </strong>
            </span>
          </div>
        </section>

        {/* TOAST */}

        {toast && (
          <div
            className={`toast toast-${toast.type}`}
            role="status"
          >
            <span className="toast-icon">
              {toast.type ===
              "success" ? (
                <CheckIcon />
              ) : toast.type ===
                "error" ? (
                <AlertIcon />
              ) : (
                "i"
              )}
            </span>

            <span>
              {toast.message}
            </span>

            <button
              type="button"
              onClick={() =>
                setToast(null)
              }
              aria-label="Close notification"
            >
              <CloseIcon />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* =====================================================
   LOADING STYLES
===================================================== */

const loadingStyles = `
.loading-page {
  min-height: 100vh;
  background: #f8fafc;
  padding: 32px;
}

.loading-inner {
  max-width: 1400px;
  margin: 0 auto;
}

.loading-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 44px;
}

.loading-logo {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  background: #e5e7eb;
}

.loading-line,
.loading-card,
.loading-row div {
  background: linear-gradient(
    90deg,
    #e5e7eb,
    #f3f4f6,
    #e5e7eb
  );
  background-size: 200% 100%;
  animation: loadingShimmer 1.4s infinite;
}

.loading-line {
  height: 12px;
  border-radius: 8px;
}

.brand-line {
  width: 150px;
}

.small-line {
  width: 90px;
  margin-top: 8px;
}

.loading-hero {
  margin-bottom: 28px;
}

.title-line {
  width: 280px;
  height: 28px;
}

.text-line {
  width: 420px;
  margin-top: 12px;
}

.loading-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.loading-card {
  height: 130px;
  border-radius: 18px;
}

.loading-table {
  background: white;
  border-radius: 18px;
  padding: 20px;
}

.loading-row {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 20px;
  padding: 20px 0;
  border-bottom: 1px solid #f1f5f9;
}

.loading-row div {
  height: 18px;
  border-radius: 6px;
}

@keyframes loadingShimmer {
  0% {
    background-position: 200% 0;
  }

  100% {
    background-position: -200% 0;
  }
}

@media (max-width: 800px) {
  .loading-page {
    padding: 20px;
  }

  .loading-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .loading-row {
    grid-template-columns: 1fr 1fr;
  }
}
`;

/* =====================================================
   ERROR STYLES
===================================================== */

const errorStyles = `
.error-page {
  min-height: 100vh;
  background: #f8fafc;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.error-card {
  width: min(460px, 100%);
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 20px;
  padding: 36px;
  text-align: center;
  box-shadow:
    0 20px 60px
    rgba(15, 23, 42, 0.08);
}

.error-icon {
  width: 48px;
  height: 48px;
  margin: 0 auto 18px;
  border-radius: 14px;
  display: grid;
  place-items: center;
  background: #fef2f2;
  color: #dc2626;
}

.error-card h2 {
  margin: 0 0 10px;
  font-size: 22px;
  color: #111827;
}

.error-card p {
  margin: 0 0 24px;
  color: #64748b;
  line-height: 1.6;
}
`;

/* =====================================================
   MAIN PAGE STYLES
===================================================== */

const pageStyles = `
/* Prevent the page itself from creating an unwanted horizontal scroll.
   Wide data tables get their own horizontal scrollbar instead. */
.grievances-page,
.grievances-page * {
  box-sizing: border-box;
}

.grievances-page {
  width: 100%;
  min-width: 0;
  min-height: 100vh;
  overflow-x: hidden;
  background: #f8fafc;
  color: #111827;
}

.page-shell {
  width: 100%;
  max-width: 1500px;
  min-width: 0;
  margin: 0 auto;
  padding: 30px;
}

.page-topbar {
  width: 100%;
  min-width: 0;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 28px;
}

.page-kicker,
.hero-eyebrow {
  color: #64748b;
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 0.14em;
  text-transform: uppercase;
}

.page-title {
  margin: 6px 0 5px;
  font-size: 32px;
  line-height: 1.1;
  letter-spacing: -0.03em;
}

.page-subtitle {
  margin: 0;
  color: #64748b;
  font-size: 14px;
}

.topbar-actions {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  flex-wrap: wrap;
  min-width: 0;
}

.refresh-button,
.filter-toggle {
  min-height: 42px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  background: white;
  color: #334155;
  padding: 0 14px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 700;
  cursor: pointer;
}

.refresh-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.primary-button {
  min-height: 42px;
  border: 0;
  border-radius: 10px;
  padding: 11px 17px;
  background: #111827;
  color: white;
  font-weight: 700;
  cursor: pointer;
}

.primary-button:hover {
  opacity: 0.92;
}

.grievances-hero {
  width: 100%;
  min-width: 0;
  background: #111827;
  color: white;
  border-radius: 22px;
  padding: 28px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 18px;
}

.grievances-hero .hero-eyebrow {
  color: #94a3b8;
}

.grievances-hero h2 {
  margin: 8px 0;
  font-size: 25px;
  letter-spacing: -0.02em;
}

.grievances-hero p {
  margin: 0;
  max-width: 650px;
  color: #cbd5e1;
  line-height: 1.6;
}

.hero-today-button {
  flex-shrink: 0;
  min-height: 44px;
  border: 1px solid #475569;
  background: #1f2937;
  color: white;
  border-radius: 11px;
  padding: 0 15px;
  display: flex;
  align-items: center;
  gap: 9px;
  cursor: pointer;
  font-weight: 700;
}

.stats-grid {
  width: 100%;
  min-width: 0;
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 18px;
}

.stat-card {
  min-width: 0;
  border: 1px solid #e2e8f0;
  border-radius: 16px;
  background: white;
  padding: 17px;
  text-align: left;
  cursor: pointer;
}

.stat-card-static {
  cursor: default;
}

.stat-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.stat-label {
  color: #64748b;
  font-size: 12px;
  font-weight: 700;
}

.stat-card strong {
  display: block;
  margin-top: 9px;
  font-size: 27px;
}

.stat-foot {
  display: block;
  margin-top: 3px;
  color: #94a3b8;
  font-size: 11px;
}

.stat-icon {
  width: 28px;
  height: 28px;
  border-radius: 9px;
  display: grid;
  place-items: center;
  font-size: 13px;
  font-weight: 900;
}

.stat-icon-total {
  background: #f1f5f9;
  color: #475569;
}

.stat-icon-pending {
  background: #fff7ed;
  color: #ea580c;
}

.stat-icon-progress {
  background: #f5f3ff;
  color: #7c3aed;
}

.stat-icon-resolved {
  background: #ecfdf5;
  color: #059669;
}

.stat-icon-closed {
  background: #f1f5f9;
  color: #475569;
}

.stat-icon-high {
  background: #fff1f2;
  color: #e11d48;
}

.workspace-card {
  width: 100%;
  min-width: 0;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 20px;
  overflow: hidden;
}

.workspace-header {
  padding: 22px 22px 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
}

.workspace-header h2 {
  margin: 0;
  font-size: 19px;
}

.workspace-header p {
  margin: 5px 0 0;
  color: #94a3b8;
  font-size: 13px;
}

.filter-count {
  min-width: 20px;
  height: 20px;
  border-radius: 999px;
  background: #111827;
  color: white;
  display: inline-grid;
  place-items: center;
  font-size: 10px;
}

.search-row {
  padding: 0 22px 15px;
}

.search-box {
  height: 44px;
  border: 1px solid #e2e8f0;
  border-radius: 11px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 13px;
  color: #94a3b8;
  background: #f8fafc;
}

.search-box:focus-within {
  border-color: #94a3b8;
  background: white;
}

.search-box input {
  flex: 1;
  min-width: 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: #111827;
  font-size: 13px;
}

.search-clear {
  border: 0;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
}

.filters-panel {
  padding: 0 22px 17px;
  display: grid;
  grid-template-columns:
    repeat(5, minmax(0, 1fr))
    auto;
  gap: 10px;
}

.filter-field {
  min-width: 0;
}

.filter-field label {
  display: block;
  margin-bottom: 6px;
  color: #64748b;
  font-size: 11px;
  font-weight: 700;
}

.filter-field select,
.mobile-filters select,
.assign-box select,
.mobile-assign select {
  width: 100%;
  height: 39px;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  background: white;
  color: #334155;
  padding: 0 10px;
  outline: none;
  font-size: 12px;
}

.clear-filters-button {
  align-self: end;
  height: 39px;
  border: 0;
  border-radius: 9px;
  background: #f1f5f9;
  color: #475569;
  padding: 0 12px;
  font-weight: 700;
  cursor: pointer;
}

.mobile-filters {
  display: none;
}

.active-filters {
  padding: 0 22px 15px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 7px;
}

.active-label {
  color: #94a3b8;
  font-size: 11px;
  font-weight: 700;
}

.filter-chip {
  min-height: 27px;
  border: 1px solid #e2e8f0;
  border-radius: 999px;
  background: #f8fafc;
  color: #475569;
  padding: 0 9px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  cursor: pointer;
}

.clear-inline {
  border: 0;
  background: transparent;
  color: #dc2626;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
}

.results-bar {
  min-height: 48px;
  padding: 0 22px;
  border-top: 1px solid #f1f5f9;
  border-bottom: 1px solid #f1f5f9;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.results-count {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #64748b;
  font-size: 12px;
}

.results-count strong {
  color: #111827;
}

.inline-error {
  color: #dc2626;
  font-size: 11px;
}

.table-wrap {
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: auto;
  scrollbar-color: #94a3b8 #f1f5f9;
}

.table-wrap::-webkit-scrollbar {
  height: 10px;
}

.table-wrap::-webkit-scrollbar-track {
  background: #f1f5f9;
}

.table-wrap::-webkit-scrollbar-thumb {
  background: #94a3b8;
  border-radius: 999px;
  border: 2px solid #f1f5f9;
}

.table-wrap::-webkit-scrollbar-thumb:hover {
  background: #64748b;
}

.grievance-table {
  width: 100%;
  min-width: 1150px;
  max-width: none;
  border-collapse: collapse;
}

.grievance-table th {
  padding: 12px 14px;
  background: #f8fafc;
  color: #64748b;
  text-align: left;
  font-size: 10px;
  font-weight: 800;
  text-transform: uppercase;
}

.grievance-table td {
  padding: 15px 14px;
  border-top: 1px solid #f1f5f9;
  vertical-align: middle;
}

.case-cell {
  min-width: 220px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.case-avatar {
  flex-shrink: 0;
  width: 36px;
  height: 36px;
  border-radius: 11px;
  background: #eef2ff;
  color: #4f46e5;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 900;
}

.case-info {
  min-width: 0;
}

.case-title {
  display: block;
  max-width: 270px;
  overflow: hidden;
  border: 0;
  background: transparent;
  color: #111827;
  padding: 0;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 13px;
  font-weight: 800;
  cursor: pointer;
}

.case-title:hover {
  color: #4f46e5;
}

.case-id {
  margin-top: 3px;
  color: #94a3b8;
  font-size: 10px;
}

.citizen-name {
  margin-top: 5px;
  display: flex;
  align-items: center;
  gap: 4px;
  color: #64748b;
  font-size: 10px;
}

.location-cell,
.department-cell {
  min-width: 130px;
}

.location-line {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #334155;
  font-size: 12px;
  font-weight: 700;
}

.location-sub {
  margin-top: 4px;
  color: #94a3b8;
  font-size: 10px;
}

.department-cell strong {
  display: block;
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #334155;
  font-size: 11px;
}

.assigned-officer,
.unassigned-text {
  margin-top: 5px;
  display: flex;
  align-items: center;
  gap: 4px;
  color: #64748b;
  font-size: 10px;
}

.unassigned-text {
  color: #94a3b8;
}

.status-badge,
.priority-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 1px solid;
  border-radius: 999px;
  padding: 5px 8px;
  white-space: nowrap;
  font-size: 10px;
  font-weight: 800;
}

.status-dot {
  width: 5px;
  height: 5px;
  border-radius: 999px;
}

.date-cell {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #64748b;
  font-size: 10px;
  white-space: nowrap;
}

.assign-box {
  width: 175px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.assign-box select {
  height: 33px;
}

.small-primary {
  height: 31px;
  border: 0;
  border-radius: 8px;
  background: #111827;
  color: white;
  padding: 0 9px;
  font-size: 10px;
  font-weight: 800;
  cursor: pointer;
}

.small-primary:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.action-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.status-action,
.view-button,
.undo-button,
.undo-mobile-button {
  border: 0;
  border-radius: 8px;
  min-height: 31px;
  padding: 0 9px;
  font-size: 10px;
  font-weight: 800;
  cursor: pointer;
  white-space: nowrap;
}

.status-action:disabled,
.undo-button:disabled,
.undo-mobile-button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.status-action.primary {
  background: #eef2ff;
  color: #4338ca;
}

.status-action.success {
  background: #ecfdf5;
  color: #047857;
}

.status-action.danger {
  background: #fef2f2;
  color: #b91c1c;
}

.status-action.neutral {
  background: #f1f5f9;
  color: #334155;
}

.view-button {
  background: #f1f5f9;
  color: #334155;
}

.undo-button {
  width: 31px;
  padding: 0;
  background: #fff7ed;
  color: #c2410c;
  display: inline-grid;
  place-items: center;
}

.row-actions {
  display: flex;
  align-items: center;
  gap: 5px;
}

.no-action {
  color: #cbd5e1;
}

.mobile-cards {
  display: none;
}

.empty-state {
  padding: 70px 24px;
  text-align: center;
}

.empty-icon {
  width: 50px;
  height: 50px;
  margin: 0 auto 14px;
  border-radius: 16px;
  background: #f1f5f9;
  color: #64748b;
  display: grid;
  place-items: center;
  font-size: 24px;
}

.empty-state h3 {
  margin: 0 0 7px;
  font-size: 17px;
}

.empty-state p {
  margin: 0 auto 18px;
  max-width: 430px;
  color: #94a3b8;
  font-size: 13px;
  line-height: 1.6;
}

.table-footer {
  min-height: 50px;
  border-top: 1px solid #f1f5f9;
  padding: 0 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  color: #94a3b8;
  font-size: 11px;
}

.table-footer strong {
  color: #475569;
}

.footer-role {
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.toast {
  position: fixed;
  right: 24px;
  bottom: 24px;
  z-index: 100;
  min-width: 300px;
  max-width: 450px;
  padding: 13px 14px;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  background: white;
  box-shadow:
    0 18px 45px
    rgba(15, 23, 42, 0.15);
  display: flex;
  align-items: center;
  gap: 9px;
  color: #334155;
  font-size: 12px;
  font-weight: 700;
}

.toast-icon {
  width: 27px;
  height: 27px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.toast-success .toast-icon {
  background: #ecfdf5;
  color: #059669;
}

.toast-error .toast-icon {
  background: #fef2f2;
  color: #dc2626;
}

.toast-info .toast-icon {
  background: #eff6ff;
  color: #2563eb;
}

.toast > span:nth-child(2) {
  flex: 1;
}

.toast button {
  border: 0;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
}

.mobile-assign {
  display: flex;
  gap: 7px;
  margin-top: 13px;
}

.mobile-assign select {
  flex: 1;
}

.mobile-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  margin-top: 14px;
  padding-top: 13px;
  border-top: 1px solid #f1f5f9;
}

.undo-mobile-button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #fff7ed;
  color: #c2410c;
}

@media (max-width: 1250px) {
  .page-topbar {
    align-items: flex-start;
    flex-direction: column;
  }

  .topbar-actions {
    width: 100%;
    justify-content: flex-start;
  }

  .grievances-hero {
    align-items: flex-start;
  }

  .stats-grid {
    grid-template-columns: repeat(3, 1fr);
  }

  .filters-panel {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 900px) {
  .page-shell {
    padding: 20px;
  }

  .page-topbar,
  .grievances-hero {
    align-items: flex-start;
    flex-direction: column;
  }

  .topbar-actions {
    width: 100%;
  }

  .topbar-actions button {
    flex: 1;
  }

  .hero-today-button {
    width: 100%;
    justify-content: center;
  }

  .table-wrap {
    display: none;
  }

  .mobile-cards {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    background: #f8fafc;
  }

  .mobile-grievance-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    padding: 15px;
  }

  .mobile-card-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  }

  .mobile-case-main {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 9px;
  }

  .mobile-case-main .case-title {
    max-width: 230px;
  }

  .mobile-citizen {
    margin-top: 12px;
    display: flex;
    align-items: center;
    gap: 5px;
    color: #64748b;
    font-size: 11px;
  }

  .mobile-details-grid {
    margin-top: 14px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
  }

  .mobile-details-grid > div {
    padding: 10px;
    border-radius: 10px;
    background: #f8fafc;
  }

  .mobile-details-grid span,
  .mobile-details-grid small,
  .mobile-details-grid strong {
    display: block;
  }

  .mobile-details-grid span {
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
  }

  .mobile-details-grid strong {
    margin-top: 4px;
    color: #334155;
    font-size: 11px;
  }

  .mobile-details-grid small {
    margin-top: 3px;
    color: #94a3b8;
    font-size: 9px;
  }

  .filters-panel {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 600px) {
  .page-shell {
    padding: 14px;
  }

  .page-title {
    font-size: 27px;
  }

  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .grievances-hero {
    padding: 21px;
    border-radius: 17px;
  }

  .grievances-hero h2 {
    font-size: 21px;
  }

  .workspace-header,
  .search-row,
  .active-filters {
    padding-left: 14px;
    padding-right: 14px;
  }

  .results-bar {
    padding: 0 14px;
  }

  .filters-panel {
    display: none;
  }

  .mobile-filters {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 7px;
    padding: 0 14px 13px;
  }

  .mobile-filters select:last-child {
    grid-column: 1 / -1;
  }

  .mobile-actions .status-action,
  .mobile-actions .view-button,
  .mobile-actions .undo-mobile-button {
    flex: 1;
  }

  .table-footer {
    padding: 0 14px;
    align-items: flex-start;
    flex-direction: column;
    justify-content: center;
    gap: 4px;
  }

  .toast {
    right: 14px;
    left: 14px;
    bottom: 14px;
    min-width: 0;
  }
}

@media (max-width: 420px) {
  .stats-grid {
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  .stat-card {
    padding: 13px;
  }

  .stat-card strong {
    font-size: 23px;
  }

  .topbar-actions {
    flex-direction: column;
  }

  .topbar-actions button {
    width: 100%;
  }

  .mobile-details-grid {
    grid-template-columns: 1fr;
  }

  .mobile-actions {
    flex-direction: column;
  }

  .mobile-actions .status-action,
  .mobile-actions .view-button,
  .mobile-actions .undo-mobile-button {
    width: 100%;
    flex: unset;
  }
}
`;

/* =====================================================
   INJECT PAGE STYLES
===================================================== */

if (
  typeof document !==
  "undefined"
) {
  const STYLE_ID =
    "grievances-page-styles";

  if (
    !document.getElementById(
      STYLE_ID,
    )
  ) {
    const style =
      document.createElement(
        "style",
      );

    style.id = STYLE_ID;
    style.textContent =
      pageStyles;

    document.head.appendChild(
      style,
    );
  }
}
