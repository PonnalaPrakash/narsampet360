
import { useState, useEffect } from "react";
import client from "../api/client";

export default function Login() {
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  // =====================================================
  // CHECK EXISTING LOGIN
  // =====================================================

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    const savedRole = localStorage.getItem("role");

    if (token) {
      const role = savedRole?.toUpperCase();

      if (role === "OFFICER") {
        window.location.href = "/officer-dashboard";
      } else {
        window.location.href = "/dashboard";
      }
    }
  }, []);

  // =====================================================
  // SEND OTP
  // =====================================================

  async function sendOtp() {
    if (!mobile.trim()) {
      setMessage("Please enter mobile number");
      return;
    }

    if (mobile.trim().length !== 10) {
      setMessage("Please enter a valid 10-digit mobile number");
      return;
    }

    try {
      setLoading(true);
      setMessage("");

      await client.post("/auth/send-otp", {
        mobile: mobile.trim(),
      });

      setStep(2);
      setMessage("OTP sent. Check backend terminal.");
    } catch (err: any) {
      setMessage(
        err.response?.data?.message || "Failed to send OTP"
      );
    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // VERIFY OTP
  // =====================================================

  async function verifyOtp() {
    if (!otp.trim()) {
      setMessage("Please enter OTP");
      return;
    }

    if (otp.trim().length !== 6) {
      setMessage("Please enter the 6-digit OTP");
      return;
    }

    try {
      setLoading(true);
      setMessage("");

      const res = await client.post("/auth/verify-otp", {
        mobile: mobile.trim(),
        otp: otp.trim(),
      });

      const user = res.data.user;
      const role = user?.role?.toUpperCase();

      // =================================================
      // SAVE LOGIN INFORMATION
      // =================================================

      localStorage.setItem(
        "accessToken",
        res.data.accessToken
      );

      localStorage.setItem(
        "refreshToken",
        res.data.refreshToken
      );

      localStorage.setItem(
        "user",
        JSON.stringify(user)
      );

      localStorage.setItem("role", role);

      // =================================================
      // ROLE BASED REDIRECT
      // =================================================

      if (role === "OFFICER") {
        window.location.href = "/officer-dashboard";
      } else {
        window.location.href = "/dashboard";
      }
    } catch (err: any) {
      setMessage(
        err.response?.data?.message || "Invalid OTP"
      );
    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // UI
  // =====================================================

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
        boxSizing: "border-box",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        background:
          "radial-gradient(circle at 15% 15%, rgba(59,130,246,0.22), transparent 28%), radial-gradient(circle at 85% 85%, rgba(14,165,233,0.18), transparent 30%), linear-gradient(135deg, #071426 0%, #0b1f3a 45%, #102d52 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* =================================================
          BACKGROUND DECORATION
      ================================================= */}

      <div
        style={{
          position: "absolute",
          width: 420,
          height: 420,
          borderRadius: "50%",
          border: "1px solid rgba(255,255,255,0.08)",
          top: "-180px",
          left: "-150px",
        }}
      />

      <div
        style={{
          position: "absolute",
          width: 620,
          height: 620,
          borderRadius: "50%",
          border: "1px solid rgba(255,255,255,0.05)",
          bottom: "-330px",
          right: "-260px",
        }}
      />

      <div
        style={{
          position: "absolute",
          width: 260,
          height: 260,
          borderRadius: "50%",
          background:
            "rgba(37, 99, 235, 0.12)",
          filter: "blur(60px)",
          top: "12%",
          right: "8%",
        }}
      />

      {/* =================================================
          MAIN CARD
      ================================================= */}

      <div
        style={{
          width: "100%",
          maxWidth: 1020,
          minHeight: 600,
          display: "grid",
          gridTemplateColumns:
            "minmax(0, 1.05fr) minmax(360px, 0.95fr)",
          borderRadius: 30,
          overflow: "hidden",
          background: "rgba(255,255,255,0.96)",
          boxShadow:
            "0 35px 90px rgba(0,0,0,0.35), 0 10px 30px rgba(0,0,0,0.15)",
          position: "relative",
          zIndex: 2,
          backdropFilter: "blur(20px)",
        }}
      >
        {/* =================================================
            LEFT BRAND PANEL
        ================================================= */}

        <div
          style={{
            position: "relative",
            padding: "58px 52px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            color: "#fff",
            overflow: "hidden",
            background:
              "linear-gradient(145deg, #0b2a55 0%, #0d47a1 48%, #1565c0 100%)",
          }}
        >
          {/* Decorative circles */}

          <div
            style={{
              position: "absolute",
              width: 330,
              height: 330,
              borderRadius: "50%",
              border:
                "1px solid rgba(255,255,255,0.12)",
              right: -150,
              top: -110,
            }}
          />

          <div
            style={{
              position: "absolute",
              width: 470,
              height: 470,
              borderRadius: "50%",
              border:
                "1px solid rgba(255,255,255,0.07)",
              left: -280,
              bottom: -280,
            }}
          />

          <div
            style={{
              position: "absolute",
              width: 180,
              height: 180,
              borderRadius: "50%",
              background:
                "rgba(255,255,255,0.08)",
              filter: "blur(2px)",
              right: -70,
              bottom: 60,
            }}
          />

          {/* Logo */}

          <div style={{ position: "relative", zIndex: 1 }}>
            <div
              style={{
                width: 72,
                height: 72,
                borderRadius: 22,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background:
                  "rgba(255,255,255,0.14)",
                border:
                  "1px solid rgba(255,255,255,0.22)",
                boxShadow:
                  "0 12px 30px rgba(0,0,0,0.16)",
                marginBottom: 28,
                fontSize: 25,
                fontWeight: 900,
                letterSpacing: "-2px",
              }}
            >
              360
            </div>

            <div
              style={{
                fontSize: 38,
                fontWeight: 850,
                letterSpacing: "-1.8px",
                lineHeight: 1.05,
                marginBottom: 16,
              }}
            >
              Narsampet360
            </div>

            <div
              style={{
                width: 55,
                height: 4,
                borderRadius: 10,
                background:
                  "rgba(255,255,255,0.85)",
                marginBottom: 24,
              }}
            />

            <p
              style={{
                margin: 0,
                maxWidth: 390,
                fontSize: 17,
                lineHeight: 1.7,
                color: "rgba(255,255,255,0.82)",
              }}
            >
              A smarter way to connect citizens,
              communities and public services.
            </p>
          </div>

          {/* Bottom */}

          <div
            style={{
              position: "relative",
              zIndex: 1,
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                marginBottom: 12,
              }}
            >
              <div
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: "#7dd3fc",
                  boxShadow:
                    "0 0 14px rgba(125,211,252,0.9)",
                }}
              />

              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color:
                    "rgba(255,255,255,0.75)",
                  letterSpacing: 0.4,
                }}
              >
                SECURE CITIZEN PLATFORM
              </span>
            </div>

            <div
              style={{
                fontSize: 13,
                color:
                  "rgba(255,255,255,0.55)",
              }}
            >
              Narsampet • Telangana
            </div>
          </div>
        </div>

        {/* =================================================
            RIGHT LOGIN PANEL
        ================================================= */}

        <div
          style={{
            padding: "58px 52px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            background: "#ffffff",
          }}
        >
          {/* Heading */}

          <div style={{ marginBottom: 34 }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                padding: "7px 12px",
                borderRadius: 999,
                background: "#eff6ff",
                color: "#2563eb",
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: 0.5,
                marginBottom: 18,
              }}
            >
              {step === 1
                ? "WELCOME BACK"
                : "SECURE VERIFICATION"}
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: 32,
                lineHeight: 1.15,
                fontWeight: 850,
                letterSpacing: "-1.2px",
                color: "#0f172a",
              }}
            >
              {step === 1
                ? "Login to continue"
                : "Verify your mobile"}
            </h1>

            <p
              style={{
                margin:
                  "12px 0 0",
                color: "#64748b",
                fontSize: 15,
                lineHeight: 1.6,
              }}
            >
              {step === 1
                ? "Enter your registered mobile number to access Narsampet360."
                : `We sent a 6-digit OTP to +91 ${mobile}`}
            </p>
          </div>

          {/* =================================================
              MOBILE STEP
          ================================================= */}

          {step === 1 && (
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: 10,
                  color: "#1e293b",
                  fontSize: 13,
                  fontWeight: 750,
                }}
              >
                Mobile Number
              </label>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  height: 58,
                  border:
                    "1.5px solid #dbe3ef",
                  borderRadius: 15,
                  background: "#f8fafc",
                  overflow: "hidden",
                  transition:
                    "all 0.2s ease",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    display: "flex",
                    alignItems: "center",
                    padding: "0 15px",
                    borderRight:
                      "1px solid #e2e8f0",
                    color: "#334155",
                    fontSize: 14,
                    fontWeight: 750,
                    whiteSpace: "nowrap",
                  }}
                >
                  🇮🇳 +91
                </div>

                <input
                  type="tel"
                  inputMode="numeric"
                  autoComplete="tel"
                  placeholder="Enter mobile number"
                  value={mobile}
                  maxLength={10}
                  onChange={(e) =>
                    setMobile(
                      e.target.value.replace(
                        /\D/g,
                        ""
                      )
                    )
                  }
                  onKeyDown={(e) => {
                    if (
                      e.key === "Enter"
                    ) {
                      sendOtp();
                    }
                  }}
                  style={{
                    width: "100%",
                    height: "100%",
                    border: "none",
                    outline: "none",
                    padding:
                      "0 17px",
                    background:
                      "transparent",
                    fontSize: 16,
                    color: "#0f172a",
                    letterSpacing: 0.4,
                  }}
                />
              </div>

              <button
                onClick={sendOtp}
                disabled={loading}
                style={{
                  width: "100%",
                  height: 58,
                  marginTop: 18,
                  border: "none",
                  borderRadius: 15,
                  background: loading
                    ? "#94a3b8"
                    : "linear-gradient(135deg, #2563eb, #1d4ed8)",
                  color: "#fff",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  fontSize: 15,
                  fontWeight: 800,
                  letterSpacing: 0.2,
                  boxShadow: loading
                    ? "none"
                    : "0 12px 24px rgba(37,99,235,0.25)",
                  transition:
                    "all 0.2s ease",
                }}
              >
                {loading ? (
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent:
                        "center",
                      gap: 10,
                    }}
                  >
                    <span
                      style={{
                        width: 17,
                        height: 17,
                        border:
                          "2px solid rgba(255,255,255,0.35)",
                        borderTopColor:
                          "#fff",
                        borderRadius:
                          "50%",
                        animation:
                          "spin 0.8s linear infinite",
                      }}
                    />
                    Sending OTP...
                  </span>
                ) : (
                  "Send OTP  →"
                )}
              </button>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent:
                    "center",
                  gap: 8,
                  marginTop: 24,
                  color: "#94a3b8",
                  fontSize: 12,
                }}
              >
                <span>🔒</span>
                <span>
                  Your login is protected with
                  secure OTP verification
                </span>
              </div>
            </div>
          )}

          {/* =================================================
              OTP STEP
          ================================================= */}

          {step === 2 && (
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: 10,
                  color: "#1e293b",
                  fontSize: 13,
                  fontWeight: 750,
                }}
              >
                Enter OTP
              </label>

              <input
                type="tel"
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="• • • • • •"
                value={otp}
                maxLength={6}
                autoFocus
                onChange={(e) =>
                  setOtp(
                    e.target.value.replace(
                      /\D/g,
                      ""
                    )
                  )
                }
                onKeyDown={(e) => {
                  if (
                    e.key === "Enter"
                  ) {
                    verifyOtp();
                  }
                }}
                style={{
                  width: "100%",
                  height: 64,
                  boxSizing: "border-box",
                  border:
                    "1.5px solid #dbe3ef",
                  borderRadius: 15,
                  outline: "none",
                  background: "#f8fafc",
                  padding: "0 18px",
                  fontSize: 24,
                  fontWeight: 750,
                  letterSpacing: 12,
                  textAlign: "center",
                  color: "#0f172a",
                }}
              />

              <button
                onClick={verifyOtp}
                disabled={loading}
                style={{
                  width: "100%",
                  height: 58,
                  marginTop: 18,
                  border: "none",
                  borderRadius: 15,
                  background: loading
                    ? "#94a3b8"
                    : "linear-gradient(135deg, #16a34a, #15803d)",
                  color: "#fff",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  fontSize: 15,
                  fontWeight: 800,
                  boxShadow: loading
                    ? "none"
                    : "0 12px 24px rgba(22,163,74,0.22)",
                }}
              >
                {loading ? (
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent:
                        "center",
                      gap: 10,
                    }}
                  >
                    <span
                      style={{
                        width: 17,
                        height: 17,
                        border:
                          "2px solid rgba(255,255,255,0.35)",
                        borderTopColor:
                          "#fff",
                        borderRadius:
                          "50%",
                        animation:
                          "spin 0.8s linear infinite",
                      }}
                    />
                    Verifying...
                  </span>
                ) : (
                  "Verify & Continue  →"
                )}
              </button>

              <button
                onClick={() => {
                  setStep(1);
                  setOtp("");
                  setMessage("");
                }}
                disabled={loading}
                style={{
                  width: "100%",
                  height: 48,
                  marginTop: 10,
                  border:
                    "1px solid #e2e8f0",
                  borderRadius: 14,
                  background: "#fff",
                  color: "#475569",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  fontSize: 13,
                  fontWeight: 700,
                }}
              >
                ← Change Mobile Number
              </button>

              <div
                style={{
                  textAlign: "center",
                  marginTop: 22,
                  color: "#94a3b8",
                  fontSize: 12,
                }}
              >
                Didn't receive the OTP?
                <div
                  style={{
                    marginTop: 5,
                    color: "#2563eb",
                    fontWeight: 700,
                  }}
                >
                  Check your backend terminal
                </div>
              </div>
            </div>
          )}

          {/* =================================================
              MESSAGE
          ================================================= */}

          {message && (
            <div
              style={{
                marginTop: 22,
                padding: "13px 15px",
                borderRadius: 13,
                background:
                  message.toLowerCase().includes(
                    "sent"
                  )
                    ? "#f0fdf4"
                    : "#fff7ed",
                border:
                  message.toLowerCase().includes(
                    "sent"
                  )
                    ? "1px solid #bbf7d0"
                    : "1px solid #fed7aa",
                color:
                  message.toLowerCase().includes(
                    "sent"
                  )
                    ? "#166534"
                    : "#9a3412",
                fontSize: 13,
                fontWeight: 600,
                lineHeight: 1.5,
              }}
            >
              {message}
            </div>
          )}

          {/* Footer */}

          <div
            style={{
              marginTop: 38,
              paddingTop: 20,
              borderTop:
                "1px solid #f1f5f9",
              textAlign: "center",
              color: "#cbd5e1",
              fontSize: 11,
            }}
          >
            © {new Date().getFullYear()} Narsampet360
          </div>
        </div>
      </div>

      {/* =================================================
          ANIMATION
      ================================================= */}

      <style>
        {`
          @keyframes spin {
            from {
              transform: rotate(0deg);
            }
            to {
              transform: rotate(360deg);
            }
          }

          @media (max-width: 820px) {
            .login-card {
              grid-template-columns: 1fr !important;
            }
          }

          @media (max-width: 820px) {
            body {
              overflow-x: hidden;
            }
          }

          @media (max-width: 600px) {
            div {
              box-sizing: border-box;
            }
          }
        `}
      </style>
    </div>
  );
}
