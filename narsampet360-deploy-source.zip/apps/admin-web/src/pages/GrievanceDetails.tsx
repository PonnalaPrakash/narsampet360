import {
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  useNavigate,
  useParams,
} from "react-router-dom";

import {
  assignGrievance,
  getGrievanceById,
  getGrievanceHistory,
  getOfficers,
  undoGrievance,
  updateGrievanceStatus,
  getGrievanceAttachments,
  uploadGrievanceAttachment,
  deleteGrievanceAttachment,
} from "../api/grievanceApi";

import Sidebar from "../components/Sidebar";
import { downloadAuthenticatedFile } from "../api/client";

type Role =
  | "ADMIN"
  | "MLA"
  | "PA"
  | "MANDAL_INCHARGE"
  | "OFFICER"
  | "VILLAGE_COORDINATOR"
  | "";

type Officer = {
  id: string;
  name: string;
  mobile?: string;
};

type HistoryItem = {
  id: string;
  oldStatus?: string;
  newStatus?: string;
  remarks?: string;
  changedField?: string;
  createdAt?: string;
  user?: {
    id?: string;
    name?: string;
    mobile?: string;
    role?: string;
  };
};

type UserRef = {
  id?: string;
  name?: string;
  mobile?: string;
  role?: string;
};

type Attachment = {
  id: string;
  fileName: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: number;
  createdAt?: string;
  user?: {
    id?: string;
    name?: string;
    role?: string;
  };
};

type Grievance = {
  id: string;
  title?: string;
  description?: string;
  status?: string;
  priority?: string;

  citizenName?: string;
  citizenMobile?: string;

  createdAt?: string;

  createdBy?: UserRef;

  constituency?: {
    id?: string;
    name?: string;
  };

  mandal?: {
    id?: string;
    name?: string;
  };

  village?: {
    id?: string;
    name?: string;
  };

  department?: {
    id?: string;
    name?: string;
  };

  assignedToId?: string | UserRef;
  assignedTo?: UserRef;
  assignedOfficer?: UserRef;
};

function normalizeId(value: any): string {
  if (!value) return "";

  if (
    typeof value === "string" ||
    typeof value === "number"
  ) {
    return String(value).trim();
  }

  if (typeof value === "object") {
    return String(
      value?.id ??
        value?._id ??
        value?.userId ??
        value?.user?.id ??
        value?.user?._id ??
        ""
    ).trim();
  }

  return "";
}

function normalizeStatus(value: any): string {
  return String(value ?? "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");
}

function normalizeRole(value: any): Role {
  const role = String(value ?? "")
    .trim()
    .toUpperCase();

  if (
    role === "ADMIN" ||
    role === "MLA" ||
    role === "PA" ||
    role === "MANDAL_INCHARGE" ||
    role === "OFFICER" ||
    role === "VILLAGE_COORDINATOR"
  ) {
    return role;
  }

  return "";
}

function extractGrievance(
  response: any
): Grievance | null {
  if (!response) return null;

  if (response?.data?.grievance) {
    return response.data.grievance;
  }

  if (response?.grievance) {
    return response.grievance;
  }

  if (response?.data?.data?.id) {
    return response.data.data;
  }

  if (response?.data?.id) {
    return response.data;
  }

  if (response?.id) {
    return response;
  }

  return null;
}

function extractArray(
  response: any,
  keys: string[] = []
): any[] {
  if (Array.isArray(response)) {
    return response;
  }

  if (Array.isArray(response?.data)) {
    return response.data;
  }

  if (Array.isArray(response?.data?.data)) {
    return response.data.data;
  }

  for (const key of keys) {
    if (Array.isArray(response?.[key])) {
      return response[key];
    }

    if (Array.isArray(response?.data?.[key])) {
      return response.data[key];
    }

    if (
      Array.isArray(
        response?.data?.data?.[key]
      )
    ) {
      return response.data.data[key];
    }
  }

  return [];
}

function formatDate(value?: string) {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function formatDateTime(value?: string) {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function getCaseAge(value?: string) {
  if (!value) return 0;

  const created = new Date(value).getTime();

  if (Number.isNaN(created)) {
    return 0;
  }

  const now = Date.now();

  return Math.max(
    0,
    Math.floor(
      (now - created) /
        (1000 * 60 * 60 * 24)
    )
  );
}

const statusConfig: Record<
  string,
  {
    label: string;
    icon: string;
    className: string;
  }
> = {
  PENDING: {
    label: "Pending",
    icon: "⏳",
    className: "status-pending",
  },

  ASSIGNED: {
    label: "Assigned",
    icon: "👤",
    className: "status-assigned",
  },

  IN_PROGRESS: {
    label: "In Progress",
    icon: "⚙",
    className: "status-progress",
  },

  RESOLVED: {
    label: "Resolved",
    icon: "✓",
    className: "status-resolved",
  },

  REJECTED: {
    label: "Rejected",
    icon: "✕",
    className: "status-rejected",
  },

  CLOSED: {
    label: "Closed",
    icon: "✓",
    className: "status-closed",
  },
};

const priorityConfig: Record<
  string,
  {
    label: string;
    className: string;
    icon: string;
  }
> = {
  HIGH: {
    label: "High Priority",
    className: "priority-high",
    icon: "!",
  },

  MEDIUM: {
    label: "Medium Priority",
    className: "priority-medium",
    icon: "•",
  },

  LOW: {
    label: "Low Priority",
    className: "priority-low",
    icon: "↓",
  },
};

export default function GrievanceDetails() {
  const { id } =
    useParams<{ id: string }>();

  const navigate = useNavigate();

  const [grievance, setGrievance] =
    useState<Grievance | null>(null);

  const [history, setHistory] =
    useState<HistoryItem[]>([]);

  const [attachments, setAttachments] =
    useState<Attachment[]>([]);

  const [attachmentLoading, setAttachmentLoading] =
    useState(false);

  const [uploadingAttachment, setUploadingAttachment] =
    useState(false);

  const [officers, setOfficers] =
    useState<Officer[]>([]);

  const [assignedTo, setAssignedTo] =
    useState("");

  const [role, setRole] =
    useState<Role>("");

  const [loading, setLoading] =
    useState(true);

  const [processing, setProcessing] =
    useState(false);

  const [refreshing, setRefreshing] =
    useState(false);

  const loggedInUser = useMemo(() => {
    try {
      const rawUser =
        localStorage.getItem("user");

      const rawUserId =
        localStorage.getItem("userId");

      const rawRole =
        localStorage.getItem("role");

      if (!rawUser) {
        return {
          id: normalizeId(rawUserId),
          name: "",
          role: normalizeRole(rawRole),
        };
      }

      const parsedUser =
        JSON.parse(rawUser);

      const userId = normalizeId(
        parsedUser?.id ??
          parsedUser?._id ??
          parsedUser?.userId ??
          parsedUser?.user?.id ??
          parsedUser?.user?._id ??
          rawUserId
      );

      const userName = String(
        parsedUser?.name ??
          parsedUser?.fullName ??
          parsedUser?.username ??
          parsedUser?.user?.name ??
          ""
      );

      const userRole = normalizeRole(
        parsedUser?.role ??
          parsedUser?.user?.role ??
          rawRole
      );

      return {
        id: userId,
        name: userName,
        role: userRole,
      };
    } catch {
      return {
        id: "",
        name: "",
        role: "",
      };
    }
  }, []);

  const loggedInUserId =
    normalizeId(loggedInUser.id);

  async function loadGrievance() {
    if (!id) return;

    try {
      const response =
        await getGrievanceById(id);

      const data =
        extractGrievance(response);

      setGrievance(data);
    } catch (error: any) {
      console.error(
        "GRIEVANCE ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Failed to load grievance"
      );
    }
  }

  async function loadHistory() {
    if (!id) return;

    try {
      const response =
        await getGrievanceHistory(id);

      const data = extractArray(
        response,
        ["history"]
      );

      const sortedHistory =
        [...data].sort(
          (
            a: HistoryItem,
            b: HistoryItem
          ) =>
            new Date(
              b.createdAt || 0
            ).getTime() -
            new Date(
              a.createdAt || 0
            ).getTime()
        );

      setHistory(sortedHistory);
    } catch (error: any) {
      console.error(
        "HISTORY ERROR:",
        error?.response?.data ||
          error?.message
      );

      setHistory([]);
    }
  }

  async function loadAttachments() {
    if (!id) return;

    try {
      setAttachmentLoading(true);

      const response =
        await getGrievanceAttachments(id);

      const data =
        extractArray(response);

      setAttachments(
        data as Attachment[]
      );
    } catch (error: any) {
      console.error(
        "ATTACHMENTS ERROR:",
        error?.response?.data ||
          error?.message
      );

      setAttachments([]);
    } finally {
      setAttachmentLoading(false);
    }
  }

  async function handleAttachmentUpload(
    event: React.ChangeEvent<HTMLInputElement>,
  ) {
    const file =
      event.target.files?.[0];

    event.target.value = "";

    if (
      !id ||
      !file ||
      uploadingAttachment
    ) {
      return;
    }

    /*
      Attachment permissions.

      Backend is the real security layer.
      These checks only control the UI.

      Upload:
      Users with a valid grievance-access role
      can attempt upload. Backend checks the
      actual grievance scope.

      Delete:
      ADMIN only.
    */
    if (!canUploadAttachments) {
      alert(
        "You are not authorized to upload attachments."
      );
      return;
    }

    if (
      status === "RESOLVED" ||
      status === "CLOSED" ||
      status === "REJECTED"
    ) {
      alert(
        "Attachments are locked after the grievance is resolved."
      );
      return;
    }

    if (
      file.size >
      5 * 1024 * 1024
    ) {
      alert(
        "File size must be 5 MB or less."
      );
      return;
    }

    try {
      setUploadingAttachment(true);

      await uploadGrievanceAttachment(
        id,
        file
      );

      alert(
        "Attachment uploaded successfully."
      );

      await loadAttachments();
    } catch (error: any) {
      console.error(
        "ATTACHMENT UPLOAD ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Attachment upload failed"
      );
    } finally {
      setUploadingAttachment(false);
    }
  }

  async function handleAttachmentDelete(
    attachment: Attachment
  ) {
    if (!attachment?.id) return;

    /*
      Only ADMIN can delete attachments.
      Backend also enforces this permission.
    */
    if (!canDeleteAttachments) {
      alert(
        "Only ADMIN can delete attachments."
      );
      return;
    }

    if (
      status === "RESOLVED" ||
      status === "CLOSED" ||
      status === "REJECTED"
    ) {
      alert(
        "Attachments are locked after the grievance is resolved."
      );
      return;
    }

    const confirmed =
      window.confirm(
        `Delete ${attachment.fileName}?`
      );

    if (!confirmed) return;

    try {
      await deleteGrievanceAttachment(
        attachment.id
      );

      await loadAttachments();
    } catch (error: any) {
      console.error(
        "ATTACHMENT DELETE ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Attachment delete failed"
      );
    }
  }

  async function loadOfficers() {
    try {
      const response =
        await getOfficers();

      const data = extractArray(
        response,
        ["users", "officers"]
      );

      const normalized: Officer[] =
        data
          .map((item: any) => ({
            id: normalizeId(
              item?.id ??
                item?._id ??
                item?.userId ??
                item?.user
            ),

            name:
              item?.name ??
              item?.fullName ??
              item?.username ??
              item?.user?.name ??
              "Unknown Officer",

            mobile:
              item?.mobile ??
              item?.phone ??
              item?.phoneNumber ??
              item?.user?.mobile ??
              "",
          }))
          .filter(
            (item: Officer) =>
              Boolean(item.id)
          );

      setOfficers(normalized);
    } catch (error: any) {
      console.error(
        "OFFICERS ERROR:",
        error?.response?.data ||
          error?.message
      );

      setOfficers([]);
    }
  }

  async function loadData(
    isRefresh = false
  ) {
    if (!id) return;

    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      await Promise.all([
        loadGrievance(),
        loadHistory(),

        /*
          Officers are only required when the
          logged-in role can assign grievances.
        */
        canAssign
          ? loadOfficers()
          : Promise.resolve(),

        loadAttachments(),
      ]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    const localStorageRole =
      normalizeRole(
        localStorage.getItem("role")
      );

    const finalRole: Role =
      normalizeRole(
        loggedInUser.role ||
          localStorageRole
      );

    setRole(finalRole);

    loadData();
  }, [
    id,
    loggedInUserId,
    loggedInUser.role,
  ]);

  const status = normalizeStatus(
    grievance?.status
  );

  const assignedOfficerId =
    normalizeId(
      grievance?.assignedToId ??
        grievance?.assignedTo ??
        grievance?.assignedOfficer
    );

  const assignedOfficerName =
    grievance?.assignedTo?.name ||
    grievance?.assignedOfficer?.name ||
    "";

  const assignedOfficerMobile =
    grievance?.assignedTo?.mobile ||
    grievance?.assignedOfficer?.mobile ||
    "";

  const isAssignedToCurrentOfficer =
    role === "OFFICER" &&
    Boolean(loggedInUserId) &&
    Boolean(assignedOfficerId) &&
    loggedInUserId ===
      assignedOfficerId;

  const priority =
    String(
      grievance?.priority || ""
    )
      .trim()
      .toUpperCase();

  const priorityInfo =
    priorityConfig[priority] || {
      label:
        grievance?.priority ||
        "Not Specified",
      className:
        "priority-default",
      icon: "•",
    };

  const caseAge = getCaseAge(
    grievance?.createdAt
  );

  const canAssign =
    role === "ADMIN" ||
    role === "MLA" ||
    role === "PA";

  /*
    Attachment permissions.

    Backend is the real security layer.
    These checks only control the UI.

    Upload:
    Users with a valid grievance-access role
    can attempt upload. Backend checks the
    actual grievance scope.

    Delete:
    ADMIN only.
  */
  const canUploadAttachments =
    role === "ADMIN" ||
    role === "MLA" ||
    role === "PA" ||
    role === "MANDAL_INCHARGE" ||
    role === "VILLAGE_COORDINATOR" ||
    role === "OFFICER";

  const canDeleteAttachments =
    role === "ADMIN";

  const isFinalStatus =
    status === "RESOLVED" ||
    status === "CLOSED" ||
    status === "REJECTED";

  const backPath =
    role === "OFFICER"
      ? "/my-grievances"
      : "/grievances";

  /*
    Assignment Undo:
    Only ADMIN / MLA / PA can undo an officer assignment.
    It is available only while the grievance is ASSIGNED.
  */
  const lastHistoryAction =
    history.length > 0
      ? history[0]
      : null;

  const canUndoAssignment =
    (role === "ADMIN" ||
      role === "MLA" ||
      role === "PA") &&
    status === "ASSIGNED" &&
    Boolean(assignedOfficerId) &&
    lastHistoryAction?.changedField !==
      "UNDO";

  async function updateStatus(
    newStatus: string
  ) {
    if (
      !id ||
      !grievance ||
      processing
    ) {
      return;
    }

    const currentStatus =
      normalizeStatus(
        grievance.status
      );

    const nextStatus =
      normalizeStatus(newStatus);

    if (
      currentStatus === "CLOSED" ||
      currentStatus === "REJECTED"
    ) {
      alert(
        `This grievance is already ${currentStatus}.`
      );
      return;
    }

    /*
      OFFICER:
      Only the assigned officer can move:
      ASSIGNED -> IN_PROGRESS
      IN_PROGRESS -> RESOLVED
    */
    if (role === "OFFICER") {
      if (!loggedInUserId) {
        alert(
          "Logged-in officer ID not found. Please login again."
        );
        return;
      }

      if (!assignedOfficerId) {
        alert(
          "This grievance does not have a valid assigned officer."
        );
        return;
      }

      if (
        !isAssignedToCurrentOfficer
      ) {
        alert(
          "This grievance is assigned to another officer."
        );
        return;
      }

      if (
        nextStatus !==
          "IN_PROGRESS" &&
        nextStatus !== "RESOLVED"
      ) {
        alert(
          "Officer can only start work or mark the grievance as resolved."
        );
        return;
      }
    }

    /*
      ADMIN:
      Admin cannot Start Work or Mark Resolved.
      Admin can only:
      - Reject an IN_PROGRESS grievance
      - Close a RESOLVED grievance
    */
    if (role === "ADMIN") {
      if (
        nextStatus !== "CLOSED" &&
        nextStatus !== "REJECTED"
      ) {
        alert(
          "Admin cannot start work or resolve a grievance. Only the assigned officer can do that."
        );
        return;
      }
    }

    /*
      PA:
      PA can only close or reject.
    */
    if (role === "PA") {
      if (
        nextStatus !== "CLOSED" &&
        nextStatus !== "REJECTED"
      ) {
        alert(
          "PA can only close or reject a grievance."
        );
        return;
      }
    }

    /*
      MLA:
      MLA can assign officers but cannot update status.
    */
    if (role === "MLA") {
      alert(
        "MLA can assign officers but cannot update status."
      );
      return;
    }

    /*
      IN_PROGRESS can only be reached from ASSIGNED
      by the assigned OFFICER.
    */
    if (
      nextStatus === "IN_PROGRESS"
    ) {
      if (
        role !== "OFFICER"
      ) {
        alert(
          "Only the assigned officer can start work."
        );
        return;
      }

      if (
        currentStatus !== "ASSIGNED"
      ) {
        alert(
          "Grievance must be ASSIGNED before starting work."
        );
        return;
      }

      if (
        !isAssignedToCurrentOfficer
      ) {
        alert(
          "This grievance is assigned to another officer."
        );
        return;
      }
    }

    /*
      RESOLVED can only be reached from IN_PROGRESS
      by the assigned OFFICER.
    */
    if (
      nextStatus === "RESOLVED"
    ) {
      if (
        role !== "OFFICER"
      ) {
        alert(
          "Only the assigned officer can mark a grievance as resolved."
        );
        return;
      }

      if (
        currentStatus !==
        "IN_PROGRESS"
      ) {
        alert(
          "Grievance must be IN_PROGRESS before resolving."
        );
        return;
      }

      if (
        !isAssignedToCurrentOfficer
      ) {
        alert(
          "This grievance is assigned to another officer."
        );
        return;
      }
    }

    /*
      REJECTED:
      Only ADMIN / PA can reject,
      and only while IN_PROGRESS.
    */
    if (
      nextStatus === "REJECTED"
    ) {
      if (
        role !== "ADMIN" &&
        role !== "PA"
      ) {
        alert(
          "Only ADMIN or PA can reject a grievance."
        );
        return;
      }

      if (
        currentStatus !==
        "IN_PROGRESS"
      ) {
        alert(
          "Only an IN_PROGRESS grievance can be rejected."
        );
        return;
      }
    }

    /*
      CLOSED:
      Only ADMIN / PA can close,
      and only after officer has resolved it.
    */
    if (
      nextStatus === "CLOSED"
    ) {
      if (
        role !== "ADMIN" &&
        role !== "PA"
      ) {
        alert(
          "Only ADMIN or PA can close a grievance."
        );
        return;
      }

      if (
        currentStatus !== "RESOLVED"
      ) {
        alert(
          "Only a RESOLVED grievance can be closed."
        );
        return;
      }
    }

    try {
      setProcessing(true);

      await updateGrievanceStatus(
        id,
        {
          status: nextStatus,
          remarks:
            `Status changed from ${currentStatus} to ${nextStatus}`,
        }
      );

      alert(
        `Grievance status changed to ${nextStatus}`
      );

      await loadData();
    } catch (error: any) {
      console.error(
        "STATUS UPDATE ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Status update failed"
      );
    } finally {
      setProcessing(false);
    }
  }

  async function assignOfficer() {
    if (
      !id ||
      !assignedTo ||
      !grievance ||
      processing
    ) {
      return;
    }

    if (!canAssign) {
      alert(
        "Only ADMIN, MLA or PA can assign an officer."
      );
      return;
    }

    if (status !== "PENDING") {
      alert(
        "Officer can be assigned only when grievance is PENDING."
      );
      return;
    }

    const selectedOfficer =
      officers.find(
        (officer) =>
          normalizeId(officer.id) ===
          normalizeId(assignedTo)
      );

    if (!selectedOfficer) {
      alert(
        "Selected officer was not found."
      );
      return;
    }

    try {
      setProcessing(true);

      await assignGrievance(id, {
        assignedToId:
          selectedOfficer.id,
      });

      alert(
        `Grievance assigned to ${selectedOfficer.name}`
      );

      setAssignedTo("");

      await loadData();
    } catch (error: any) {
      console.error(
        "ASSIGN ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Assignment failed"
      );
    } finally {
      setProcessing(false);
    }
  }

  async function undoStatus() {
    if (!id || processing) return;

    if (
      role !== "ADMIN" &&
      role !== "MLA" &&
      role !== "PA"
    ) {
      alert(
        "Only ADMIN, MLA or PA can undo an officer assignment."
      );
      return;
    }

    if (status !== "ASSIGNED") {
      alert(
        "Only an assigned grievance can have its assignment undone."
      );
      return;
    }

    if (!assignedOfficerId) {
      alert(
        "No assigned officer was found for this grievance."
      );
      return;
    }

    const confirmed =
      window.confirm(
        `Are you sure you want to undo the assignment of ${
          assignedOfficerName || "this officer"
        }?`
      );

    if (!confirmed) return;

    try {
      setProcessing(true);

      const response =
        await undoGrievance(id);

      alert(
        response?.message ||
          "Officer assignment undone successfully"
      );

      setAssignedTo("");

      await loadData();
    } catch (error: any) {
      console.error(
        "UNDO ASSIGNMENT ERROR:",
        error?.response?.data ||
          error?.message
      );

      alert(
        error?.response?.data?.message ||
          "Failed to undo officer assignment"
      );
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <div className="details-layout">
        <Sidebar />

        <main className="details-main">
          <div className="loading-card">
            <div className="loading-spinner" />

            <h2>
              Loading grievance...
            </h2>

            <p>
              Please wait while we fetch
              the case details.
            </p>
          </div>
        </main>

        <DetailsStyles />
      </div>
    );
  }

  if (!grievance) {
    return (
      <div className="details-layout">
        <Sidebar />

        <main className="details-main">
          <div className="empty-card">
            <div className="empty-icon">
              📄
            </div>

            <h2>
              Grievance Not Found
            </h2>

            <p>
              The requested grievance
              could not be found.
            </p>

            <button
              className="btn btn-primary"
              onClick={() =>
                navigate(backPath)
              }
            >
              ← Back to Grievances
            </button>
          </div>
        </main>

        <DetailsStyles />
      </div>
    );
  }

  const statusInfo =
    statusConfig[status] || {
      label: status || "Unknown",
      icon: "•",
      className: "status-pending",
    };

  return (
    <div className="details-layout">
      <Sidebar />

      <main className="details-main">
        <div className="details-topbar">
          <button
            className="back-button"
            onClick={() =>
              navigate(backPath)
            }
          >
            <span className="back-arrow">
              ←
            </span>

            {role === "OFFICER"
              ? "Back to My Grievances"
              : "Back to Grievances"}
          </button>

          <div className="topbar-actions">
            <button
              className="refresh-detail-button"
              onClick={() =>
                loadData(true)
              }
              disabled={refreshing}
            >
              <span
                className={
                  refreshing
                    ? "refresh-spin"
                    : ""
                }
              >
                ↻
              </span>

              {refreshing
                ? "Refreshing..."
                : "Refresh"}
            </button>

            <span className="role-pill">
              {role || "USER"}
            </span>
          </div>
        </div>

        <section className="hero-section">
          <div className="hero-left">
            <div className="hero-icon">
              📋
            </div>

            <div className="hero-copy">
              <div className="eyebrow">
                GRIEVANCE DETAILS
              </div>

              <h1>
                {grievance.title ||
                  "Untitled Grievance"}
              </h1>

              <div className="hero-meta">
                <span>
                  Case ID
                  <strong>
                    #{grievance.id}
                  </strong>
                </span>

                <span className="meta-dot">
                  •
                </span>

                <span>
                  Created
                  <strong>
                    {formatDate(
                      grievance.createdAt
                    )}
                  </strong>
                </span>

                <span className="meta-dot">
                  •
                </span>

                <span>
                  Age
                  <strong>
                    {caseAge} day
                    {caseAge !== 1
                      ? "s"
                      : ""}
                  </strong>
                </span>
              </div>
            </div>
          </div>

          <div className="hero-status-area">
            <span
              className={`large-status ${statusInfo.className}`}
            >
              <span>
                {statusInfo.icon}
              </span>

              {statusInfo.label}
            </span>

            <span
              className={`hero-priority ${priorityInfo.className}`}
            >
              {priorityInfo.icon}{" "}
              {priorityInfo.label}
            </span>
          </div>
        </section>

        <section className="quick-summary">
          <SummaryItem
            icon="●"
            label="Current Status"
            value={
              statusInfo.label
            }
          />

          <SummaryItem
            icon="!"
            label="Priority"
            value={
              priorityInfo.label
            }
          />

          <SummaryItem
            icon="👤"
            label="Assigned Officer"
            value={
              assignedOfficerName ||
              "Not Assigned"
            }
          />

          <SummaryItem
            icon="◷"
            label="Case Age"
            value={`${caseAge} day${
              caseAge !== 1
                ? "s"
                : ""
            }`}
          />
        </section>

        <section className="section-card status-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                WORKFLOW
              </div>

              <h2>
                Grievance Status
              </h2>
            </div>

            <span className="progress-text">
              Current:{" "}
              <strong>
                {statusInfo.label}
              </strong>
            </span>
          </div>

          <StatusTracker
            status={status}
          />
        </section>

        <div className="content-grid">
          <section className="section-card">
            <div className="section-heading">
              <div>
                <div className="section-kicker">
                  CASE INFORMATION
                </div>

                <h2>
                  Grievance Information
                </h2>
              </div>

              <div className="section-icon">
                📄
              </div>
            </div>

            <div className="info-list">
              <InfoRow
                label="Title"
                value={
                  grievance.title
                }
              />

              <InfoRow
                label="Description"
                value={
                  grievance.description
                }
                large
              />

              <div className="info-two-col">
                <InfoRow
                  label="Priority"
                  value={
                    priorityInfo.label
                  }
                  badge
                />

                <InfoRow
                  label="Current Status"
                  value={
                    statusInfo.label
                  }
                  status
                />
              </div>
            </div>
          </section>

          <section className="section-card">
            <div className="section-heading">
              <div>
                <div className="section-kicker">
                  CITIZEN
                </div>

                <h2>
                  Citizen Information
                </h2>
              </div>

              <div className="section-icon">
                👤
              </div>
            </div>

            <div className="citizen-profile">
              <div className="avatar">
                {(
                  grievance.citizenName ||
                  "C"
                )
                  .charAt(0)
                  .toUpperCase()}
              </div>

              <div className="citizen-profile-copy">
                <div className="citizen-name">
                  {grievance.citizenName ||
                    "Unknown Citizen"}
                </div>

                <div className="citizen-role">
                  Citizen / Complainant
                </div>
              </div>
            </div>

            <div className="info-list compact">
              <InfoRow
                label="Mobile Number"
                value={
                  grievance.citizenMobile
                }
              />

              <InfoRow
                label="Submitted On"
                value={formatDate(
                  grievance.createdAt
                )}
              />
            </div>
          </section>
        </div>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                JURISDICTION
              </div>

              <h2>
                Location & Department
              </h2>
            </div>

            <div className="section-icon">
              📍
            </div>
          </div>

          <div className="location-grid">
            <LocationItem
              icon="🏛"
              label="Constituency"
              value={
                grievance
                  .constituency?.name
              }
            />

            <LocationItem
              icon="🗺"
              label="Mandal"
              value={
                grievance.mandal?.name
              }
            />

            <LocationItem
              icon="🏘"
              label="Village"
              value={
                grievance.village?.name
              }
            />

            <LocationItem
              icon="🏢"
              label="Department"
              value={
                grievance.department?.name
              }
            />
          </div>
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                ASSIGNMENT
              </div>

              <h2>
                Assigned Officer
              </h2>
            </div>

            <div className="section-icon">
              👨‍💼
            </div>
          </div>

          {assignedOfficerId ? (
            <div className="assigned-officer">
              <div className="officer-avatar">
                {(
                  assignedOfficerName ||
                  "O"
                )
                  .charAt(0)
                  .toUpperCase()}
              </div>

              <div className="officer-details">
                <div className="officer-name">
                  {assignedOfficerName ||
                    "Assigned Officer"}
                </div>

                <div className="officer-mobile">
                  {assignedOfficerMobile ||
                    "Mobile number not available"}
                </div>
              </div>

              {isAssignedToCurrentOfficer && (
                <span className="you-badge">
                  YOU
                </span>
              )}
            </div>
          ) : (
            <div className="not-assigned">
              <div className="not-assigned-icon">
                👤
              </div>

              <div>
                <strong>
                  No officer assigned
                </strong>

                <p>
                  This grievance is
                  waiting for officer
                  assignment.
                </p>
              </div>
            </div>
          )}

          {canAssign &&
            status === "PENDING" && (
              <div className="assignment-box">
                <div className="assignment-header">
                  <div>
                    <div className="assignment-title">
                      Assign an Officer
                    </div>

                    <div className="assignment-subtitle">
                      Select an officer to
                      handle this grievance.
                    </div>
                  </div>

                  <span className="assignment-step">
                    STEP 1
                  </span>
                </div>

                <div className="assignment-row">
                  <select
                    className="officer-select"
                    value={assignedTo}
                    onChange={(event) =>
                      setAssignedTo(
                        event.target.value
                      )
                    }
                    disabled={processing}
                  >
                    <option value="">
                      Select Officer
                    </option>

                    {officers.map(
                      (officer) => (
                        <option
                          key={
                            officer.id
                          }
                          value={
                            officer.id
                          }
                        >
                          {officer.name}
                          {officer.mobile
                            ? ` - ${officer.mobile}`
                            : ""}
                        </option>
                      )
                    )}
                  </select>

                  <button
                    className="btn btn-primary"
                    onClick={
                      assignOfficer
                    }
                    disabled={
                      processing ||
                      !assignedTo
                    }
                  >
                    {processing
                      ? "Assigning..."
                      : "Assign Officer"}
                  </button>
                </div>
              </div>
            )}

          {canUndoAssignment && (
            <div className="undo-area">
              <div className="undo-info">
                <span>↩</span>

                <div>
                  <strong>
                    Need to change the
                    assigned officer?
                  </strong>

                  <p>
                    Undo this assignment
                    to return the
                    grievance to Pending
                    status.
                  </p>
                </div>
              </div>

              <button
                onClick={undoStatus}
                disabled={processing}
                className="btn btn-outline"
              >
                {processing
                  ? "Undoing..."
                  : "↩ Undo Assignment"}
              </button>
            </div>
          )}
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                ACTIONS
              </div>

              <h2>
                Available Actions
              </h2>
            </div>

            <div className="section-icon action-icon">
              ⚡
            </div>
          </div>

          {status === "PENDING" && (
            <div className="state-message warning">
              <div className="state-icon">
                ⏳
              </div>

              <div>
                <strong>
                  Waiting for officer
                  assignment
                </strong>

                <p>
                  An authorized Admin,
                  MLA or PA user needs
                  to assign an officer
                  before work can begin.
                </p>
              </div>
            </div>
          )}

          {status === "ASSIGNED" && (
            <>
              {role === "OFFICER" ? (
                isAssignedToCurrentOfficer ? (
                  <div className="state-message info">
                    <div className="state-icon">
                      ⚙
                    </div>

                    <div>
                      <strong>
                        Ready to start work
                      </strong>

                      <p>
                        This grievance is
                        assigned to you.
                        Start work when you
                        begin handling the
                        case.
                      </p>

                      <button
                        className="btn btn-primary action-button"
                        onClick={() =>
                          updateStatus(
                            "IN_PROGRESS"
                          )
                        }
                        disabled={
                          processing
                        }
                      >
                        {processing
                          ? "Starting..."
                          : "Start Work"}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="state-message warning">
                    <div className="state-icon">
                      👤
                    </div>

                    <div>
                      <strong>
                        Assigned to another
                        officer
                      </strong>

                      <p>
                        You cannot modify
                        this grievance
                        because it is
                        assigned to another
                        officer.
                      </p>
                    </div>
                  </div>
                )
              ) : (
                <div className="state-message info">
                  <div className="state-icon">
                    👤
                  </div>

                  <div>
                    <strong>
                      Officer assigned
                    </strong>

                    <p>
                      The grievance has
                      been assigned to{" "}
                      {assignedOfficerName ||
                        "an officer"}
                      . The assigned
                      officer can now
                      start work.
                    </p>
                  </div>
                </div>
              )}
            </>
          )}

          {status === "IN_PROGRESS" && (
            <>
              {role === "OFFICER" ? (
                isAssignedToCurrentOfficer ? (
                  <div className="state-message info">
                    <div className="state-icon">
                      ⚙
                    </div>

                    <div>
                      <strong>
                        Work is in progress
                      </strong>

                      <p>
                        Complete the required
                        work and mark the
                        grievance as resolved
                        when ready.
                      </p>

                      <button
                        className="btn btn-success action-button"
                        onClick={() =>
                          updateStatus(
                            "RESOLVED"
                          )
                        }
                        disabled={
                          processing
                        }
                      >
                        {processing
                          ? "Resolving..."
                          : "✓ Mark Resolved"}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="state-message warning">
                    <div className="state-icon">
                      👤
                    </div>

                    <div>
                      <strong>
                        Assigned to another
                        officer
                      </strong>

                      <p>
                        You cannot modify
                        this grievance.
                      </p>
                    </div>
                  </div>
                )
              ) : (
                <div className="state-message info">
                  <div className="state-icon">
                    ⚙
                  </div>

                  <div>
                    <strong>
                      Work is in progress
                    </strong>

                    <p>
                      The assigned officer
                      is currently handling
                      this grievance.
                    </p>

                    {(role === "ADMIN" ||
                      role === "PA") && (
                      <button
                        className="btn btn-danger action-button"
                        onClick={() =>
                          updateStatus(
                            "REJECTED"
                          )
                        }
                        disabled={
                          processing
                        }
                      >
                        {processing
                          ? "Processing..."
                          : "✕ Reject Grievance"}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </>
          )}

          {status === "RESOLVED" && (
            <div className="state-message success">
              <div className="state-icon">
                ✓
              </div>

              <div>
                <strong>
                  Grievance resolved
                </strong>

                <p>
                  The assigned officer has
                  completed the grievance.
                  Admin or PA can now close
                  the case.
                </p>

                {lastHistoryAction?.changedField ===
                "UNDO" ? (
                  <div className="warning-box action-button">
                    <span>↩</span>

                    <div>
                      <strong>
                        Assignment history
                        updated
                      </strong>

                      <p>
                        The assignment
                        history contains an
                        undo action.
                      </p>
                    </div>
                  </div>
                ) : (
                  (role === "ADMIN" ||
                    role === "PA") && (
                    <button
                      className="btn btn-dark action-button"
                      onClick={() =>
                        updateStatus(
                          "CLOSED"
                        )
                      }
                      disabled={
                        processing
                      }
                    >
                      {processing
                        ? "Closing..."
                        : "✓ Close Grievance"}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {status === "REJECTED" && (
            <div className="state-message danger">
              <div className="state-icon">
                ✕
              </div>

              <div>
                <strong>
                  Grievance rejected
                </strong>

                <p>
                  This grievance has been
                  rejected and no further
                  action is available.
                </p>
              </div>
            </div>
          )}

          {status === "CLOSED" && (
            <div className="state-message success">
              <div className="state-icon">
                ✓
              </div>

              <div>
                <strong>
                  Case completed
                </strong>

                <p>
                  This grievance has been
                  successfully resolved and
                  closed.
                </p>
              </div>
            </div>
          )}
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                DOCUMENTS
              </div>

              <h2>
                Attachments
              </h2>
            </div>

            <div className="section-icon">
              📎
            </div>
          </div>

          <div className="attachment-toolbar">
            <div className="attachment-help">
              {isFinalStatus
                ? "Attachments are locked after the grievance reaches a final status. Existing files remain available for viewing."
                : canUploadAttachments
                ? "Upload supporting documents, images or PDFs. Maximum size: 5 MB. Only ADMIN can delete files."
                : "You can view existing attachments, but you are not authorized to upload or delete files."}
            </div>

            {!isFinalStatus &&
              canUploadAttachments && (
                <label className="btn btn-primary attachment-upload-button">
                  {uploadingAttachment
                    ? "Uploading..."
                    : "📎 Upload File"}

                  <input
                    type="file"
                    hidden
                    onChange={
                      handleAttachmentUpload
                    }
                    disabled={
                      uploadingAttachment
                    }
                    accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                  />
                </label>
              )}
          </div>

          {attachmentLoading ? (
            <div className="attachment-empty">
              Loading attachments...
            </div>
          ) : attachments.length === 0 ? (
            <div className="attachment-empty">
              <div className="attachment-empty-icon">
                📄
              </div>

              <strong>
                No attachments yet
              </strong>

              <p>
                Supporting files uploaded
                for this grievance will
                appear here.
              </p>
            </div>
          ) : (
            <div className="attachment-list">
              {attachments.map(
                (attachment) => (
                  <div
                    className="attachment-item"
                    key={attachment.id}
                  >
                    <div className="attachment-icon">
                      {attachment.fileType?.startsWith(
                        "image/"
                      )
                        ? "🖼️"
                        : "📄"}
                    </div>

                    <div className="attachment-copy">
                      <button
                        type="button"
                        className="attachment-name"
                        onClick={() =>
                          void downloadAuthenticatedFile(
                            attachment.fileUrl,
                            attachment.fileName,
                          )
                        }
                      >
                        {attachment.fileName}
                      </button>

                      <div className="attachment-meta">
                        {attachment.fileType ||
                          "File"}

                        {attachment.fileSize
                          ? ` • ${formatFileSize(
                              attachment.fileSize
                            )}`
                          : ""}

                        {attachment.user?.name
                          ? ` • ${attachment.user.name}`
                          : ""}

                        {attachment.createdAt
                          ? ` • ${formatDateTime(
                              attachment.createdAt
                            )}`
                          : ""}
                      </div>
                    </div>

                    <div className="attachment-actions">
                      <button
                        type="button"
                        className="btn btn-outline attachment-action"
                        onClick={() =>
                          void downloadAuthenticatedFile(
                            attachment.fileUrl,
                            attachment.fileName,
                          )
                        }
                      >
                        Open
                      </button>

                      {!isFinalStatus &&
                        canDeleteAttachments && (
                          <button
                            type="button"
                            className="btn btn-danger attachment-action"
                            onClick={() =>
                              handleAttachmentDelete(
                                attachment
                              )
                            }
                          >
                            Delete
                          </button>
                        )}
                    </div>
                  </div>
                )
              )}
            </div>
          )}
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <div className="section-kicker">
                AUDIT TRAIL
              </div>

              <h2>
                Grievance History
              </h2>
            </div>

            <span className="history-count">
              {history.length}{" "}
              {history.length === 1
                ? "Action"
                : "Actions"}
            </span>
          </div>

          {history.length === 0 ? (
            <div className="no-history">
              <div>🕘</div>

              <strong>
                No history available
              </strong>

              <p>
                Changes to this grievance
                will appear here.
              </p>
            </div>
          ) : (
            <div className="timeline">
              {history.map(
                (
                  item,
                  index
                ) => {
                  const oldStatus =
                    normalizeStatus(
                      item.oldStatus
                    );

                  const newStatus =
                    normalizeStatus(
                      item.newStatus
                    );

                  const isUndo =
                    item.changedField ===
                    "UNDO";

                  return (
                    <div
                      key={
                        item.id ||
                        `${index}-${item.createdAt}`
                      }
                      className={`timeline-item ${
                        isUndo
                          ? "undo-marker"
                          : ""
                      }`}
                    >
                      <div className="timeline-marker">
                        <div className="timeline-dot">
                          {isUndo
                            ? "↩"
                            : index + 1}
                        </div>

                        {index <
                          history.length -
                            1 && (
                          <div className="timeline-line" />
                        )}
                      </div>

                      <div className="timeline-content">
                        <div className="timeline-top">
                          <div className="timeline-status">
                            <StatusMini
                              status={
                                oldStatus
                              }
                              fallback="Previous"
                            />

                            <span className="timeline-arrow">
                              →
                            </span>

                            <StatusMini
                              status={
                                newStatus
                              }
                              fallback="Updated"
                            />
                          </div>

                          <span className="timeline-number">
                            #
                            {history.length -
                              index}
                          </span>
                        </div>

                        {isUndo && (
                          <span className="undo-badge">
                            ASSIGNMENT
                            UNDONE
                          </span>
                        )}

                        {item.remarks && (
                          <div className="timeline-details">
                            <div className="history-detail">
                              <span>
                                Remarks
                              </span>

                              <strong>
                                {
                                  item.remarks
                                }
                              </strong>
                            </div>

                            <div className="history-detail">
                              <span>
                                Changed By
                              </span>

                              <strong>
                                {item.user
                                  ?.name ||
                                  "System"}
                              </strong>
                            </div>

                            <div className="history-detail">
                              <span>
                                Role
                              </span>

                              <strong>
                                {item.user
                                  ?.role ||
                                  "-"}
                              </strong>
                            </div>

                            <div className="history-detail">
                              <span>
                                Time
                              </span>

                              <strong>
                                {formatDateTime(
                                  item.createdAt
                                )}
                              </strong>
                            </div>
                          </div>
                        )}

                        {!item.remarks && (
                          <div className="timeline-details">
                            <div className="history-detail">
                              <span>
                                Changed By
                              </span>

                              <strong>
                                {item.user
                                  ?.name ||
                                  "System"}
                              </strong>
                            </div>

                            <div className="history-detail">
                              <span>
                                Role
                              </span>

                              <strong>
                                {item.user
                                  ?.role ||
                                  "-"}
                              </strong>
                            </div>

                            <div className="history-detail">
                              <span>
                                Time
                              </span>

                              <strong>
                                {formatDateTime(
                                  item.createdAt
                                )}
                              </strong>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          )}
        </section>

        <div className="details-footer">
          <button
            className="back-footer-button"
            onClick={() =>
              navigate(backPath)
            }
          >
            ←{" "}
            {role === "OFFICER"
              ? "Back to My Grievances"
              : "Back to Grievances"}
          </button>

          <div className="footer-case-info">
            <span>
              Case ID
            </span>

            <strong>
              #{grievance.id}
            </strong>
          </div>
        </div>
      </main>

      <DetailsStyles />
    </div>
  );
}

function formatFileSize(bytes: number) {
  if (bytes < 1024)
    return `${bytes} B`;

  if (bytes < 1024 * 1024)
    return `${(
      bytes / 1024
    ).toFixed(1)} KB`;

  return `${(
    bytes /
    (1024 * 1024)
  ).toFixed(1)} MB`;
}

/* =========================================================
   SUMMARY ITEM
   ========================================================= */

function SummaryItem({
  icon,
  label,
  value,
}: {
  icon: string;
  label: string;
  value: string;
}) {
  return (
    <div className="summary-item">
      <div className="summary-icon">
        {icon}
      </div>

      <div className="summary-copy">
        <span>
          {label}
        </span>

        <strong>
          {value}
        </strong>
      </div>
    </div>
  );
}
/* =========================================================
   STATUS TRACKER
   ========================================================= */

function StatusTracker({
  status,
}: {
  status: string;
}) {
  const steps = [
    "PENDING",
    "ASSIGNED",
    "IN_PROGRESS",
    "RESOLVED",
  ];

  const currentIndex =
    steps.indexOf(status);

  return (
    <div className="status-tracker">
      {steps.map(
        (step, index) => {
          const config =
            statusConfig[step];

          const completed =
            currentIndex >= index &&
            currentIndex !== -1;

          const isCurrent =
            step === status;

          return (
            <div
              key={step}
              className="tracker-step"
            >
              <div
                className={`tracker-circle ${
                  completed
                    ? "completed"
                    : ""
                } ${
                  isCurrent
                    ? "current"
                    : ""
                }`}
              >
                {completed
                  ? "✓"
                  : config.icon}
              </div>

              <div
                className={`tracker-label ${
                  isCurrent
                    ? "active"
                    : ""
                }`}
              >
                {config.label}
              </div>

              {index <
                steps.length - 1 && (
                <div
                  className={`tracker-line ${
                    currentIndex >
                    index
                      ? "filled"
                      : ""
                  }`}
                />
              )}
            </div>
          );
        }
      )}

      {(status === "REJECTED" ||
        status === "CLOSED") && (
        <div className="final-status-note">
          <span>
            {status === "CLOSED"
              ? "✓"
              : "✕"}
          </span>

          {status === "CLOSED"
            ? "Case completed"
            : "Case rejected"}
        </div>
      )}
    </div>
  );
}

/* =========================================================
   STATUS MINI
   ========================================================= */

function StatusMini({
  status,
  fallback,
}: {
  status: string;
  fallback: string;
}) {
  if (!status) {
    return (
      <span className="status-mini">
        {fallback}
      </span>
    );
  }

  const config =
    statusConfig[status];

  return (
    <span
      className={`status-mini ${
        config?.className || ""
      }`}
    >
      {config?.icon || "•"}{" "}
      {config?.label || status}
    </span>
  );
}

/* =========================================================
   INFO ROW
   ========================================================= */

function InfoRow({
  label,
  value,
  large = false,
  badge = false,
  status = false,
}: {
  label: string;
  value?: string | null;
  large?: boolean;
  badge?: boolean;
  status?: boolean;
}) {
  return (
    <div
      className={`info-row ${
        large ? "large" : ""
      }`}
    >
      <div className="info-label">
        {label}
      </div>

      {badge ? (
        <span className="priority-badge">
          {value || "-"}
        </span>
      ) : status ? (
        <StatusBadge
          status={value || ""}
        />
      ) : (
        <div className="info-value">
          {value || "-"}
        </div>
      )}
    </div>
  );
}

/* =========================================================
   LOCATION ITEM
   ========================================================= */

function LocationItem({
  icon,
  label,
  value,
}: {
  icon: string;
  label: string;
  value?: string;
}) {
  return (
    <div className="location-item">
      <div className="location-icon">
        {icon}
      </div>

      <div className="location-copy">
        <div className="location-label">
          {label}
        </div>

        <div className="location-value">
          {value ||
            "Not available"}
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   STATUS BADGE
   ========================================================= */

function StatusBadge({
  status,
}: {
  status: string;
}) {
  const normalized =
    normalizeStatus(status);

  const config =
    statusConfig[normalized];

  return (
    <span
      className={`inline-status ${
        config?.className ||
        "status-pending"
      }`}
    >
      <span>
        {config?.icon || "•"}
      </span>

      {config?.label ||
        normalized ||
        "Unknown"}
    </span>
  );
}

/* =========================================================
   STYLES
   ========================================================= */

function DetailsStyles() {
  return (
    <style>{`
      * {
        box-sizing: border-box;
      }

      .details-layout {
  min-height: 100vh;
  width: 100%;
  max-width: 100%;
  overflow-x: hidden;
  display: flex;
  background:
    radial-gradient(
      circle at 0% 0%,
      rgba(13, 110, 253, 0.07),
      transparent 30%
    ),
    radial-gradient(
      circle at 100% 10%,
      rgba(79, 141, 253, 0.045),
      transparent 25%
    ),
    #f5f7fb;
}
 .details-main {
  margin-left: 0;
  width: 100%;
  max-width: none;
  min-width: 0;
  min-height: 100vh;
  overflow-x: hidden;
  padding: 26px 22px 42px;
  color: #182230;
  font-family:
    Inter,
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    sans-serif;
}
      .details-topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        min-width: 0;
        flex-wrap: wrap;
        margin-bottom: 20px;
      }

      .back-button {
        border: none;
        background: transparent;
        color: #526173;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        padding: 6px 0;
        transition: 0.2s ease;
      }

      .back-button:hover {
        color: #0d6efd;
        transform: translateX(-2px);
      }

      .back-arrow {
        font-size: 18px;
        line-height: 1;
      }

      .topbar-actions {
        display: flex;
        align-items: center;
        gap: 9px;
        flex-shrink: 0;
      }

      .refresh-detail-button {
        height: 35px;
        padding: 0 12px;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        border: 1px solid #dce3ec;
        border-radius: 9px;
        background: white;
        color: #536072;
        font-size: 11px;
        font-weight: 800;
        cursor: pointer;
        transition: 0.2s ease;
      }

      .refresh-detail-button:hover:not(:disabled) {
        border-color: #b9cbea;
        color: #0d6efd;
        transform: translateY(-1px);
      }

      .refresh-detail-button:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .refresh-spin {
        display: inline-block;
        animation: refreshRotate 0.8s linear infinite;
      }

      @keyframes refreshRotate {
        to {
          transform: rotate(360deg);
        }
      }

      .role-pill {
        background: #eef4ff;
        color: #2757a8;
        border: 1px solid #d8e5ff;
        border-radius: 999px;
        padding: 7px 13px;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: 0.6px;
      }

      .hero-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 18px;
  width: 100%;
  min-width: 0;
  max-width: none;
  margin-bottom: 17px;
}

      .hero-left {
        display: flex;
        align-items: center;
        gap: 15px;
        min-width: 0;
      }

      .hero-icon {
        width: 57px;
        height: 57px;
        flex-shrink: 0;
        border-radius: 16px;
        display: grid;
        place-items: center;
        font-size: 26px;
        background:
          linear-gradient(
            135deg,
            #0d6efd,
            #4f8dfd
          );
        box-shadow:
          0 11px 27px
          rgba(13, 110, 253, 0.2);
      }

      .hero-copy {
        min-width: 0;
      }

      .eyebrow,
      .section-kicker {
        font-size: 9px;
        font-weight: 900;
        letter-spacing: 1.35px;
        color: #7a8798;
        margin-bottom: 5px;
      }

      .hero-section h1 {
        margin: 0;
        font-size: 27px;
        line-height: 1.2;
        color: #162033;
        word-break: break-word;
      }

      .hero-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        margin-top: 8px;
        color: #7a8798;
        font-size: 11px;
      }

      .hero-meta strong {
        color: #465469;
        margin-left: 3px;
      }

      .meta-dot {
        color: #b5bdc9;
      }

      .hero-status-area {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 7px;
        flex-shrink: 0;
      }

      .large-status,
      .hero-priority {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 900;
        border: 1px solid transparent;
      }

      .large-status {
        padding: 10px 15px;
      }

      .hero-priority {
        padding: 6px 10px;
        font-size: 9px;
      }

      .status-pending {
        background: #fff6df;
        color: #946c00;
        border-color: #f4df9c;
      }

      .status-assigned {
        background: #edf4ff;
        color: #2458a8;
        border-color: #d5e4ff;
      }

      .status-progress {
        background: #eaf9fc;
        color: #08758a;
        border-color: #c9edf3;
      }

      .status-resolved {
        background: #eaf8ef;
        color: #197342;
        border-color: #c9e9d5;
      }

      .status-rejected {
        background: #fff0f1;
        color: #b52a37;
        border-color: #f2cdd1;
      }

      .status-closed {
        background: #eef0f3;
        color: #56606c;
        border-color: #dce0e5;
      }

      .priority-high {
        background: #fff0f1;
        color: #b52a37;
        border-color: #f2cdd1;
      }

      .priority-medium {
        background: #fff7e7;
        color: #9a6700;
        border-color: #f1dfb7;
      }

      .priority-low {
        background: #edf9f1;
        color: #197342;
        border-color: #d1ebda;
      }

      .priority-default {
        background: #f3f5f8;
        color: #697587;
        border-color: #e2e6ec;
      }

      .quick-summary {
        display: grid;
        grid-template-columns:
          repeat(4, minmax(0, 1fr));
        gap: 11px;
        margin-bottom: 18px;
      }

      .summary-item {
        display: flex;
        align-items: center;
        gap: 11px;
        min-width: 0;
        padding: 13px 14px;
        background: rgba(255,255,255,0.9);
        border: 1px solid #e6eaf0;
        border-radius: 13px;
        box-shadow:
          0 5px 18px
          rgba(26,39,61,0.035);
      }

      .summary-icon {
        width: 34px;
        height: 34px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 10px;
        background: #f1f5fb;
        color: #3166b8;
        font-size: 14px;
        font-weight: 900;
      }

      .summary-copy {
        min-width: 0;
      }

      .summary-copy span {
        display: block;
        margin-bottom: 3px;
        color: #8b95a5;
        font-size: 9px;
        text-transform: uppercase;
        letter-spacing: 0.55px;
        font-weight: 900;
      }

      .summary-copy strong {
        display: block;
        color: #334052;
        font-size: 12px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .section-card {
        width: 100%;
        max-width: 100%;
        min-width: 0;
        background: rgba(255,255,255,0.97);
        border: 1px solid #e5e9ef;
        border-radius: 17px;
        padding: 21px;
        margin-bottom: 17px;
        box-shadow:
          0 7px 24px
          rgba(26,39,61,0.045);
      }

      .section-heading {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        margin-bottom: 19px;
      }

      .section-heading h2 {
        margin: 0;
        font-size: 16px;
        color: #1c2737;
      }

      .section-icon {
        width: 37px;
        height: 37px;
        border-radius: 11px;
        display: grid;
        place-items: center;
        background: #f4f7fb;
        border: 1px solid #e8edf4;
        font-size: 17px;
      }

      .action-icon {
        background: #fff8e8;
        border-color: #f3e4bf;
      }

      .status-card {
        overflow: hidden;
      }

      .progress-text {
        color: #8792a3;
        font-size: 11px;
      }

      .progress-text strong {
        color: #334155;
      }

      .status-tracker {
        position: relative;
        display: flex;
        align-items: flex-start;
        width: 100%;
        padding: 10px 8px 2px;
      }

      .tracker-step {
        flex: 1;
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-width: 0;
      }

      .tracker-circle {
        width: 39px;
        height: 39px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: #f1f3f6;
        border: 2px solid #e2e6eb;
        color: #98a2b1;
        font-size: 13px;
        font-weight: 900;
        z-index: 2;
        transition: 0.25s ease;
      }

      .tracker-circle.completed {
        background: #0d6efd;
        border-color: #0d6efd;
        color: white;
        box-shadow:
          0 7px 18px
          rgba(13,110,253,0.2);
      }

      .tracker-circle.current {
        transform: scale(1.08);
        box-shadow:
          0 0 0 5px
          rgba(13,110,253,0.09);
      }

      .tracker-label {
        margin-top: 9px;
        font-size: 10px;
        font-weight: 600;
        color: #929baa;
        text-align: center;
      }

      .tracker-label.active {
        color: #1c2737;
        font-weight: 900;
      }

      .tracker-line {
        position: absolute;
        height: 3px;
        left: 50%;
        right: -50%;
        top: 18px;
        background: #e6e9ee;
        z-index: 1;
      }

      .tracker-line.filled {
        background: #0d6efd;
      }

      .final-status-note {
        position: absolute;
        right: 0;
        top: -5px;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 8px;
        border-radius: 999px;
        background: #f5f7fa;
        color: #7c8797;
        font-size: 9px;
        font-weight: 800;
      }

      .content-grid {
        display: grid;
        min-width: 0;
        max-width: 100%;
        grid-template-columns:
          minmax(0, 1.4fr)
          minmax(0, 0.9fr);
        gap: 17px;
      }

      .info-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
      }

      .info-list.compact {
        margin-top: 19px;
      }

      .info-row {
        padding-bottom: 13px;
        border-bottom: 1px solid #eef1f5;
        min-width: 0;
      }

      .info-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
      }

      .info-label {
        font-size: 9px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        color: #8a95a5;
        margin-bottom: 6px;
      }

      .info-value {
        color: #2a3545;
        font-size: 13px;
        line-height: 1.65;
        overflow-wrap: anywhere;
      }

      .info-row.large .info-value {
        line-height: 1.75;
      }

      .info-two-col {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 22px;
      }

      .inline-status,
      .priority-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        width: fit-content;
        padding: 6px 10px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 900;
      }

      .priority-badge {
        background: #fff6e7;
        color: #9a6700;
        border: 1px solid #f4dfb4;
      }

      .citizen-profile {
        display: flex;
        align-items: center;
        gap: 13px;
        padding: 14px;
        background: #f8fafc;
        border: 1px solid #edf0f4;
        border-radius: 13px;
      }

      .avatar {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        flex-shrink: 0;
        background: #e8f0ff;
        color: #1e5fc1;
        font-weight: 900;
        font-size: 16px;
      }

      .citizen-profile-copy {
        min-width: 0;
      }

      .citizen-name {
        font-size: 13px;
        font-weight: 900;
        color: #253244;
        overflow-wrap: anywhere;
      }

      .citizen-role {
        margin-top: 3px;
        color: #8a95a5;
        font-size: 10px;
      }

      .location-grid {
        display: grid;
        grid-template-columns:
          repeat(4, minmax(0, 1fr));
        gap: 11px;
      }

      .location-item {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
        padding: 14px;
        border: 1px solid #edf0f4;
        border-radius: 13px;
        background: #fafbfd;
      }

      .location-icon {
        width: 36px;
        height: 36px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 10px;
        background: white;
        border: 1px solid #e8ecf1;
        font-size: 16px;
      }

      .location-copy {
        min-width: 0;
      }

      .location-label {
        font-size: 9px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 900;
        color: #8a95a5;
        margin-bottom: 3px;
      }

      .location-value {
        font-size: 12px;
        font-weight: 800;
        color: #354153;
        overflow-wrap: anywhere;
      }

      .assigned-officer {
        display: flex;
        align-items: center;
        gap: 13px;
        padding: 15px;
        border: 1px solid #e5ebf3;
        border-radius: 14px;
        background:
          linear-gradient(
            135deg,
            #f8fbff,
            #f4f8fd
          );
      }

      .officer-avatar {
        width: 46px;
        height: 46px;
        flex-shrink: 0;
        border-radius: 13px;
        display: grid;
        place-items: center;
        background: #e8f0ff;
        color: #1554ae;
        font-size: 18px;
        font-weight: 900;
      }

      .officer-details {
        min-width: 0;
        flex: 1;
      }

      .officer-name {
        font-size: 13px;
        font-weight: 900;
        color: #253244;
        overflow-wrap: anywhere;
      }

      .officer-mobile {
        margin-top: 4px;
        color: #788598;
        font-size: 11px;
      }

      .you-badge {
        background: #e8f8ee;
        color: #197342;
        border: 1px solid #ccead7;
        padding: 5px 9px;
        border-radius: 999px;
        font-size: 9px;
        font-weight: 900;
      }

      .not-assigned {
        display: flex;
        align-items: center;
        gap: 13px;
        padding: 16px;
        background: #fffaf0;
        border: 1px solid #f4e6bd;
        border-radius: 13px;
      }

      .not-assigned-icon {
        width: 43px;
        height: 43px;
        display: grid;
        place-items: center;
        flex-shrink: 0;
        border-radius: 12px;
        background: #fff2cc;
      }

      .not-assigned strong {
        font-size: 12px;
        color: #705500;
      }

      .not-assigned p {
        margin: 4px 0 0;
        font-size: 10px;
        color: #967b2f;
      }

      .assignment-box {
        margin-top: 18px;
        padding-top: 18px;
        border-top: 1px solid #edf0f4;
      }

      .assignment-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 15px;
        margin-bottom: 11px;
      }

      .assignment-title {
        color: #465469;
        font-size: 12px;
        font-weight: 900;
      }

      .assignment-subtitle {
        margin-top: 3px;
        color: #929baa;
        font-size: 10px;
      }

      .assignment-step {
        padding: 5px 8px;
        border-radius: 999px;
        background: #f2f5f9;
        color: #778395;
        font-size: 8px;
        font-weight: 900;
        letter-spacing: 0.5px;
      }

      .assignment-row {
        display: flex;
        gap: 10px;
      }

      .officer-select {
        min-width: 0;
        flex: 1;
        height: 43px;
        padding: 0 12px;
        border: 1px solid #dce2ea;
        border-radius: 10px;
        background: white;
        color: #354153;
        outline: none;
        font-size: 12px;
      }

      .officer-select:focus {
        border-color: #75a8fa;
        box-shadow:
          0 0 0 3px
          rgba(13,110,253,0.08);
      }

      .btn {
        border: none;
        min-height: 42px;
        padding: 0 16px;
        border-radius: 10px;
        font-size: 11px;
        font-weight: 900;
        cursor: pointer;
        transition:
          transform 0.18s ease,
          box-shadow 0.18s ease,
          opacity 0.18s ease;
        white-space: nowrap;
      }

      .btn:hover:not(:disabled) {
        transform: translateY(-1px);
      }

      .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .btn-primary {
        background:
          linear-gradient(
            135deg,
            #0d6efd,
            #347ff1
          );
        color: white;
        box-shadow:
          0 7px 17px
          rgba(13,110,253,0.18);
      }

      .btn-success {
        background:
          linear-gradient(
            135deg,
            #198754,
            #279b68
          );
        color: white;
        box-shadow:
          0 7px 17px
          rgba(25,135,84,0.16);
      }

      .btn-danger {
        background: #dc3545;
        color: white;
      }

      .btn-dark {
        background: #4e5967;
        color: white;
      }

      .btn-outline {
        border: 1px solid #d7dde5;
        background: white;
        color: #536072;
      }

      .action-button {
        margin-top: 13px;
      }

      .state-message {
        display: flex;
        align-items: flex-start;
        gap: 13px;
        padding: 14px;
        border-radius: 13px;
        border: 1px solid transparent;
        margin-bottom: 12px;
      }

      .state-icon {
        width: 34px;
        height: 34px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 900;
      }

      .state-message strong {
        display: block;
        font-size: 12px;
      }

      .state-message p {
        margin: 4px 0 0;
        font-size: 10px;
        line-height: 1.55;
      }

      .state-message.info {
        background: #eff7ff;
        border-color: #d8eaff;
        color: #285985;
      }

      .state-message.info .state-icon {
        background: #dcecff;
        color: #2463a9;
      }

      .state-message.success {
        background: #edf9f1;
        border-color: #d4ecdc;
        color: #246b43;
      }

      .state-message.success .state-icon {
        background: #d8f0df;
        color: #198754;
      }

      .state-message.warning {
        background: #fff9e9;
        border-color: #f2e4bd;
        color: #80671b;
      }

      .state-message.warning .state-icon {
        background: #ffefc6;
        color: #9a770c;
      }

      .state-message.danger {
        background: #fff1f2;
        border-color: #f2d1d4;
        color: #9f3039;
      }

      .state-message.danger .state-icon {
        background: #fbdde0;
        color: #dc3545;
      }

      .warning-box {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 13px;
        border-radius: 10px;
        background: #fff8e6;
        color: #80671b;
        font-size: 11px;
      }

      .warning-box > span {
        font-size: 16px;
      }

      .warning-box strong {
        display: block;
        font-size: 11px;
      }

      .warning-box p {
        margin: 3px 0 0;
        font-size: 10px;
      }

      .undo-area {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        margin-top: 19px;
        padding-top: 17px;
        border-top: 1px dashed #dfe4eb;
      }

      .undo-info {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .undo-info > span {
        width: 31px;
        height: 31px;
        display: grid;
        place-items: center;
        border-radius: 9px;
        background: #fff5d9;
        color: #96720a;
      }

      .undo-info strong {
        display: block;
        color: #536072;
        font-size: 10px;
      }

      .undo-info p {
        margin: 3px 0 0;
        color: #929baa;
        font-size: 9px;
      }

      .history-count {
        padding: 6px 10px;
        border-radius: 999px;
        background: #f3f5f8;
        color: #687487;
        font-size: 10px;
        font-weight: 900;
      }

      .attachment-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 14px;
        border: 1px dashed #cbd5e1;
        border-radius: 14px;
        background: #f8fafc;
        margin-bottom: 16px;
      }

      .attachment-help {
        color: #64748b;
        font-size: 12px;
        line-height: 1.5;
      }

      .attachment-upload-button {
        position: relative;
        overflow: hidden;
        flex-shrink: 0;
      }

      .attachment-list {
        display: grid;
        gap: 10px;
      }

      .attachment-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 13px;
        border: 1px solid #e2e8f0;
        border-radius: 13px;
        background: #fff;
      }
      .attachment-icon {
        width: 40px;
        height: 40px;
        display: grid;
        place-items: center;
        border-radius: 11px;
        background: #f1f5f9;
        flex-shrink: 0;
      }
      .attachment-copy {
        min-width: 0;
        flex: 1;
      }

      .attachment-name {
        display: block;
        color: #0f172a;
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .attachment-name:hover {
        text-decoration: underline;
      }
      .attachment-meta {
        margin-top: 4px;
        color: #64748b;
        font-size: 10px;
        line-height: 1.4;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .attachment-actions {
        display: flex;
        gap: 7px;
        flex-shrink: 0;
      }
      .attachment-action {
        min-height: 34px;
        padding: 0 11px;
        font-size: 11px;
      }
      .attachment-empty {
        padding: 28px 15px;
        text-align: center;
        color: #64748b;
        font-size: 12px;
        border: 1px dashed #dbe3ee;
        border-radius: 13px;
      }
      .attachment-empty-icon {
        font-size: 25px;
        margin-bottom: 7px;
      }
      .attachment-empty strong {
        display: block;
        color: #334155;
        margin-bottom: 3px;
      }
      .attachment-empty p {
        margin: 0;
      }
      .timeline {
        position: relative;
        padding-left: 3px;
      }
      .timeline-item {
        position: relative;
        display: flex;
        gap: 14px;
        padding-bottom: 18px;
      }
      .timeline-item:last-child {
        padding-bottom: 0;
      }
      .timeline-marker {
        position: relative;
        width: 36px;
        flex-shrink: 0;
      }
      .timeline-dot {
        width: 36px;
        height: 36px;
        display: grid;
        place-items: center;
        border-radius: 50%;
        background: #eaf2ff;
        color: #1764c0;
        border: 1px solid #d7e6ff;
        font-size: 12px;
        font-weight: 900;
        z-index: 2;
        position: relative;
      }
      .undo-marker .timeline-dot {
        background: #fff4d7;
        border-color: #f0dda7;
        color: #9b7608;
      }
      .timeline-line {
        position: absolute;
        left: 17px;
        top: 36px;
        bottom: -18px;
        width: 2px;
        background: #e8edf3;
      }
      .timeline-content {
        flex: 1;
        min-width: 0;
        padding: 13px 15px;
        border: 1px solid #e8ecf1;
        border-radius: 13px;
        background: #fafbfd;
      }
      .timeline-top {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        align-items: flex-start;
      }
      .timeline-status {
        display: flex;
        align-items: center;
        gap: 7px;
        flex-wrap: wrap;
      }
      .timeline-arrow {
        color: #a1aab6;
        font-size: 13px;
      }
.status-mini {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 7px;
        border-radius: 999px;
        font-size: 9px;
        font-weight: 900;
      }

      .timeline-number {
        color: #9aa4b1;
        font-size: 9px;
        font-weight: 800;
      }

      .undo-badge {
        display: inline-block;
        margin-top: 7px;
        padding: 4px 8px;
        border-radius: 999px;
        background: #fff3cf;
        color: #876900;
        font-size: 8px;
        font-weight: 900;
        letter-spacing: 0.4px;
      }

      .timeline-details {
        display: grid;
        grid-template-columns:
          1.5fr
          1fr
          0.7fr
          1.3fr;
        gap: 12px;
        margin-top: 13px;
        padding-top: 12px;
        border-top: 1px solid #edf0f4;
      }

      .history-detail {
        min-width: 0;
      }

      .history-detail span {
        display: block;
        margin-bottom: 4px;
        color: #98a2af;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-size: 8px;
        font-weight: 900;
      }

      .history-detail strong {
        display: block;
        color: #4a5668;
        font-size: 10px;
        line-height: 1.5;
        overflow-wrap: anywhere;
      }

      .no-history {
        text-align: center;
        padding: 36px 15px;
        color: #929baa;
      }

      .no-history div {
        font-size: 27px;
        margin-bottom: 8px;
      }

      .no-history strong {
        display: block;
        margin-bottom: 4px;
        color: #697587;
        font-size: 12px;
      }

      .no-history p {
        margin: 0;
        font-size: 10px;
      }

      .details-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        color: #99a2af;
        font-size: 9px;
        padding: 3px 4px 0;
      }

      .back-footer-button {
        border: none;
        background: transparent;
        color: #6b7788;
        font-size: 10px;
        font-weight: 800;
        cursor: pointer;
      }

      .back-footer-button:hover {
        color: #0d6efd;
      }

      .footer-case-info {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .footer-case-info span {
        color: #a2aab6;
      }

      .footer-case-info strong {
        color: #6c7787;
      }

      .loading-card,
      .empty-card {
        min-height: 360px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        text-align: center;
        background: white;
        border: 1px solid #e6eaf0;
        border-radius: 18px;
        box-shadow:
          0 8px 25px
          rgba(26,39,61,0.05);
      }

      .loading-card h2,
      .empty-card h2 {
        margin: 12px 0 5px;
        color: #263244;
        font-size: 18px;
      }

      .loading-card p,
      .empty-card p {
        margin: 0 0 18px;
        color: #8792a3;
        font-size: 11px;
      }

      .loading-spinner {
        width: 38px;
        height: 38px;
        border: 3px solid #e7edf5;
        border-top-color: #0d6efd;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }

      .empty-icon {
        width: 60px;
        height: 60px;
        display: grid;
        place-items: center;
        border-radius: 18px;
        background: #f1f5fa;
        font-size: 27px;
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }

      @media (max-width: 1100px) {
        .details-main {
          padding: 24px;
        }

        .details-topbar {
          align-items: flex-start;
        }

        .hero-section {
          align-items: flex-start;
          flex-direction: column;
        }

        .hero-status-area {
          width: 100%;
          justify-content: space-between;
        }

        .quick-summary {
          grid-template-columns:
            repeat(2, minmax(0, 1fr));
        }

        .content-grid {
          grid-template-columns: 1fr;
        }

        .location-grid {
          grid-template-columns:
            repeat(2, minmax(0, 1fr));
        }

        .timeline-details {
          grid-template-columns:
            repeat(2, minmax(0, 1fr));
        }
      }

      @media (max-width: 768px) {
        .details-main {
          margin-left: 0;
          width: 100%;
          max-width: 100%;
          min-width: 0;
          padding: 16px 13px 30px;
        }

        .details-topbar {
          margin-bottom: 17px;
        }

        .topbar-actions {
          gap: 6px;
        }

        .role-pill {
          display: none;
        }

        .refresh-detail-button {
          padding: 0 9px;
        }

        .hero-section {
          align-items: flex-start;
          flex-direction: column;
          gap: 12px;
        }

        .hero-left {
          width: 100%;
          align-items: flex-start;
        }

        .hero-icon {
          width: 46px;
          height: 46px;
          border-radius: 13px;
          font-size: 21px;
        }

        .hero-section h1 {
          font-size: 21px;
        }

        .hero-status-area {
          width: 100%;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;
        }

        .quick-summary {
          grid-template-columns: 1fr 1fr;
        }

        .summary-item {
          padding: 11px;
        }

        .summary-icon {
          width: 31px;
          height: 31px;
        }

        .section-card {
          padding: 17px;
          border-radius: 15px;
          margin-bottom: 14px;
        }

        .section-heading {
          margin-bottom: 16px;
        }

        .section-heading h2 {
          font-size: 15px;
        }

        .status-tracker {
          overflow-x: auto;
          min-width: 500px;
          padding-bottom: 8px;
        }

        .status-card {
          overflow-x: auto;
        }

        .final-status-note {
          display: none;
        }

        .content-grid {
          display: block;
        }

        .location-grid {
          grid-template-columns: 1fr;
        }

        .info-two-col {
          grid-template-columns: 1fr;
          gap: 14px;
        }

        .attachment-toolbar {
          align-items: stretch;
          flex-direction: column;
        }

        .attachment-upload-button {
          width: 100%;
          justify-content: center;
        }

        .attachment-item {
          align-items: flex-start;
          flex-wrap: wrap;
        }

        .attachment-actions {
          width: 100%;
        }

        .attachment-action {
          flex: 1;
        }

        .assignment-row {
          flex-direction: column;
        }

        .officer-select {
          width: 100%;
          min-height: 43px;
        }

        .assignment-row .btn {
          width: 100%;
        }

        .assignment-header {
          flex-direction: column;
          gap: 8px;
        }

        .timeline-details {
          grid-template-columns: 1fr;
          gap: 10px;
        }
        .timeline-content {
          padding: 12px;
        }
        .undo-area {
          flex-direction: column;
          align-items: flex-start;
        }

        .undo-area .btn {
          width: 100%;
        }

        .details-footer {
          flex-direction: column;
          align-items: flex-start;
        }
      }
      @media (max-width: 480px) {
        .details-main {
          padding-left: 10px;
          padding-right: 10px;
        }
        .hero-meta {
          font-size: 9px;
        }
        .hero-status-area {
          align-items: flex-start;
          flex-direction: column;
        }
        .quick-summary {
          gap: 8px;
        }
        .summary-item {
          padding: 10px;
          gap: 8px;
        }
        .summary-copy strong {
          font-size: 10px;
        }
        .section-card {
          padding: 15px;
        }
        .state-message {
          padding: 12px;
        }
        .state-icon {
          width: 31px;
          height: 31px;
        }
        .timeline-item {
          gap: 9px;
        }
        .timeline-marker {
          width: 31px;
        }
        .timeline-dot {
          width: 31px;
          height: 31px;
          font-size: 11px;
        }
        .timeline-line {
          left: 14px;
          top: 31px;
        }
        .btn {
          white-space: normal;
          min-height: 42px;
        }
      }
    `}</style>
  );
}
