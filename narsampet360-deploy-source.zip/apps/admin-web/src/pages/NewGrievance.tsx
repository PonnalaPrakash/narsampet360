import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createGrievance } from "../api/grievanceApi";
import client from "../api/client";

type Option = {
  id: string;
  name: string;
};

type Village = {
  id: string;
  name: string;
  mandalId?: string;
  mandal?: {
    id: string;
    name: string;
  };
};

export default function NewGrievance() {
  const navigate = useNavigate();

  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [constituencies, setConstituencies] = useState<Option[]>([]);
  const [mandals, setMandals] = useState<Option[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [departments, setDepartments] = useState<Option[]>([]);

  const [loadingConstituencies, setLoadingConstituencies] =
    useState(true);
  const [loadingMandals, setLoadingMandals] =
    useState(true);
  const [loadingVillages, setLoadingVillages] =
    useState(true);
  const [loadingDepartments, setLoadingDepartments] =
    useState(true);

  const [form, setForm] = useState({
    title: "",
    description: "",
    citizenName: "",
    citizenMobile: "",
    priority: "MEDIUM",
    constituencyId: "",
    mandalId: "",
    villageId: "",
    departmentId: "",
  });

  useEffect(() => {
    loadConstituencies();
    loadMandals();
    loadVillages();
    loadDepartments();
  }, []);

  async function loadConstituencies() {
    try {
      setLoadingConstituencies(true);

      const res = await client.get("/constituencies");

      setConstituencies(
        Array.isArray(res.data) ? res.data : [],
      );
    } catch (err: any) {
      console.error(
        "CONSTITUENCIES ERROR:",
        err.response?.data || err.message,
      );

      setConstituencies([]);
    } finally {
      setLoadingConstituencies(false);
    }
  }

  async function loadMandals() {
    try {
      setLoadingMandals(true);

      const res = await client.get("/mandals");

      setMandals(
        Array.isArray(res.data) ? res.data : [],
      );
    } catch (err: any) {
      console.error(
        "MANDALS ERROR:",
        err.response?.data || err.message,
      );

      setMandals([]);
    } finally {
      setLoadingMandals(false);
    }
  }

  async function loadVillages() {
    try {
      setLoadingVillages(true);

      const res = await client.get("/villages");

      setVillages(
        Array.isArray(res.data) ? res.data : [],
      );
    } catch (err: any) {
      console.error(
        "VILLAGES ERROR:",
        err.response?.data || err.message,
      );

      setVillages([]);
    } finally {
      setLoadingVillages(false);
    }
  }

  async function loadDepartments() {
    try {
      setLoadingDepartments(true);

      const res = await client.get("/departments");

      setDepartments(
        Array.isArray(res.data) ? res.data : [],
      );
    } catch (err: any) {
      console.error(
        "DEPARTMENTS ERROR:",
        err.response?.data || err.message,
      );

      setDepartments([]);
    } finally {
      setLoadingDepartments(false);
    }
  }

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  function handleMandalChange(
    e: React.ChangeEvent<HTMLSelectElement>,
  ) {
    const mandalId = e.target.value;

    setForm((prev) => ({
      ...prev,
      mandalId,
      villageId: "",
    }));

    setError("");
  }

  async function handleSubmit(
    e: React.FormEvent,
  ) {
    e.preventDefault();

    setError("");
    setSuccess("");

    if (!form.title.trim()) {
      setError("Title is required");
      return;
    }

    if (!form.description.trim()) {
      setError("Description is required");
      return;
    }

    if (!form.citizenName.trim()) {
      setError("Citizen name is required");
      return;
    }

    if (
      !/^[6-9]\d{9}$/.test(
        form.citizenMobile.trim(),
      )
    ) {
      setError(
        "Enter a valid 10 digit mobile number",
      );
      return;
    }

    // ============================================================
    // MANDAL REQUIRED
    // ============================================================

    if (!form.mandalId) {
      setError("Mandal is required");
      return;
    }

    // ============================================================
    // VILLAGE REQUIRED
    // ============================================================

    if (!form.villageId) {
      setError("Village is required");
      return;
    }

    // ============================================================
    // VERIFY SELECTED VILLAGE BELONGS TO SELECTED MANDAL
    // ============================================================

    const selectedVillage =
      villages.find(
        (v) => v.id === form.villageId,
      );

    if (!selectedVillage) {
      setError(
        "Selected village is invalid",
      );
      return;
    }

    const villageMandalId =
      selectedVillage.mandalId ||
      selectedVillage.mandal?.id;

    if (
      villageMandalId &&
      villageMandalId !== form.mandalId
    ) {
      setError(
        "Selected village does not belong to the selected mandal",
      );
      return;
    }

    try {
      setCreating(true);

      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        citizenName: form.citizenName.trim(),
        citizenMobile:
          form.citizenMobile.trim(),

        priority: form.priority as
          | "LOW"
          | "MEDIUM"
          | "HIGH",

        constituencyId:
          form.constituencyId
            ? String(form.constituencyId)
            : undefined,

        // REQUIRED
        mandalId: String(form.mandalId),

        // REQUIRED
        villageId: String(form.villageId),

        departmentId:
          form.departmentId
            ? String(form.departmentId)
            : undefined,
      };

      await createGrievance(payload);

      setSuccess(
        "Grievance created successfully",
      );

      setTimeout(() => {
        navigate("/grievances");
      }, 1000);
    } catch (err: any) {
      console.error(
        "CREATE GRIEVANCE ERROR:",
        err.response?.data ||
          err.message,
      );

      const message =
        err.response?.data?.message;

      setError(
        Array.isArray(message)
          ? message.join(", ")
          : message ||
              "Failed to create grievance",
      );
    } finally {
      setCreating(false);
    }
  }

  const selectedMandalVillages =
    form.mandalId
      ? villages.filter(
          (v) =>
            v.mandalId ===
              form.mandalId ||
            v.mandal?.id ===
              form.mandalId,
        )
      : [];

  return (
    <div
      style={{
        padding: 30,
        fontFamily: "Arial, sans-serif",
        background: "#f5f6f8",
        minHeight: "100vh",
      }}
    >
      <div
        style={{
          maxWidth: 800,
          margin: "0 auto",
          background: "#fff",
          padding: 30,
          borderRadius: 10,
          boxShadow:
            "0 2px 10px rgba(0,0,0,0.08)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 25,
          }}
        >
          <h1
            style={{
              margin: 0,
              fontSize: 28,
            }}
          >
            New Grievance
          </h1>

          <button
            type="button"
            onClick={() =>
              navigate("/grievances")
            }
            style={{
              padding: "9px 16px",
              cursor: "pointer",
              border: "1px solid #ccc",
              borderRadius: 6,
              background: "#fff",
              fontWeight: 600,
            }}
          >
            ← Back
          </button>
        </div>

        {error && (
          <div
            style={{
              background: "#f8d7da",
              color: "#842029",
              padding: 12,
              borderRadius: 6,
              marginBottom: 20,
            }}
          >
            {error}
          </div>
        )}

        {success && (
          <div
            style={{
              background: "#d1e7dd",
              color: "#0f5132",
              padding: 12,
              borderRadius: 6,
              marginBottom: 20,
            }}
          >
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {/* TITLE */}

          <div
            style={{
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Title *
            </label>

            <input
              type="text"
              name="title"
              value={form.title}
              onChange={handleChange}
              placeholder="Enter grievance title"
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                boxSizing:
                  "border-box",
              }}
            />
          </div>

          {/* DESCRIPTION */}

          <div
            style={{
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Description *
            </label>

            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={5}
              placeholder="Enter grievance description"
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                boxSizing:
                  "border-box",
                resize: "vertical",
              }}
            />
          </div>

          {/* CITIZEN */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "1fr 1fr",
              gap: 18,
            }}
          >
            <div>
              <label
                style={{
                  display: "block",
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Citizen Name *
              </label>

              <input
                type="text"
                name="citizenName"
                value={form.citizenName}
                onChange={handleChange}
                placeholder="Enter citizen name"
                style={{
                  width: "100%",
                  padding: 10,
                  border:
                    "1px solid #ccc",
                  borderRadius: 6,
                  boxSizing:
                    "border-box",
                }}
              />
            </div>

            <div>
              <label
                style={{
                  display: "block",
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Citizen Mobile *
              </label>

              <input
                type="tel"
                name="citizenMobile"
                value={
                  form.citizenMobile
                }
                onChange={handleChange}
                maxLength={10}
                placeholder="10 digit mobile"
                style={{
                  width: "100%",
                  padding: 10,
                  border:
                    "1px solid #ccc",
                  borderRadius: 6,
                  boxSizing:
                    "border-box",
                }}
              />
            </div>
          </div>

          {/* PRIORITY */}

          <div
            style={{
              marginTop: 18,
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Priority
            </label>

            <select
              name="priority"
              value={form.priority}
              onChange={handleChange}
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
              }}
            >
              <option value="LOW">
                Low
              </option>
              <option value="MEDIUM">
                Medium
              </option>
              <option value="HIGH">
                High
              </option>
            </select>
          </div>

          {/* CONSTITUENCY */}

          <div
            style={{
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Constituency
            </label>

            <select
              name="constituencyId"
              value={
                form.constituencyId
              }
              onChange={handleChange}
              disabled={
                loadingConstituencies
              }
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
              }}
            >
              <option value="">
                {loadingConstituencies
                  ? "Loading Constituencies..."
                  : constituencies.length ===
                    0
                  ? "No Constituencies Available"
                  : "Select Constituency"}
              </option>

              {constituencies.map(
                (c) => (
                  <option
                    key={c.id}
                    value={c.id}
                  >
                    {c.name}
                  </option>
                ),
              )}
            </select>
          </div>

          {/* MANDAL */}

          <div
            style={{
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Mandal *
            </label>

            <select
              name="mandalId"
              value={form.mandalId}
              onChange={
                handleMandalChange
              }
              disabled={loadingMandals}
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
              }}
            >
              <option value="">
                {loadingMandals
                  ? "Loading Mandals..."
                  : mandals.length === 0
                  ? "No Mandals Available"
                  : "Select Mandal *"}
              </option>

              {mandals.map((m) => (
                <option
                  key={m.id}
                  value={m.id}
                >
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          {/* VILLAGE */}

          <div
            style={{
              marginBottom: 18,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Village *
            </label>

            <select
              name="villageId"
              value={form.villageId}
              onChange={handleChange}
              disabled={
                loadingVillages ||
                !form.mandalId
              }
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
              }}
            >
              <option value="">
                {!form.mandalId
                  ? "Select Mandal first"
                  : loadingVillages
                  ? "Loading Villages..."
                  : selectedMandalVillages.length ===
                    0
                  ? "No Villages Available"
                  : "Select Village *"}
              </option>

              {selectedMandalVillages.map(
                (v) => (
                  <option
                    key={v.id}
                    value={v.id}
                  >
                    {v.name}
                  </option>
                ),
              )}
            </select>
          </div>

          {/* DEPARTMENT */}

          <div
            style={{
              marginBottom: 20,
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                marginBottom: 6,
              }}
            >
              Department
            </label>

            <select
              name="departmentId"
              value={
                form.departmentId
              }
              onChange={handleChange}
              disabled={
                loadingDepartments
              }
              style={{
                width: "100%",
                padding: 10,
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
              }}
            >
              <option value="">
                {loadingDepartments
                  ? "Loading Departments..."
                  : departments.length ===
                    0
                  ? "No Departments Available"
                  : "Select Department"}
              </option>

              {departments.map((d) => (
                <option
                  key={d.id}
                  value={d.id}
                >
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* BUTTONS */}

          <div
            style={{
              display: "flex",
              gap: 10,
            }}
          >
            <button
              type="submit"
              disabled={creating}
              style={{
                padding:
                  "10px 20px",
                cursor: creating
                  ? "not-allowed"
                  : "pointer",
                border: "none",
                borderRadius: 6,
                background: "#2563eb",
                color: "#fff",
                fontWeight: 600,
                opacity: creating
                  ? 0.7
                  : 1,
              }}
            >
              {creating
                ? "Creating..."
                : "Create Grievance"}
            </button>

            <button
              type="button"
              onClick={() =>
                navigate(
                  "/grievances",
                )
              }
              style={{
                padding:
                  "10px 20px",
                cursor: "pointer",
                border:
                  "1px solid #ccc",
                borderRadius: 6,
                background: "#fff",
                fontWeight: 600,
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}