# Grievance Mobile App

Fresh React Native + Expo + TypeScript mobile client built against the existing NestJS API (`/api/v1`).

## Implemented
- OTP login and verification
- SecureStore access/refresh token persistence
- JWT request interceptor + refresh flow
- Auth route guards
- Dashboard API integration
- My grievances list
- Grievance detail with history
- Comments read/create
- Create grievance with required backend DTO fields
- Notifications list/read
- Profile read/update/logout
- React Query cache/query management
- Shared UI/theme primitives

## Run
1. Copy `.env.example` to `.env` and set `EXPO_PUBLIC_API_URL`.
2. Install dependencies with `npm install`.
3. Start with `npx expo start`.

## Backend compatibility
The current API requires `title`, `description`, `citizenName`, `citizenMobile` for grievance creation. The mobile form now supplies those fields. Optional location/department IDs can be entered until picker screens are wired to the master-data endpoints.

## Next production pass
- Master-data dropdown selectors (constituency → mandal → village)
- Attachment picker/upload
- Push notification registration/deep links
- Role-specific actions and officer/MLA dashboards
- Better error/offline handling and automated tests
- Production API security hardening (OTP, refresh tokens, CORS)
