import 'dotenv/config';

import { PrismaClient, UserRole } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL!,
});

const prisma = new PrismaClient({
  adapter,
});

async function main() {

  await prisma.user.upsert({
    where: {
      mobile: '9000000000',
    },

    update: {
      role: UserRole.ADMIN,
    },

    create: {
      name: 'Admin User',
      mobile: '9000000000',
      role: UserRole.ADMIN,
    },
  });

  console.log('✅ Admin user seed completed');

}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);

    await prisma.$disconnect();

    process.exit(1);
  });