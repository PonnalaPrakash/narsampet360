# Update Notes

- Attachment download remains authenticated and access-controlled.
- Attachment storage names use UUIDs and physical files are not publicly served.
- Attachment controller duplicate import was removed.
- Attachment service uses explicit `randomUUID()` import.
- OTP generation/rate limiting and JWT secret validation remain enabled.
- CORS is configurable with `CORS_ORIGINS` and the API port with `PORT`.
- Production environment variables are documented in `.env.example`.
- Production OTP delivery uses the MSG91 SMS Flow API with `MSG91_AUTH_KEY` and `MSG91_OTP_TEMPLATE_ID`.
- The MSG91 OTP template must include the OTP as `VAR1`; Indian numbers are sent with the `91` country prefix.
