import {
  NestFactory,
} from '@nestjs/core';

import {
  AppModule,
} from './app.module';

import {
  ValidationPipe,
} from '@nestjs/common';

import {
  SwaggerModule,
  DocumentBuilder,
} from '@nestjs/swagger';



async function bootstrap() {

  if (!process.env.JWT_ACCESS_SECRET || process.env.JWT_ACCESS_SECRET.length < 32) {
    throw new Error('JWT_ACCESS_SECRET must be set to a random secret of at least 32 characters');
  }

  const app =
    await NestFactory.create(
      AppModule,
    );


  const corsOrigins = (process.env.CORS_ORIGINS || 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  app.enableCors({
    origin: corsOrigins,
    credentials: true,
  });


  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );


  app.setGlobalPrefix(
    'api/v1',
  );


  const config =
    new DocumentBuilder()

      .setTitle(
        'Narsampet360 API',
      )

      .setDescription(
        'MLA Constituency Management System API',
      )

      .setVersion(
        '1.0',
      )

      .addBearerAuth(
        {
          type:'http',
          scheme:'bearer',
          bearerFormat:'JWT',
        },
        'access-token',
      )

      .build();

const document =
  SwaggerModule.createDocument(
    app,
    config,
    {
      deepScanRoutes:true,
    },
  );


document.security = [
  {
    'access-token': [],
  },
];


SwaggerModule.setup(
  'docs',
  app,
  document,
  {
    swaggerOptions:{
      persistAuthorization:true,
    },
  },
);


  const port = Number(process.env.PORT || 3000);
  await app.listen(port);

}

bootstrap();