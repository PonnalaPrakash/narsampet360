import { Module } from '@nestjs/common';

import { ConstituencyController } from './constituency.controller';
import { ConstituencyService } from './constituency.service';

import { DatabaseModule } from '../database/database.module';

@Module({
  imports: [
    DatabaseModule,
  ],

  controllers: [
    ConstituencyController,
  ],

  providers: [
    ConstituencyService,
  ],

  exports: [
    ConstituencyService,
  ],
})
export class ConstituencyModule {}