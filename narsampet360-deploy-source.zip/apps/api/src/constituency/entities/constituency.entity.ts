export class Constituency {}
