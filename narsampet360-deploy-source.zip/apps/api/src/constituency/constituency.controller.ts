
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';

import {
  ApiBearerAuth,
  ApiTags,
} from '@nestjs/swagger';

import { ConstituencyService } from './constituency.service';

import { CreateConstituencyDto } from './dto/create-constituency.dto';
import { UpdateConstituencyDto } from './dto/update-constituency.dto';

import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Constituency')
@ApiBearerAuth('access-token')
@Controller('constituencies')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ConstituencyController {
  constructor(
    private readonly constituencyService: ConstituencyService,
  ) {}

  // CREATE CONSTITUENCY
  @Post()
  @Roles('ADMIN', 'MLA')
  create(
    @Body() createConstituencyDto: CreateConstituencyDto,
  ) {
    return this.constituencyService.create(
      createConstituencyDto,
    );
  }

  // GET ALL CONSTITUENCIES
  @Get()
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )
  findAll() {
    return this.constituencyService.findAll();
  }

  // GET SINGLE CONSTITUENCY
  @Get(':id')
  @Roles('ADMIN', 'MLA', 'PA')
  findOne(@Param('id') id: string) {
    return this.constituencyService.findOne(id);
  }

  // UPDATE CONSTITUENCY
  @Patch(':id')
  @Roles('ADMIN', 'MLA')
  update(
    @Param('id') id: string,
    @Body() updateConstituencyDto: UpdateConstituencyDto,
  ) {
    return this.constituencyService.update(
      id,
      updateConstituencyDto,
    );
  }

  // DELETE CONSTITUENCY
  @Delete(':id')
  @Roles('ADMIN')
  remove(@Param('id') id: string) {
    return this.constituencyService.remove(id);
  }
}
