
import {
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateConstituencyDto {
  @ApiProperty({
    example: 'Narsampet Constituency',
    description: 'Name of the constituency',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    example: 'Warangal',
    description: 'District of the constituency',
  })
  @IsString()
  @IsNotEmpty()
  district: string;

  @ApiProperty({
    example: 'Telangana',
    description: 'State of the constituency',
  })
  @IsString()
  @IsNotEmpty()
  state: string;

  @ApiPropertyOptional({
    example: 'Donthi Madhav Reddy',
    description: 'Name of the MLA',
  })
  @IsOptional()
  @IsString()
  mlaName?: string;
}
