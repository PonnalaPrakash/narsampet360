import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { CreateConstituencyDto } from './dto/create-constituency.dto';
import { UpdateConstituencyDto } from './dto/update-constituency.dto';
import { Constituency } from '@prisma/client';

@Injectable()
export class ConstituencyService {
  constructor(
    private readonly prisma: PrismaService,
  ) {}

  // CREATE CONSTITUENCY
  async create(
  createConstituencyDto: CreateConstituencyDto,
) {
  const {
    name,
    district,
    state,
    mlaName,
  } = createConstituencyDto;

  return this.prisma.constituency.create({
    data: {
      name,
      district,
      state,
      mlaName,
    },
  });
}

  // GET ALL CONSTITUENCIES
  async findAll(): Promise<Constituency[]> {
    return this.prisma.constituency.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  // GET SINGLE CONSTITUENCY
  async findOne(id: string): Promise<Constituency> {
    const constituency =
      await this.prisma.constituency.findUnique({
        where: {
          id,
        },
      });

    if (!constituency) {
      throw new NotFoundException(
        `Constituency with ID ${id} not found`,
      );
    }

    return constituency;
  }

  // UPDATE CONSTITUENCY
 async update(
  id: string,
  updateConstituencyDto: UpdateConstituencyDto,
) {
  await this.findOne(id);

  return this.prisma.constituency.update({
    where: {
      id,
    },
    data: {
      ...updateConstituencyDto,
    },
  });
}

  // DELETE CONSTITUENCY
  async remove(id: string): Promise<Constituency> {
    // Check whether constituency exists
    await this.findOne(id);

    return this.prisma.constituency.delete({
      where: {
        id,
      },
    });
  }
}