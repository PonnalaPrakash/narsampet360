
import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from "@nestjs/common";

import {
  ApiBearerAuth,
  ApiTags,
} from "@nestjs/swagger";

import {
  UserRole,
} from "@prisma/client";

import {
  JwtAuthGuard,
} from "../auth/jwt-auth.guard";

import {
  RolesGuard,
} from "../auth/roles.guard";

import {
  Roles,
} from "../auth/roles.decorator";

import {
  GrievanceService,
} from "./grievance.service";

import {
  CreateGrievanceDto,
} from "./dto/create-grievance.dto";

import {
  UpdateStatusDto,
} from "./dto/update-status.dto";

import {
  AssignGrievanceDto,
} from "./dto/assign-grievance.dto";


@ApiTags("Grievance")
@ApiBearerAuth("access-token")
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
@Controller("grievance")
export class GrievanceController {

  constructor(
    private readonly grievanceService: GrievanceService,
  ) {}


  // ============================================================
  // CREATE GRIEVANCE
  // POST /api/v1/grievance
  // ============================================================

  @Post()
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  create(
    @Body() dto: CreateGrievanceDto,
    @Req() req: any,
  ) {
    return this.grievanceService.create(
      dto,
      req.user,
    );
  }


  // ============================================================
  // GET ALL GRIEVANCES
  // GET /api/v1/grievance
  // ============================================================

  @Get()
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  findAll(
    @Req() req: any,
    @Query("status") status?: string,
    @Query("date") date?: string,
  ) {
    return this.grievanceService.findAll(
      req.user,
      {
        status,
        date,
      },
    );
  }


  // ============================================================
  // GET MY GRIEVANCES
  // GET /api/v1/grievance/my
  // ============================================================

  @Get("my")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  findMy(
    @Req() req: any,
  ) {
    return this.grievanceService.findMy(
      req.user,
    );
  }


  // ============================================================
  // GET DASHBOARD
  // GET /api/v1/grievance/dashboard
  // ============================================================

  @Get("dashboard")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  dashboard(
    @Req() req: any,
  ) {
    return this.grievanceService.dashboard(
      req.user,
    );
  }


  // ============================================================
  // GET GRIEVANCE HISTORY
  // GET /api/v1/grievance/:id/history
  // ============================================================

  @Get(":id/history")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  getHistory(
    @Param("id") id: string,
    @Req() req: any,
  ) {
    return this.grievanceService.getHistory(
      id,
      req.user,
    );
  }


  // ============================================================
  // UNDO LAST STATUS CHANGE
  // POST /api/v1/grievance/:id/undo
  // ============================================================

  @Post(":id/undo")
  @Roles(
    UserRole.ADMIN,
    UserRole.PA,
    UserRole.OFFICER,
    UserRole.VILLAGE_COORDINATOR,
  )
  undoStatus(
    @Param("id") id: string,
    @Req() req: any,
  ) {
    return this.grievanceService.undoStatus(
      id,
      req.user,
    );
  }


  // ============================================================
  // GET SINGLE GRIEVANCE
  // GET /api/v1/grievance/:id
  // ============================================================

  @Get(":id")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  findOne(
    @Param("id") id: string,
    @Req() req: any,
  ) {
    return this.grievanceService.findOne(
      id,
      req.user,
    );
  }


  // ============================================================
  // UPDATE GRIEVANCE STATUS
  // PATCH /api/v1/grievance/:id/status
  // ============================================================

  @Patch(":id/status")
  @Roles(
    UserRole.ADMIN,
    UserRole.PA,
    UserRole.OFFICER,
    UserRole.VILLAGE_COORDINATOR,
  )
  updateStatus(
    @Param("id") id: string,
    @Body() dto: UpdateStatusDto,
    @Req() req: any,
  ) {
    return this.grievanceService.updateStatus(
      id,
      dto.status,
      req.user,
      dto.remarks?.trim() || undefined,
    );
  }


  // ============================================================
  // ASSIGN GRIEVANCE
  // PATCH /api/v1/grievance/:id/assign
  // ============================================================

  @Patch(":id/assign")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
  )
  assign(
    @Param("id") id: string,
    @Body() dto: AssignGrievanceDto,
    @Req() req: any,
  ) {
    return this.grievanceService.assign(
      id,
      dto.assignedToId,
      req.user,
    );
  }
}
