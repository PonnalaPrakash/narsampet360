import { Test, TestingModule } from '@nestjs/testing';
import { GrievanceController } from './grievance.controller';
import { GrievanceService } from './grievance.service';

describe('GrievanceController', () => {
  let controller: GrievanceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GrievanceController],
      providers: [
        {
          provide: GrievanceService,
          useValue: {},
        },
      ],
    }).compile();

    controller = module.get<GrievanceController>(GrievanceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});