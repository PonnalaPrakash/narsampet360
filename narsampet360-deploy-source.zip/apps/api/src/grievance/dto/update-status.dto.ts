import {
  IsEnum,
  IsOptional,
  IsString,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';

import {
  GrievanceStatus,
} from '@prisma/client';



export class UpdateStatusDto {


  @ApiProperty({
    enum:GrievanceStatus,
    example:'IN_PROGRESS',
  })
  @IsEnum(GrievanceStatus)
  status:GrievanceStatus;



  @ApiPropertyOptional({
    example:'Work started by department officer',
  })
  @IsOptional()
  @IsString()
  remarks?:string;


}