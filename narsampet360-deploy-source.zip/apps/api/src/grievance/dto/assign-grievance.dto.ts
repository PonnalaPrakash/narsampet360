import {
  IsUUID,
} from 'class-validator';

import {
  ApiProperty,
} from '@nestjs/swagger';



export class AssignGrievanceDto {


  @ApiProperty({
    example:'user-id',
    description:'Officer / User id to assign grievance',
  })
  @IsUUID()
  assignedToId:string;


}