import {
  IsString,
  IsOptional,
  IsEnum,
  IsUUID,
  Length,
  Matches,
} from 'class-validator';

import {
  ApiPropertyOptional,
} from '@nestjs/swagger';

import {
  GrievancePriority,
} from '@prisma/client';



export class UpdateGrievanceDto {


  @ApiPropertyOptional({
    example:'Road Problem',
  })
  @IsOptional()
  @IsString()
  @Length(3,100)
  title?: string;



  @ApiPropertyOptional({
    example:'Road damaged near village',
  })
  @IsOptional()
  @IsString()
  description?: string;



  @ApiPropertyOptional({
    example:'Ramesh Kumar',
  })
  @IsOptional()
  @IsString()
  citizenName?: string;



  @ApiPropertyOptional({
    example:'8888888888',
  })
  @IsOptional()
  @IsString()
  @Matches(/^[6-9]\d{9}$/, {
    message:'Invalid mobile number',
  })
  citizenMobile?: string;



  @ApiPropertyOptional({
    enum:GrievancePriority,
    example:'URGENT',
  })
  @IsOptional()
  @IsEnum(GrievancePriority)
  priority?: GrievancePriority;



  @ApiPropertyOptional({
    example:'constituency-id',
  })
  @IsOptional()
  @IsUUID()
  constituencyId?: string;



  @ApiPropertyOptional({
    example:'mandal-id',
  })
  @IsOptional()
  @IsUUID()
  mandalId?: string;



  @ApiPropertyOptional({
    example:'village-id',
  })
  @IsOptional()
  @IsUUID()
  villageId?: string;



  @ApiPropertyOptional({
    example:'department-id',
  })
  @IsOptional()
  @IsUUID()
  departmentId?: string;


}