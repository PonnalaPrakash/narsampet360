import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsEnum,
  IsUUID,
  Length,
  Matches,
} from "class-validator";

import {
  ApiProperty,
  ApiPropertyOptional,
} from "@nestjs/swagger";

import {
  GrievancePriority,
} from "@prisma/client";

export class CreateGrievanceDto {
  @ApiProperty({
    example: "Water Problem",
  })
  @IsString()
  @IsNotEmpty()
  @Length(3, 100)
  title: string;

  @ApiProperty({
    example: "No drinking water from last 3 days",
  })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({
    example: "Ramesh Kumar",
  })
  @IsString()
  @IsNotEmpty()
  citizenName: string;

  @ApiProperty({
    example: "8888888888",
  })
  @IsString()
  @Matches(/^[6-9]\d{9}$/, {
    message: "Invalid mobile number",
  })
  citizenMobile: string;

  @ApiPropertyOptional({
    enum: GrievancePriority,
    example: "HIGH",
  })
  @IsOptional()
  @IsEnum(GrievancePriority)
  priority?: GrievancePriority;

  @ApiPropertyOptional({
    example: "constituency-id",
  })
  @IsOptional()
  @IsUUID()
  constituencyId?: string;

  // ============================================================
  // MANDAL - REQUIRED
  // ============================================================

  @ApiProperty({
    example: "mandal-id",
    description: "Mandal is required for every grievance",
  })
  @IsUUID()
  mandalId: string;

  // ============================================================
  // VILLAGE - REQUIRED
  // ============================================================

  @ApiProperty({
    example: "village-id",
    description: "Village is required for every grievance",
  })
  @IsUUID()
  villageId: string;

  @ApiPropertyOptional({
    example: "department-id",
  })
  @IsOptional()
  @IsUUID()
  departmentId?: string;
}