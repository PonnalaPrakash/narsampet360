
import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from "@nestjs/common";

import { PrismaService } from "../database/prisma.service";

import {
  UserRole,
  GrievanceStatus,
  GrievancePriority,
  NotificationType,
  Prisma,
} from "@prisma/client";

@Injectable()
export class GrievanceService {
  constructor(
    private readonly prisma: PrismaService,
  ) {}

  // ============================================================
  // CREATE
  // ============================================================
async create(
  data: any,
  user: any,
) {
  if (!user?.userId) {
    throw new BadRequestException(
      "Invalid user",
    );
  }

  const dbUser =
    await this.prisma.user.findUnique({
      where: {
        id: user.userId,
      },
    });

  if (!dbUser) {
    throw new NotFoundException(
      "User not found",
    );
  }

  // ----------------------------------------------------------
  // MANDATORY LOCATION
  // ----------------------------------------------------------

  if (!data.mandalId || !data.villageId) {
    throw new BadRequestException(
      "Mandal and Village are required",
    );
  }

  // ----------------------------------------------------------
  // VERIFY VILLAGE EXISTS
  // ----------------------------------------------------------

  const village =
    await this.prisma.village.findUnique({
      where: {
        id: data.villageId,
      },
      select: {
        id: true,
        mandalId: true,
      },
    });

  if (!village) {
    throw new BadRequestException(
      "Selected village not found",
    );
  }

  // ----------------------------------------------------------
  // VERIFY VILLAGE BELONGS TO MANDAL
  // ----------------------------------------------------------

  if (
    village.mandalId !==
    data.mandalId
  ) {
    throw new BadRequestException(
      "Selected village does not belong to selected mandal",
    );
  }

  // ----------------------------------------------------------
  // ROLE LOCATION RESTRICTIONS
  // ----------------------------------------------------------

  if (
    user.role ===
      UserRole.VILLAGE_COORDINATOR &&
    data.villageId !==
      dbUser.villageId
  ) {
    throw new ForbiddenException(
      "Cannot create outside assigned village",
    );
  }

  if (
    user.role ===
      UserRole.MANDAL_INCHARGE &&
    data.mandalId !==
      dbUser.mandalId
  ) {
    throw new ForbiddenException(
      "Cannot create outside assigned mandal",
    );
  }

  if (
    (
      user.role === UserRole.MLA ||
      user.role === UserRole.PA
    ) &&
    data.constituencyId &&
    data.constituencyId !==
      dbUser.constituencyId
  ) {
    throw new ForbiddenException(
      "Cannot create outside constituency",
    );
  }

  // ----------------------------------------------------------
  // CREATE GRIEVANCE
  // ----------------------------------------------------------

  return this.prisma.grievance.create({
    data: {
      title: data.title,
      description: data.description,
      citizenName: data.citizenName,
      citizenMobile: data.citizenMobile,

      priority:
        data.priority ??
        GrievancePriority.MEDIUM,

      constituencyId:
        data.constituencyId ??
        dbUser.constituencyId ??
        null,

      mandalId: data.mandalId,

      villageId: data.villageId,

      departmentId:
        data.departmentId ??
        null,

      createdById:
        user.userId,
    },
  });
}

  // ============================================================
  // ACCESS WHERE
  // ============================================================

  private buildAccessWhere(
    user: any,
  ): Prisma.GrievanceWhereInput {
    switch (user.role) {
      case UserRole.ADMIN:
        return {};

      case UserRole.MLA:
      case UserRole.PA:
        return {
          constituencyId:
            user.constituencyId,
        };

      case UserRole.OFFICER:
        return {
          assignedToId:
            user.userId,
        };

      case UserRole.VILLAGE_COORDINATOR:
        return {
          villageId:
            user.villageId,
        };

      case UserRole.MANDAL_INCHARGE:
        return {
          mandalId:
            user.mandalId,
        };

      default:
        throw new ForbiddenException(
          "Access denied",
        );
    }
  }

  // ============================================================
  // INCLUDE
  // ============================================================

  private getGrievanceInclude() {
    return {
      constituency: true,
      mandal: true,
      village: true,
      department: true,

      assignedTo: {
        select: {
          id: true,
          name: true,
          mobile: true,
        },
      },

      createdBy: {
        select: {
          id: true,
          name: true,
        },
      },

      history: {
        orderBy: {
          createdAt: "desc" as const,
        },
      },
    };
  }

  // ============================================================
  // FIND ALL
  // ============================================================

  async findAll(
    user: any,
    filters?: {
      status?: string;
      date?: string;
    },
  ) {
    const accessWhere =
      this.buildAccessWhere(user);

    const where: Prisma.GrievanceWhereInput = {
      ...accessWhere,
    };

    if (filters?.status) {
      const validStatuses =
        Object.values(
          GrievanceStatus,
        );

      if (
        !validStatuses.includes(
          filters.status as GrievanceStatus,
        )
      ) {
        throw new BadRequestException(
          "Invalid grievance status",
        );
      }

      where.status =
        filters.status as GrievanceStatus;
    }

    if (filters?.date) {
      const startOfDay = new Date(
        `${filters.date}T00:00:00`,
      );

      const endOfDay = new Date(
        `${filters.date}T23:59:59.999`,
      );

      if (
        Number.isNaN(
          startOfDay.getTime(),
        )
      ) {
        throw new BadRequestException(
          "Invalid date",
        );
      }

      where.createdAt = {
        gte: startOfDay,
        lte: endOfDay,
      };
    }

    return this.prisma.grievance.findMany({
      where,

      orderBy: {
        createdAt: "desc",
      },

      include:
        this.getGrievanceInclude(),
    });
  }

  // ============================================================
  // FIND MY
  // ============================================================

  async findMy(
    user: any,
  ) {
    const where =
      this.buildAccessWhere(user);

    return this.prisma.grievance.findMany({
      where,

      orderBy: {
        createdAt: "desc",
      },

      include:
        this.getGrievanceInclude(),
    });
  }

  // ============================================================
  // FIND ONE
  // ============================================================

  async findOne(
    id: string,
    user: any,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id,
        },

        include:
          this.getGrievanceInclude(),
      });

    if (!grievance) {
      throw new NotFoundException(
        "Grievance not found",
      );
    }

    if (
      user.role !== UserRole.ADMIN &&
      !this.checkAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        "Access denied",
      );
    }

    return grievance;
  }

  // ============================================================
  // UPDATE STATUS
  // ============================================================

  async updateStatus(
    id: string,
    status: GrievanceStatus,
    user: any,
    remarks?: string,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        "Grievance not found",
      );
    }

    // ----------------------------------------------------------
    // ACCESS
    // ----------------------------------------------------------

    if (
      user.role !== UserRole.ADMIN &&
      !this.checkAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        "You cannot update this grievance",
      );
    }

    // ----------------------------------------------------------
    // SAME STATUS
    // ----------------------------------------------------------

    if (
      grievance.status === status
    ) {
      throw new BadRequestException(
        `Grievance already in ${status} status`,
      );
    }

    // ----------------------------------------------------------
    // CLOSED / REJECTED
    // ----------------------------------------------------------

    if (
      grievance.status ===
      GrievanceStatus.CLOSED
    ) {
      throw new BadRequestException(
        "Closed grievance cannot be updated. Use Undo Last Status first.",
      );
    }

    if (
      grievance.status ===
      GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        "Rejected grievance cannot be updated directly. Use Undo Last Status first.",
      );
    }

    // ==========================================================
    // PERMANENTLY BLOCK A TRANSITION THAT WAS ALREADY UNDONE
    // ==========================================================

    const alreadyUndoneTransition =
      await this.prisma.grievanceHistory.findFirst({
        where: {
          grievanceId: id,

          changedField:
            "UNDO",

          oldStatus:
            status,

          newStatus:
            grievance.status,
        },

        orderBy: [
          {
            createdAt: "desc",
          },
          {
            id: "desc",
          },
        ],
      });

    if (alreadyUndoneTransition) {
      throw new BadRequestException(
        `This status transition (${grievance.status} → ${status}) was already undone and cannot be repeated.`,
      );
    }

    // ----------------------------------------------------------
    // STATUS WORKFLOW
    // ----------------------------------------------------------

    if (
      grievance.status ===
        GrievanceStatus.PENDING &&
      status !==
        GrievanceStatus.ASSIGNED &&
      status !==
        GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        "Pending grievance must be assigned before work can start",
      );
    }

    if (
      grievance.status ===
        GrievanceStatus.ASSIGNED &&
      status !==
        GrievanceStatus.IN_PROGRESS
    ) {
      throw new BadRequestException(
        "Assigned grievance can only move to in progress",
      );
    }

    if (
      grievance.status ===
        GrievanceStatus.IN_PROGRESS &&
      status !==
        GrievanceStatus.RESOLVED &&
      status !==
        GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        "In-progress grievance can only be resolved or rejected",
      );
    }

    if (
      grievance.status ===
      GrievanceStatus.RESOLVED
    ) {
      if (
        status !==
        GrievanceStatus.CLOSED
      ) {
        throw new BadRequestException(
          "Resolved grievance can only be closed",
        );
      }

      const latestHistory =
        await this.prisma.grievanceHistory.findFirst({
          where: {
            grievanceId: id,
          },

          orderBy: [
            {
              createdAt: "desc",
            },
            {
              id: "desc",
            },
          ],
        });

      if (
        latestHistory?.changedField ===
        "UNDO"
      ) {
        throw new BadRequestException(
          "This grievance was reverted by Undo. Make a new valid status action before closing it again.",
        );
      }
    }

    // ----------------------------------------------------------
    // OFFICER
    // ----------------------------------------------------------

    if (
      user.role === UserRole.OFFICER
    ) {
      if (
        grievance.assignedToId !==
        user.userId
      ) {
        throw new ForbiddenException(
          "This grievance is assigned to another officer",
        );
      }

      if (
        status !==
          GrievanceStatus.IN_PROGRESS &&
        status !==
          GrievanceStatus.RESOLVED
      ) {
        throw new ForbiddenException(
          "Officer can only move assigned grievances to in progress or resolved",
        );
      }
    }

    // ----------------------------------------------------------
    // REJECT / CLOSE
    // ----------------------------------------------------------

    if (
      status ===
        GrievanceStatus.REJECTED ||
      status ===
        GrievanceStatus.CLOSED
    ) {
      if (
        user.role !== UserRole.ADMIN &&
        user.role !== UserRole.PA
      ) {
        throw new ForbiddenException(
          "Only Admin or PA can perform this status action",
        );
      }
    }

    // ==========================================================
    // TRANSACTION
    // ==========================================================

    const updated =
      await this.prisma.$transaction(
        async (tx) => {
          const current =
            await tx.grievance.findUnique({
              where: {
                id,
              },
            });

          if (!current) {
            throw new NotFoundException(
              "Grievance not found",
            );
          }

          if (
            current.status === status
          ) {
            throw new BadRequestException(
              `Grievance already in ${status} status`,
            );
          }

          const alreadyUndoneTransition =
            await tx.grievanceHistory.findFirst({
              where: {
                grievanceId: id,

                changedField:
                  "UNDO",

                oldStatus:
                  status,

                newStatus:
                  current.status,
              },

              orderBy: [
                {
                  createdAt: "desc",
                },
                {
                  id: "desc",
                },
              ],
            });

          if (
            alreadyUndoneTransition
          ) {
            throw new BadRequestException(
              `This status transition (${current.status} → ${status}) was already undone and cannot be repeated.`,
            );
          }

          const result =
            await tx.grievance.update({
              where: {
                id,
              },

              data: {
                status,

                resolvedAt:
                  status ===
                  GrievanceStatus.RESOLVED
                    ? new Date()
                    : status ===
                      GrievanceStatus.CLOSED
                      ? current.resolvedAt
                      : null,

                closedAt:
                  status ===
                  GrievanceStatus.CLOSED
                    ? new Date()
                    : null,
              },
            });

          await tx.grievanceHistory.create({
            data: {
              grievanceId:
                id,

              oldStatus:
                current.status,

              newStatus:
                status,

              changedById:
                user.userId,

              remarks:
                remarks ||
                `Status changed from ${current.status} to ${status}`,
            },
          });

          return result;
        },
      );

    // ----------------------------------------------------------
    // NOTIFICATION
    // ----------------------------------------------------------

    if (
      grievance.assignedToId
    ) {
      await this.prisma.notification.create({
        data: {
          userId:
            grievance.assignedToId,

          grievanceId:
            id,

          type:
            NotificationType.INFO,

          title:
            "Grievance Status Updated",

          message:
            `Grievance "${grievance.title}" status changed to ${status}`,
        },
      });
    }

    return {
      message:
        "Status updated",

      grievance:
        updated,
    };
  }

  // ============================================================
  // UNDO
  // ============================================================

  async undoStatus(
    id: string,
    user: any,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        "Grievance not found",
      );
    }

    // ----------------------------------------------------------
    // PERMISSION
    // ----------------------------------------------------------

    if (
      user.role !== UserRole.ADMIN &&
      user.role !== UserRole.MLA &&
      user.role !== UserRole.PA
    ) {
      throw new ForbiddenException(
        "Only ADMIN, MLA or PA can undo an officer assignment.",
      );
    }

    // ----------------------------------------------------------
    // ACCESS
    // ----------------------------------------------------------

    if (
      user.role !== UserRole.ADMIN &&
      !this.checkAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        "You cannot undo this grievance",
      );
    }

    // ----------------------------------------------------------
    // ASSIGNMENT ONLY
    // ----------------------------------------------------------

    if (
      grievance.status !==
      GrievanceStatus.ASSIGNED
    ) {
      throw new BadRequestException(
        "Only an ASSIGNED grievance can have its assignment undone.",
      );
    }

    // ----------------------------------------------------------
    // LATEST HISTORY
    // ----------------------------------------------------------

    const latestHistory =
      await this.prisma.grievanceHistory.findFirst({
        where: {
          grievanceId: id,
        },

        orderBy: [
          {
            createdAt: "desc",
          },
          {
            id: "desc",
          },
        ],
      });

    if (!latestHistory) {
      throw new BadRequestException(
        "No previous status change available to undo",
      );
    }

    // ----------------------------------------------------------
    // PREVENT DOUBLE UNDO
    // ----------------------------------------------------------

    if (
      latestHistory.changedField ===
      "UNDO"
    ) {
      throw new BadRequestException(
        "The last action is already an undo. Make a new assignment before using undo again.",
      );
    }

    // ----------------------------------------------------------
    // CURRENT STATUS MUST MATCH
    // ----------------------------------------------------------

    if (
      grievance.status !==
      latestHistory.newStatus
    ) {
      throw new BadRequestException(
        "Grievance status has changed after the last status action. Cannot undo.",
      );
    }

    // ----------------------------------------------------------
    // ONLY ASSIGNMENT TRANSITION
    // ----------------------------------------------------------

    if (
      latestHistory.oldStatus !==
        GrievanceStatus.PENDING ||
      latestHistory.newStatus !==
        GrievanceStatus.ASSIGNED
    ) {
      throw new BadRequestException(
        "Only the latest officer assignment can be undone.",
      );
    }

    // ==========================================================
    // MAXIMUM 2 ASSIGNMENT UNDO ATTEMPTS
    // ==========================================================

    const assignmentUndoCount =
      await this.prisma.grievanceHistory.count({
        where: {
          grievanceId: id,

          changedField:
            "UNDO",

          oldStatus:
            GrievanceStatus.ASSIGNED,

          newStatus:
            GrievanceStatus.PENDING,
        },
      });

    if (assignmentUndoCount >= 2) {
      throw new BadRequestException(
        "Maximum 2 assignment undo attempts reached for this grievance.",
      );
    }

    // ==========================================================
    // TRANSACTION
    // ==========================================================

    const updated =
      await this.prisma.$transaction(
        async (tx) => {
          const current =
            await tx.grievance.findUnique({
              where: {
                id,
              },

              include: {
                assignedTo: {
                  select: {
                    id: true,
                    name: true,
                    mobile: true,
                  },
                },
              },
            });

          if (!current) {
            throw new NotFoundException(
              "Grievance not found",
            );
          }

          if (
            current.status !==
            GrievanceStatus.ASSIGNED
          ) {
            throw new BadRequestException(
              "Only an ASSIGNED grievance can have its assignment undone.",
            );
          }

          const currentLatestHistory =
            await tx.grievanceHistory.findFirst({
              where: {
                grievanceId: id,
              },

              orderBy: [
                {
                  createdAt: "desc",
                },
                {
                  id: "desc",
                },
              ],
            });

          if (
            !currentLatestHistory
          ) {
            throw new BadRequestException(
              "No previous status change available to undo",
            );
          }

          if (
            currentLatestHistory.changedField ===
            "UNDO"
          ) {
            throw new BadRequestException(
              "The last action is already an undo. Make a new assignment before using undo again.",
            );
          }

          if (
            currentLatestHistory.id !==
            latestHistory.id
          ) {
            throw new BadRequestException(
              "A newer status action already exists. This undo action is no longer valid.",
            );
          }

          if (
            current.status !==
            currentLatestHistory.newStatus
          ) {
            throw new BadRequestException(
              "Grievance status has already changed. This undo action is no longer valid.",
            );
          }

          if (
            currentLatestHistory.oldStatus !==
              GrievanceStatus.PENDING ||
            currentLatestHistory.newStatus !==
              GrievanceStatus.ASSIGNED
          ) {
            throw new BadRequestException(
              "Only the latest officer assignment can be undone.",
            );
          }

          // ------------------------------------------------------
          // RE-CHECK MAX 2 INSIDE TRANSACTION
          // ------------------------------------------------------

          const undoCount =
            await tx.grievanceHistory.count({
              where: {
                grievanceId: id,

                changedField:
                  "UNDO",

                oldStatus:
                  GrievanceStatus.ASSIGNED,

                newStatus:
                  GrievanceStatus.PENDING,
              },
            });

          if (undoCount >= 2) {
            throw new BadRequestException(
              "Maximum 2 assignment undo attempts reached for this grievance.",
            );
          }

          /*
            ASSIGNED
              ↓
            UNDO
              ↓
            PENDING

            Assignment is cleared.
          */

          const restoredStatus =
            GrievanceStatus.PENDING;

          const restoredAssignedToId =
            null;

          const result =
            await tx.grievance.update({
              where: {
                id,
              },

              data: {
                status:
                  restoredStatus,

                assignedToId:
                  restoredAssignedToId,

                resolvedAt:
                  null,

                closedAt:
                  null,
              },
            });

          await tx.grievanceHistory.create({
            data: {
              grievanceId:
                id,

              oldStatus:
                current.status,

              newStatus:
                restoredStatus,

              changedById:
                user.userId,

              changedField:
                "UNDO",

              remarks:
                "Undo: reverted from ASSIGNED to PENDING",
            },
          });

          return {
            result,

            restoredStatus,

            previousAssignedToId:
              current.assignedToId,
          };
        },
      );

    // ----------------------------------------------------------
    // NOTIFICATION
    // ----------------------------------------------------------

    if (
      updated.previousAssignedToId
    ) {
      await this.prisma.notification.create({
        data: {
          userId:
            updated.previousAssignedToId,

          grievanceId:
            id,

          type:
            NotificationType.INFO,

          title:
            "Grievance Assignment Undone",

          message:
            `Grievance "${grievance.title}" assignment has been undone and returned to PENDING`,
        },
      });
    }

    return {
      message:
        "Officer assignment undone successfully",

      previousStatus:
        grievance.status,

      restoredStatus:
        updated.restoredStatus,

      grievance:
        updated.result,
    };
  }

  // ============================================================
  // ASSIGN
  // ============================================================

  async assign(
    id: string,
    assignedToId: string,
    user: any,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id,
        },

        include: {
          department: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        "Grievance not found",
      );
    }

    // ----------------------------------------------------------
    // PERMISSION
    // ----------------------------------------------------------

    if (
      user.role !== UserRole.ADMIN &&
      user.role !== UserRole.MLA &&
      user.role !== UserRole.PA
    ) {
      throw new ForbiddenException(
        "You cannot assign grievances",
      );
    }

    // ----------------------------------------------------------
    // CONSTITUENCY
    // ----------------------------------------------------------

    if (
      (
        user.role === UserRole.MLA ||
        user.role === UserRole.PA
      ) &&
      grievance.constituencyId !==
        user.constituencyId
    ) {
      throw new ForbiddenException(
        "Outside constituency",
      );
    }

    // ----------------------------------------------------------
    // PENDING ONLY
    // ----------------------------------------------------------

    if (
      grievance.status !==
      GrievanceStatus.PENDING
    ) {
      throw new BadRequestException(
        "Only pending grievances can be assigned",
      );
    }

    // ==========================================================
    // MAXIMUM 2 ASSIGNMENT UNDO ATTEMPTS
    // ==========================================================

    const assignmentUndoCount =
      await this.prisma.grievanceHistory.count({
        where: {
          grievanceId: id,

          changedField:
            "UNDO",

          oldStatus:
            GrievanceStatus.ASSIGNED,

          newStatus:
            GrievanceStatus.PENDING,
        },
      });

    if (assignmentUndoCount >= 2) {
      throw new BadRequestException(
        "This grievance has already used the maximum 2 assignment undo attempts and cannot be assigned again.",
      );
    }

    // ----------------------------------------------------------
    // OFFICER
    // ----------------------------------------------------------

    const officer =
      await this.prisma.user.findUnique({
        where: {
          id: assignedToId,
        },

        select: {
          id: true,
          name: true,
          mobile: true,
          role: true,
          departmentId: true,
          constituencyId: true,

          department: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

    if (!officer) {
      throw new NotFoundException(
        "Assigned user not found",
      );
    }

    if (
      officer.role !==
      UserRole.OFFICER
    ) {
      throw new BadRequestException(
        "Only officer can be assigned",
      );
    }

    if (!officer.departmentId) {
      throw new BadRequestException(
        "Officer department not assigned",
      );
    }

    // ----------------------------------------------------------
    // CONSTITUENCY MATCH
    // ----------------------------------------------------------

    if (
      grievance.constituencyId &&
      officer.constituencyId &&
      grievance.constituencyId !==
        officer.constituencyId
    ) {
      throw new ForbiddenException(
        "Officer belongs to another constituency",
      );
    }

    // ----------------------------------------------------------
    // DEPARTMENT MATCH
    // ----------------------------------------------------------

    if (
      grievance.departmentId &&
      grievance.departmentId !==
        officer.departmentId
    ) {
      const grievanceDepartmentName =
        grievance.department?.name ??
        "Unknown Department";

      const officerDepartmentName =
        officer.department?.name ??
        "Unknown Department";

      throw new ForbiddenException(
        `Department mismatch: grievance belongs to "${grievanceDepartmentName}", but officer "${officer.name}" belongs to "${officerDepartmentName}"`,
      );
    }

    // ==========================================================
    // TRANSACTION
    // ==========================================================

    const updated =
      await this.prisma.$transaction(
        async (tx) => {
          const current =
            await tx.grievance.findUnique({
              where: {
                id,
              },

              include: {
                department: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
              },
            });

          if (!current) {
            throw new NotFoundException(
              "Grievance not found",
            );
          }

          if (
            current.status !==
            GrievanceStatus.PENDING
          ) {
            throw new BadRequestException(
              "Only pending grievances can be assigned",
            );
          }

          // ------------------------------------------------------
          // RE-CHECK MAX 2 INSIDE TRANSACTION
          // ------------------------------------------------------

          const undoCount =
            await tx.grievanceHistory.count({
              where: {
                grievanceId: id,

                changedField:
                  "UNDO",

                oldStatus:
                  GrievanceStatus.ASSIGNED,

                newStatus:
                  GrievanceStatus.PENDING,
              },
            });

          if (undoCount >= 2) {
            throw new BadRequestException(
              "This grievance has already used the maximum 2 assignment undo attempts and cannot be assigned again.",
            );
          }

          const result =
            await tx.grievance.update({
              where: {
                id,
              },

              data: {
                assignedToId:
                  officer.id,

                departmentId:
                  current.departmentId ??
                  officer.departmentId,

                status:
                  GrievanceStatus.ASSIGNED,

                resolvedAt:
                  null,

                closedAt:
                  null,
              },
            });

          await tx.grievanceHistory.create({
            data: {
              grievanceId:
                id,

              oldStatus:
                current.status,

              newStatus:
                GrievanceStatus.ASSIGNED,

              changedById:
                user.userId,

              remarks:
                `Assigned to ${officer.name}`,
            },
          });

          // ----------------------------------------------------
          // OFFICER NOTIFICATION
          // ----------------------------------------------------

          await tx.notification.create({
            data: {
              userId:
                officer.id,

              grievanceId:
                id,

              type:
                NotificationType.INFO,

              title:
                "New Grievance Assigned",

              message:
                `A grievance "${grievance.title}" has been assigned to you`,
            },
          });

          // ----------------------------------------------------
          // CREATOR NOTIFICATION
          // ----------------------------------------------------

          if (
            current.createdById &&
            current.createdById !==
              officer.id
          ) {
            await tx.notification.create({
              data: {
                userId:
                  current.createdById,

                grievanceId:
                  id,

                type:
                  NotificationType.INFO,

                title:
                  "Grievance Assigned",

                message:
                  `Your grievance "${grievance.title}" has been assigned`,
              },
            });
          }

          return result;
        },
      );

    return {
      message:
        "Grievance assigned successfully",

      grievance:
        updated,
    };
  }

  // ============================================================
  // DASHBOARD
  // ============================================================

  async dashboard(
    user: any,
  ) {
    const where =
      this.buildAccessWhere(user);

    const [
      total,
      pending,
      assigned,
      inProgress,
      resolved,
      rejected,
      closed,
    ] = await Promise.all([
      this.prisma.grievance.count({
        where,
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.PENDING,
        },
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.ASSIGNED,
        },
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.IN_PROGRESS,
        },
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.RESOLVED,
        },
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.REJECTED,
        },
      }),

      this.prisma.grievance.count({
        where: {
          ...where,
          status:
            GrievanceStatus.CLOSED,
        },
      }),
    ]);

    const startOfToday =
      new Date();

    startOfToday.setHours(
      0,
      0,
      0,
      0,
    );

    const startOfTomorrow =
      new Date(startOfToday);

    startOfTomorrow.setDate(
      startOfTomorrow.getDate() + 1,
    );

    const today =
      await this.prisma.grievance.count({
        where: {
          ...where,

          createdAt: {
            gte: startOfToday,
            lt: startOfTomorrow,
          },
        },
      });

    return {
      total,
      pending,
      assigned,
      inProgress,
      resolved,
      rejected,
      closed,
      today,
    };
  }

  // ============================================================
  // HISTORY
  // ============================================================

  async getHistory(
    id: string,
    user: any,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        "Grievance not found",
      );
    }

    if (
      user.role !== UserRole.ADMIN &&
      !this.checkAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        "Access denied",
      );
    }

    return this.prisma.grievanceHistory.findMany({
      where: {
        grievanceId: id,
      },

      orderBy: [
        {
          createdAt: "desc",
        },
        {
          id: "desc",
        },
      ],

      include: {
        user: {
          select: {
            id: true,
            name: true,
            mobile: true,
            role: true,
          },
        },
      },
    });
  }

  // ============================================================
  // ACCESS CHECK
  // ============================================================

  private checkAccess(
    grievance: any,
    user: any,
  ): boolean {
    switch (user.role) {
      case UserRole.ADMIN:
        return true;

      case UserRole.MLA:
      case UserRole.PA:
        return (
          !!user.constituencyId &&
          grievance.constituencyId ===
            user.constituencyId
        );

      case UserRole.OFFICER:
        return (
          grievance.assignedToId ===
          user.userId
        );

      case UserRole.VILLAGE_COORDINATOR:
        return (
          !!user.villageId &&
          grievance.villageId ===
            user.villageId
        );

      case UserRole.MANDAL_INCHARGE:
        return (
          !!user.mandalId &&
          grievance.mandalId ===
            user.mandalId
        );

      default:
        return false;
    }
  }
}