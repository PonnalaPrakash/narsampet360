import { Test, TestingModule } from "@nestjs/testing";
import { BadRequestException, ForbiddenException, NotFoundException } from "@nestjs/common";
import { GrievancePriority, GrievanceStatus, UserRole } from "@prisma/client";
import { GrievanceService } from "./grievance.service";
import { PrismaService } from "../database/prisma.service";

describe("GrievanceService - status workflow", () => {
  let service: GrievanceService;
  let prisma: any;

  const admin = { userId: "admin-1", role: UserRole.ADMIN };
  const pa = { userId: "pa-1", role: UserRole.PA, constituencyId: "c-1" };
  const officer = { userId: "officer-1", role: UserRole.OFFICER };

  const grievance = (status: GrievanceStatus, overrides: any = {}) => ({
    id: "g-1",
    title: "Road repair",
    status,
    priority: GrievancePriority.MEDIUM,
    assignedToId: "officer-1",
    constituencyId: "c-1",
    mandalId: "m-1",
    villageId: "v-1",
    resolvedAt: null,
    closedAt: null,
    ...overrides,
  });

  beforeEach(async () => {
    prisma = {
      grievance: {
        findUnique: jest.fn(),
        update: jest.fn(),
      },
      grievanceHistory: {
        findFirst: jest.fn().mockResolvedValue(null),
        create: jest.fn(),
      },
      notification: {
        create: jest.fn(),
      },
      $transaction: jest.fn(async (callback: any) => callback(prisma)),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GrievanceService,
        { provide: PrismaService, useValue: prisma },
      ],
    }).compile();

    service = module.get<GrievanceService>(GrievanceService);
  });

  it("rejects an unknown grievance", async () => {
    prisma.grievance.findUnique.mockResolvedValue(null);

    await expect(
      service.updateStatus("missing", GrievanceStatus.ASSIGNED, admin),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it("rejects changing to the same status", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.ASSIGNED));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.ASSIGNED, admin),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it("allows PENDING -> ASSIGNED", async () => {
    const current = grievance(GrievanceStatus.PENDING);
    const updated = grievance(GrievanceStatus.ASSIGNED);
    prisma.grievance.findUnique.mockResolvedValueOnce(current).mockResolvedValueOnce(current);
    prisma.grievance.update.mockResolvedValue(updated);

    const result = await service.updateStatus("g-1", GrievanceStatus.ASSIGNED, admin);

    expect(result.message).toBe("Status updated");
    expect(prisma.grievance.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ status: GrievanceStatus.ASSIGNED }) }),
    );
    expect(prisma.grievanceHistory.create).toHaveBeenCalled();
  });

  it("rejects PENDING -> IN_PROGRESS", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.PENDING));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.IN_PROGRESS, admin),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it("allows ASSIGNED -> IN_PROGRESS", async () => {
    const current = grievance(GrievanceStatus.ASSIGNED);
    prisma.grievance.findUnique.mockResolvedValueOnce(current).mockResolvedValueOnce(current);
    prisma.grievance.update.mockResolvedValue(grievance(GrievanceStatus.IN_PROGRESS));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.IN_PROGRESS, officer),
    ).resolves.toEqual(expect.objectContaining({ message: "Status updated" }));
  });

  it("blocks an officer from updating another officer's grievance", async () => {
    prisma.grievance.findUnique.mockResolvedValue(
      grievance(GrievanceStatus.ASSIGNED, { assignedToId: "officer-2" }),
    );

    await expect(
      service.updateStatus("g-1", GrievanceStatus.IN_PROGRESS, officer),
    ).rejects.toBeInstanceOf(ForbiddenException);
  });

  it("allows IN_PROGRESS -> RESOLVED for the assigned officer", async () => {
    const current = grievance(GrievanceStatus.IN_PROGRESS);
    prisma.grievance.findUnique.mockResolvedValueOnce(current).mockResolvedValueOnce(current);
    prisma.grievance.update.mockResolvedValue(grievance(GrievanceStatus.RESOLVED));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.RESOLVED, officer),
    ).resolves.toEqual(expect.objectContaining({ message: "Status updated" }));
  });

  it("blocks officer from rejecting a grievance", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.IN_PROGRESS));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.REJECTED, officer),
    ).rejects.toBeInstanceOf(ForbiddenException);
  });

  it("allows RESOLVED -> CLOSED for PA", async () => {
    const current = grievance(GrievanceStatus.RESOLVED, { assignedToId: null });
    prisma.grievance.findUnique.mockResolvedValueOnce(current).mockResolvedValueOnce(current);
    prisma.grievanceHistory.findFirst.mockResolvedValue(null);
    prisma.grievance.update.mockResolvedValue(grievance(GrievanceStatus.CLOSED));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.CLOSED, pa),
    ).resolves.toEqual(expect.objectContaining({ message: "Status updated" }));
  });

  it("blocks CLOSED grievances from direct updates", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.CLOSED));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.ASSIGNED, admin),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it("blocks REJECTED grievances from direct updates", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.REJECTED));

    await expect(
      service.updateStatus("g-1", GrievanceStatus.ASSIGNED, admin),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it("blocks a transition that was already undone", async () => {
    prisma.grievance.findUnique.mockResolvedValue(grievance(GrievanceStatus.ASSIGNED));
    prisma.grievanceHistory.findFirst.mockResolvedValue({
      changedField: "UNDO",
      oldStatus: GrievanceStatus.IN_PROGRESS,
      newStatus: GrievanceStatus.ASSIGNED,
    });

    await expect(
      service.updateStatus("g-1", GrievanceStatus.IN_PROGRESS, admin),
    ).rejects.toBeInstanceOf(BadRequestException);
  });
});
