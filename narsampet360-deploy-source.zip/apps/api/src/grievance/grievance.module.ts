import { Module } from '@nestjs/common';

import { GrievanceController } from './grievance.controller';
import { GrievanceService } from './grievance.service';

import { DatabaseModule } from '../database/database.module';


@Module({
  imports: [
    DatabaseModule,
  ],

  controllers: [
    GrievanceController,
  ],

  providers: [
    GrievanceService,
  ],
})
export class GrievanceModule {}