import {
 Injectable,
 NotFoundException,
} from '@nestjs/common';

import {
 PrismaService,
} from '../database/prisma.service';



@Injectable()
export class NotificationsService {


constructor(
 private prisma:PrismaService,
){}



// GET USER NOTIFICATIONS

async findMyNotifications(
 userId:string,
){

 return this.prisma.notification.findMany({

  where:{
   userId,
  },


  orderBy:{
   createdAt:'desc',
  },


  include:{

   grievance:{
    select:{
     id:true,
     title:true,
     status:true,
    }
   }

  }

 });


}



// UNREAD COUNT

async unreadCount(
 userId:string,
){

 const count =
 await this.prisma.notification.count({

  where:{

   userId,

   isRead:false,

  }

 });


 return {
  unread:count,
 };

}



// MARK READ

async markRead(
 id:string,
 userId:string,
){

 const notification =
 await this.prisma.notification.findFirst({

  where:{

   id,

   userId,

  }

 });


 if(!notification){

  throw new NotFoundException(
   'Notification not found'
  );

 }



 return this.prisma.notification.update({

  where:{
   id,
  },


  data:{

   isRead:true,

  }


 });


}


}