import {
 Controller,
 Get,
 Patch,
 Param,
 Req,
 UseGuards,
} from '@nestjs/common';

import {
 ApiBearerAuth,
 ApiTags,
} from '@nestjs/swagger';

import {
 NotificationsService,
} from './notifications.service';

import {
 JwtAuthGuard,
} from '../auth/jwt-auth.guard';



@ApiTags('Notifications')

@ApiBearerAuth('access-token')

@UseGuards(JwtAuthGuard)

@Controller('notifications')
export class NotificationsController {


constructor(
 private readonly notificationsService:NotificationsService,
){}



// MY NOTIFICATIONS

@Get()

findMyNotifications(
 @Req() req:any,
){

 return this.notificationsService.findMyNotifications(
  req.user.userId
 );

}




// UNREAD COUNT

@Get('unread/count')

unreadCount(
 @Req() req:any,
){

 return this.notificationsService.unreadCount(
  req.user.userId
 );

}




// MARK READ

@Patch(':id/read')

markRead(
 @Param('id') id:string,

 @Req() req:any,
){

 return this.notificationsService.markRead(
  id,
  req.user.userId
 );

}


}