import { IsNotEmpty, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateCommentDto {
  @IsUUID()
  grievanceId: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(5000)
  message: string;
}