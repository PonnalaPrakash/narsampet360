import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from "@nestjs/common";

import {
  ApiBearerAuth,
  ApiTags,
} from "@nestjs/swagger";

import {
  UserRole,
} from "@prisma/client";

import {
  JwtAuthGuard,
} from "../auth/jwt-auth.guard";

import {
  RolesGuard,
} from "../auth/roles.guard";

import {
  Roles,
} from "../auth/roles.decorator";

import {
  CommentsService,
} from "./comments.service";

import {
  CreateCommentDto,
} from "./dto/create-comment.dto";

import {
  UpdateCommentDto,
} from "./dto/update-comment.dto";


@ApiTags("Comments")
@ApiBearerAuth("access-token")
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
@Controller("comments")
export class CommentsController {
  constructor(
    private readonly commentsService: CommentsService,
  ) {}


  // ============================================================
  // ADD COMMENT
  // POST /api/v1/comments
  // ============================================================

  @Post()
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  create(
    @Body() dto: CreateCommentDto,
    @Req() req: any,
  ) {
    return this.commentsService.create(
      dto,
      req.user,
    );
  }


  // ============================================================
  // GET COMMENTS FOR A GRIEVANCE
  // GET /api/v1/comments?grievanceId=xxxx
  // ============================================================

  @Get()
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  findAll(
    @Query("grievanceId") grievanceId: string,
    @Req() req: any,
  ) {
    return this.commentsService.findAll(
      grievanceId,
      req.user,
    );
  }


  // ============================================================
  // GET SINGLE COMMENT
  // GET /api/v1/comments/:id
  // ============================================================

  @Get(":id")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  findOne(
    @Param("id") id: string,
    @Req() req: any,
  ) {
    return this.commentsService.findOne(
      id,
      req.user,
    );
  }


  // ============================================================
  // UPDATE COMMENT
  // PATCH /api/v1/comments/:id
  // ============================================================

  @Patch(":id")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  update(
    @Param("id") id: string,
    @Body() dto: UpdateCommentDto,
    @Req() req: any,
  ) {
    return this.commentsService.update(
      id,
      dto,
      req.user,
    );
  }


  // ============================================================
  // DELETE COMMENT
  // DELETE /api/v1/comments/:id
  // ============================================================

  @Delete(":id")
  @Roles(
    UserRole.ADMIN,
    UserRole.MLA,
    UserRole.PA,
    UserRole.MANDAL_INCHARGE,
    UserRole.VILLAGE_COORDINATOR,
    UserRole.OFFICER,
  )
  remove(
    @Param("id") id: string,
    @Req() req: any,
  ) {
    return this.commentsService.remove(
      id,
      req.user,
    );
  }
}