import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { CreateCommentDto } from './dto/create-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';
import { GrievanceStatus, UserRole } from '@prisma/client';

@Injectable()
export class CommentsService {
  constructor(private readonly prisma: PrismaService) {}

  private checkAccess(grievance: any, user: any): boolean {
    if (!user) return false;

    switch (user.role) {
      case UserRole.ADMIN:
        return true;

      case UserRole.MLA:
      case UserRole.PA:
        return grievance.constituencyId === user.constituencyId;

      case UserRole.OFFICER:
        return grievance.assignedToId === user.userId;

      case UserRole.VILLAGE_COORDINATOR:
        return grievance.villageId === user.villageId;

      case UserRole.MANDAL_INCHARGE:
        return grievance.mandalId === user.mandalId;

      default:
        return false;
    }
  }

  private async getAccessibleGrievance(
    grievanceId: string,
    user: any,
  ) {
    const grievance = await this.prisma.grievance.findUnique({
      where: { id: grievanceId },
    });

    if (!grievance) {
      throw new NotFoundException('Grievance not found');
    }

    if (!this.checkAccess(grievance, user)) {
      throw new ForbiddenException(
        'You do not have access to this grievance',
      );
    }

    return grievance;
  }

  async create(
    createCommentDto: CreateCommentDto,
    user: any,
  ) {
    if (!user?.userId) {
      throw new ForbiddenException('User authentication required');
    }

    const grievance = await this.getAccessibleGrievance(
      createCommentDto.grievanceId,
      user,
    );

    // Resolved/Closed/Rejected grievances are view-only.
    if (
      grievance.status === GrievanceStatus.RESOLVED ||
      grievance.status === GrievanceStatus.CLOSED ||
      grievance.status === GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        'Comments cannot be added to a resolved, closed or rejected grievance',
      );
    }

    const message = createCommentDto.message?.trim();

    if (!message) {
      throw new BadRequestException('Comment message is required');
    }

    return this.prisma.comment.create({
      data: {
        grievanceId: grievance.id,
        userId: user.userId,
        message,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
      },
    });
  }

  async findAll(
    grievanceId: string,
    user: any,
  ) {
    if (!grievanceId) {
      throw new BadRequestException(
        'grievanceId is required',
      );
    }

    await this.getAccessibleGrievance(grievanceId, user);

    return this.prisma.comment.findMany({
      where: {
        grievanceId,
      },
      orderBy: [
        {
          createdAt: 'desc',
        },
        {
          id: 'desc',
        },
      ],
      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
      },
    });
  }

  async findOne(
    id: string,
    user: any,
  ) {
    const comment = await this.prisma.comment.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
        grievance: true,
      },
    });

    if (!comment) {
      throw new NotFoundException('Comment not found');
    }

    if (!this.checkAccess(comment.grievance, user)) {
      throw new ForbiddenException(
        'You do not have access to this comment',
      );
    }

    return comment;
  }

  async update(
    id: string,
    updateCommentDto: UpdateCommentDto,
    user: any,
  ) {
    const comment = await this.findOne(id, user);

    if (
      comment.grievance.status === GrievanceStatus.RESOLVED ||
      comment.grievance.status === GrievanceStatus.CLOSED ||
      comment.grievance.status === GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        'Comments cannot be edited for a resolved, closed or rejected grievance',
      );
    }

    const isOwner = comment.userId === user.userId;
    const isAdmin = user.role === UserRole.ADMIN;

    if (!isOwner && !isAdmin) {
      throw new ForbiddenException(
        'You can only edit your own comments',
      );
    }

    const message = updateCommentDto.message?.trim();

    if (!message) {
      throw new BadRequestException('Comment message is required');
    }

    return this.prisma.comment.update({
      where: { id },
      data: {
        message,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
      },
    });
  }

  async remove(
    id: string,
    user: any,
  ) {
    const comment = await this.findOne(id, user);

    if (
      comment.grievance.status === GrievanceStatus.RESOLVED ||
      comment.grievance.status === GrievanceStatus.CLOSED ||
      comment.grievance.status === GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        'Comments cannot be deleted for a resolved, closed or rejected grievance',
      );
    }

    const isOwner = comment.userId === user.userId;
    const isAdmin = user.role === UserRole.ADMIN;

    if (!isOwner && !isAdmin) {
      throw new ForbiddenException(
        'You can only delete your own comments',
      );
    }

    return this.prisma.comment.delete({
      where: { id },
    });
  }
}