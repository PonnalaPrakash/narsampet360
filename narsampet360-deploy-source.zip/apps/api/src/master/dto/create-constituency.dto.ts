import {
  IsNotEmpty,
  IsString,
  IsOptional,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';



export class MasterCreateConstituencyDto {


  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  name:string;



  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  district:string;



  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  state:string;



  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  mlaName?:string;


}