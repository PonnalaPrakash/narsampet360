import {
  IsNotEmpty,
  IsOptional,
  IsString,
  IsNumber,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';

import { Type } from 'class-transformer';


export class MasterCreateVillageDto {


  @ApiProperty({
    example: 'Mallampalli',
  })
  @IsString()
  @IsNotEmpty()
  name: string;


  @ApiProperty({
    example: 'mandal-uuid',
  })
  @IsString()
  @IsNotEmpty()
  mandalId: string;


  @ApiPropertyOptional({
    example: 5000,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  population?: number;


  @ApiPropertyOptional({
    example: 17.9876,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  latitude?: number;


  @ApiPropertyOptional({
    example: 79.1234,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  longitude?: number;

}