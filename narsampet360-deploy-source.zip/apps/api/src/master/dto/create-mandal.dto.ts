import {
  IsNotEmpty,
  IsString,
} from 'class-validator';

import {
  ApiProperty,
} from '@nestjs/swagger';


export class MasterCreateMandalDto {


  @ApiProperty({
    example: 'Narsampet Mandal',
  })
  @IsString()
  @IsNotEmpty()
  name: string;


  @ApiProperty({
    example: 'NSP001',
  })
  @IsString()
  @IsNotEmpty()
  code: string;


  @ApiProperty({
    example: 'constituency-uuid',
  })
  @IsString()
  @IsNotEmpty()
  constituencyId: string;

}