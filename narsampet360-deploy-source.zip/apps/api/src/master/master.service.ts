import { Injectable } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class MasterService {
  constructor(
    private prisma: PrismaService,
  ) {}

  // Constituencies

  async getConstituencies() {
    return this.prisma.constituency.findMany({
      orderBy: {
        name: 'asc',
      },
    });
  }

  async createConstituency(data: any) {
    return this.prisma.constituency.create({
      data: {
        name: data.name,
        district: data.district,
        state: data.state,
        mlaName: data.mlaName,
      },
    });
  }

  // Mandals

  async getMandals() {
    return this.prisma.mandal.findMany({
      include: {
        constituency: true,
      },
      orderBy: {
        name: 'asc',
      },
    });
  }

  async createMandal(data: any) {
    return this.prisma.mandal.create({
      data: {
        name: data.name,
        code: data.code,
        constituencyId: data.constituencyId,
      },
    });
  }

  // Villages

  async getVillages() {
    return this.prisma.village.findMany({
      include: {
        mandal: true,
      },
      orderBy: {
        name: 'asc',
      },
    });
  }

  async createVillage(data: any) {
    return this.prisma.village.create({
      data: {
        name: data.name,
        mandalId: data.mandalId,
        population: data.population,
        latitude: data.latitude,
        longitude: data.longitude,
      },
    });
  }
}