import {
  Body,
  Controller,
  Get,
  Post,
  UseGuards,
} from '@nestjs/common';

import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';

import { MasterService } from './master.service';

import { JwtAuthGuard } from '../auth/jwt-auth.guard';

import { RolesGuard } from '../common/guards/roles.guard';

import { Roles } from '../common/decorators/roles.decorator';

import { MasterCreateConstituencyDto } from './dto/create-constituency.dto';
import { MasterCreateMandalDto } from './dto/create-mandal.dto';
import { MasterCreateVillageDto } from './dto/create-village.dto';




@ApiTags('Master')
@Controller('master')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard, RolesGuard)
export class MasterController {


  constructor(
    private masterService: MasterService,
  ) {}




  // =========================
  // CONSTITUENCY
  // =========================


  @Get('constituencies')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )
  getConstituencies(){

    return this.masterService.getConstituencies();

  }





  @Post('constituency')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
  )
  createConstituency(
    @Body() dto: MasterCreateConstituencyDto,
  ){

    return this.masterService.createConstituency(dto);

  }





  // =========================
  // MANDAL
  // =========================


  @Get('mandals')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )
  getMandals(){

    return this.masterService.getMandals();

  }





  @Post('mandal')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
  )
  createMandal(
    @Body() dto: MasterCreateMandalDto,
  ){

    return this.masterService.createMandal(dto);

  }





  // =========================
  // VILLAGE
  // =========================


  @Get('villages')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )
  getVillages(){

    return this.masterService.getVillages();

  }





  @Post('village')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
  )
  createVillage(
    @Body() dto: MasterCreateVillageDto,
  ){

    return this.masterService.createVillage(dto);

  }


}
