import { Module } from '@nestjs/common';

import { DatabaseModule } from '../database/database.module';
import { MasterController } from './master.controller';
import { MasterService } from './master.service';

@Module({
  imports: [
    DatabaseModule,
  ],
  controllers: [
    MasterController,
  ],
  providers: [
    MasterService,
  ],
})
export class MasterModule {}