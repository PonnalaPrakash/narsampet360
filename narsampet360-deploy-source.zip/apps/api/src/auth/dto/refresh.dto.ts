import {
  IsNotEmpty,
  IsString,
} from 'class-validator';

import {
  ApiProperty,
} from '@nestjs/swagger';



export class RefreshDto {


  @ApiProperty({

    example:'550e8400-e29b-41d4-a716-446655440000',

    description:'Refresh token received after login',

  })

  @IsString()

  @IsNotEmpty({

    message:'Refresh token is required',

  })

  refreshToken:string;


}