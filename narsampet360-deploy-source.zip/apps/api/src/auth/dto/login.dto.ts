import {
  IsNotEmpty,
  IsString,
  Matches,
} from 'class-validator';

import {
  ApiProperty,
} from '@nestjs/swagger';



export class LoginDto {


  @ApiProperty({
    example: '8888888890',
    description: 'User mobile number',
  })
  @IsString()

  @IsNotEmpty({
    message:'Mobile number is required',
  })

  @Matches(/^[6-9]\d{9}$/, {
    message:'Invalid mobile number',
  })

  mobile:string;


}