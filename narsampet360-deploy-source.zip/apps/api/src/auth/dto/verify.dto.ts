import {
  IsNotEmpty,
  IsString,
  Matches,
} from 'class-validator';


import {
  ApiProperty,
} from '@nestjs/swagger';



export class VerifyDto {



  @ApiProperty({

    example:'8888888890',

    description:'User mobile number',

  })

  @IsString()

  @IsNotEmpty({

    message:'Mobile number is required',

  })

  @Matches(/^[6-9]\d{9}$/, {

    message:'Invalid mobile number',

  })

  mobile:string;






  @ApiProperty({

    example:'123456',

    description:'6 digit OTP',

  })

  @IsString()

  @IsNotEmpty({

    message:'OTP is required',

  })

  @Matches(/^\d{6}$/, {

    message:'OTP must be 6 digits',

  })

  otp:string;


}