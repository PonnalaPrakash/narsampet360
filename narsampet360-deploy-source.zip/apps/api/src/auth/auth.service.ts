import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ServiceUnavailableException,
} from '@nestjs/common';

import { JwtService } from '@nestjs/jwt';

import { PrismaService } from '../database/prisma.service';

import { randomInt, randomUUID } from 'crypto';

import { UserRole } from '@prisma/client';

@Injectable()
export class AuthService {

constructor(

 private prisma:PrismaService,

 private jwtService:JwtService,

){
  // Lightweight per-process abuse protection. For multi-instance deployments,
  // move these counters to Redis so limits are shared across instances.
}

private readonly otpSendAttempts = new Map<string, number[]>();
private readonly otpVerifyAttempts = new Map<string, number[]>();

private pruneAttempts(map: Map<string, number[]>, key: string, windowMs: number) {
  const now = Date.now();
  const kept = (map.get(key) ?? []).filter((ts) => now - ts < windowMs);
  map.set(key, kept);
  return kept;
}

private enforceRateLimit(
  map: Map<string, number[]>,
  key: string,
  limit: number,
  windowMs: number,
  message: string,
) {
  const attempts = this.pruneAttempts(map, key, windowMs);
  if (attempts.length >= limit) {
    throw new BadRequestException(message);
  }
  attempts.push(Date.now());
}

// SEND OTP

async sendOtp(
 mobile:string,
){
if(!/^\d{10}$/.test(mobile)){

 throw new BadRequestException(
  'Invalid mobile number'
 );

}

this.enforceRateLimit(
  this.otpSendAttempts,
  mobile,
  3,
  15 * 60 * 1000,
  'Too many OTP requests. Please try again later.',
);

const otp = randomInt(100000, 1000000).toString();

const msg91AuthKey = process.env.MSG91_AUTH_KEY;
const msg91OtpTemplateId = process.env.MSG91_OTP_TEMPLATE_ID;

if (process.env.NODE_ENV === 'production' && (!msg91AuthKey || !msg91OtpTemplateId)) {
  throw new ServiceUnavailableException('OTP delivery is not configured');
}

if (msg91AuthKey && msg91OtpTemplateId) {
  let response: Response;
  try {
    response = await fetch('https://control.msg91.com/api/v5/flow', {
      method: 'POST',
      headers: {
        accept: 'application/json',
        authkey: msg91AuthKey,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        template_id: msg91OtpTemplateId,
        recipients: [
          {
            mobiles: `91${mobile}`,
            VAR1: otp,
          },
        ],
      }),
      signal: AbortSignal.timeout(10000),
    });
  } catch {
    throw new ServiceUnavailableException('OTP delivery is temporarily unavailable');
  }

  const responseBody = await response.json().catch(() => null) as
    | { type?: string }
    | null;
  if (!response.ok || responseBody?.type?.toLowerCase() !== 'success') {
    throw new ServiceUnavailableException('OTP delivery is temporarily unavailable');
  }
}

await this.prisma.otpVerification.deleteMany({

 where:{
  mobile,
 },

});

await this.prisma.otpVerification.create({

 data:{

  mobile,
  otp,
  expiresAt:
  new Date(
   Date.now()+5*60*1000
  ),
 },

});

if (process.env.NODE_ENV !== 'production' && process.env.LOG_OTP === 'true') {
  console.log(`OTP ${mobile}: ${otp}`);
}

return {

 message:'OTP sent',

 expiresIn:300,

};

}

// VERIFY OTP

async verifyOtp(

 mobile:string,

 otp:string,

){

if(!/^\d{10}$/.test(mobile) || !/^\d{6}$/.test(otp)){
 throw new BadRequestException('Invalid OTP request');
}

this.enforceRateLimit(
  this.otpVerifyAttempts,
  mobile,
  10,
  15 * 60 * 1000,
  'Too many OTP verification attempts. Please try again later.',
);

const otpRecord =
await this.prisma.otpVerification.findFirst({

where:{

 mobile,

 verified:false,

},

});

if(!otpRecord){

 throw new UnauthorizedException(
 'Invalid OTP'
 );

}

if(
 otpRecord.expiresAt < new Date()
){

 throw new UnauthorizedException(
 'OTP expired'
 );

}

await this.prisma.otpVerification.update({

where:{
 id:otpRecord.id,
},

data:{
 verified:true,
},


});

let user =
await this.prisma.user.findUnique({

where:{
 mobile,
},

});

// First time user creation

if(!user){
user =
await this.prisma.user.create({

data:{

 name:
 `User-${mobile.slice(-4)}`,

 mobile,

 // default role
 // change later by ADMIN

 role:
 UserRole.VILLAGE_COORDINATOR,


},


});


}


const accessToken =
await this.jwtService.signAsync({

 sub:user.id,

 role:user.role,

});


const refreshToken =
randomUUID();

await this.prisma.refreshToken.create({

data:{


 token:refreshToken,
 userId:user.id,
 expiresAt:
 new Date(
 Date.now()
 +
 30*24*60*60*1000
 ),


},


});


await this.prisma.loginHistory.create({

data:{

 userId:user.id,

},

});

return {


accessToken,
refreshToken,
user:{
 id:user.id,
 name:user.name,
 mobile:user.mobile,
 role:user.role,
},

};

}

// REFRESH TOKEN


async refreshToken(
 token:string,
){
const storedToken =
await this.prisma.refreshToken.findFirst({

where:{
 token,
},


include:{
 user:true,
},


});

if(!storedToken){

throw new UnauthorizedException(
'Invalid refresh token'
);

}

if(
storedToken.expiresAt < new Date()
){

await this.prisma.refreshToken.delete({

where:{
 id:storedToken.id,
},

});

throw new UnauthorizedException(
'Refresh token expired'
);

}

const accessToken =
await this.jwtService.signAsync({

sub:
storedToken.user.id,
role:
storedToken.user.role,
});

// Rotate refresh tokens so a stolen refresh token cannot be reused indefinitely.
const nextRefreshToken = randomUUID();
await this.prisma.$transaction([
  this.prisma.refreshToken.delete({ where: { id: storedToken.id } }),
  this.prisma.refreshToken.create({
    data: {
      token: nextRefreshToken,
      userId: storedToken.user.id,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    },
  }),
]);

return {

accessToken,
refreshToken: nextRefreshToken,

};


}

// LOGOUT

async logout(
token:string,
){

await this.prisma.refreshToken.deleteMany({

where:{
 token,
},

});

return {

message:
'Logout successful',

};

}

}
