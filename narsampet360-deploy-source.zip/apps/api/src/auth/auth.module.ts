import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';

import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtStrategy } from './jwt.strategy';

import { DatabaseModule } from '../database/database.module';


@Module({

  imports: [

    DatabaseModule,

    PassportModule,

    JwtModule.registerAsync({

      useFactory: () => ({

        secret:
          process.env.JWT_ACCESS_SECRET,

        signOptions: {

          expiresIn:
            (process.env.JWT_ACCESS_EXPIRES || '15m') as any,

        },

      }),

    }),

  ],


  controllers: [

    AuthController,

  ],


  providers: [

    AuthService,

    JwtStrategy,

  ],


  exports: [

    JwtModule,

    AuthService,

  ],

})


export class AuthModule {}