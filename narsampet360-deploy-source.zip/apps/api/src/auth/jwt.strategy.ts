import {
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';

import {
  PassportStrategy,
} from '@nestjs/passport';

import {
  ExtractJwt,
  Strategy,
} from 'passport-jwt';

import {
  PrismaService,
} from '../database/prisma.service';


@Injectable()
export class JwtStrategy
  extends PassportStrategy(Strategy) {


  constructor(
    private readonly prisma: PrismaService,
  ) {

    super({

      jwtFromRequest:
        ExtractJwt.fromAuthHeaderAsBearerToken(),

      ignoreExpiration:
        false,

      secretOrKey:
        process.env.JWT_ACCESS_SECRET as string,

    });

  }



  async validate(payload:any){



 const user =
 await this.prisma.user.findUnique({

  where:{
   id: payload.sub,
  },

 });




 if(!user){

  throw new UnauthorizedException(
   "User not found"
  );

 }


 return {

  userId:user.id,

  role:user.role,

  constituencyId:user.constituencyId,

  mandalId:user.mandalId,

  villageId:user.villageId,

 };

}

}