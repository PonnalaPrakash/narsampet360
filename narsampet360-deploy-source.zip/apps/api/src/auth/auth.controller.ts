import {
  Controller,
  Post,
  Body,
} from '@nestjs/common';


import {
  ApiTags,
  ApiOperation,
  ApiBody,
} from '@nestjs/swagger';

import { AuthService } from './auth.service';

import { LoginDto } from './dto/login.dto';

import { VerifyDto } from './dto/verify.dto';

import { RefreshDto } from './dto/refresh.dto';

import { Public } from '../common/decorators/public.decorator';

@ApiTags('Auth')

@Controller('auth')

export class AuthController {

constructor(

 private readonly authService:AuthService,

){}

// SEND OTP

@Public()

@Post('send-otp')

@ApiOperation({

 summary:'Send OTP to mobile'

})

@ApiBody({

 type:LoginDto

})

sendOtp(

 @Body() dto:LoginDto,

){


return this.authService.sendOtp(

 dto.mobile

);

}

// VERIFY OTP

@Public()

@Post('verify-otp')

@ApiOperation({

 summary:'Verify OTP and login'

})

@ApiBody({

 type:VerifyDto

})

verifyOtp(

 @Body() dto:VerifyDto,

){


return this.authService.verifyOtp(

 dto.mobile,

 dto.otp,

);

}

// REFRESH TOKEN

@Public()

@Post('refresh')

@ApiOperation({

 summary:'Generate new access token'

})

@ApiBody({

 type:RefreshDto

})

refresh(

 @Body() dto:RefreshDto,

){


return this.authService.refreshToken(

 dto.refreshToken,

);
}

// LOGOUT

@Public()

@Post('logout')

@ApiOperation({

 summary:'Logout user and delete refresh token'

})

@ApiBody({

 type:RefreshDto

})

logout(

 @Body() dto:RefreshDto,

){

return this.authService.logout(

 dto.refreshToken,

);
}

}