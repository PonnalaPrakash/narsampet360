import {
  Injectable,
  CanActivate,
  ExecutionContext,
} from '@nestjs/common';

import { Reflector } from '@nestjs/core';
import { UserRole } from '@prisma/client';

import { ROLES_KEY } from './roles.decorator';


@Injectable()
export class RolesGuard implements CanActivate {

  constructor(
    private reflector: Reflector,
  ) {}


  canActivate(
    context: ExecutionContext,
  ): boolean {

    const roles =
      this.reflector.getAllAndOverride<UserRole[]>(
        ROLES_KEY,
        [
          context.getHandler(),
          context.getClass(),
        ],
      );


    if (!roles) {
      return true;
    }


    const request =
      context.switchToHttp().getRequest();


    if (!request.user) {
      return false;
    }


    return roles.includes(
      request.user.role,
    );
  }
}