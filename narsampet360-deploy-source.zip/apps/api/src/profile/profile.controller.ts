import {
  Controller,
  Get,
  Patch,
  Body,
  Req,
  UseGuards,
} from '@nestjs/common';

import { ApiBearerAuth } from '@nestjs/swagger';

import { JwtAuthGuard } from '../auth/jwt-auth.guard';

import { RolesGuard } from '../common/guards/roles.guard';

import { Roles } from '../common/decorators/roles.decorator';
import { ProfileService } from './profile.service';


@Controller('profile')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(
  'ADMIN',
  'MLA',
  'PA',
  'MANDAL_INCHARGE',
  'VILLAGE_COORDINATOR',
  'OFFICER',
)
export class ProfileController {

  constructor(private readonly profileService: ProfileService) {}


  @Get()
  getProfile(@Req() req: any) {
    return this.profileService.getProfile(req.user.userId || req.user.id || req.user.sub);
  }

  @Patch()
  updateProfile(@Req() req: any, @Body() body: any) {
    return this.profileService.updateProfile(
      req.user.userId || req.user.id || req.user.sub,
      body,
    );
  }

}