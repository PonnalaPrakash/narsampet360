import {
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import {
  PrismaService,
} from '../database/prisma.service';


@Injectable()
export class ProfileService {


  constructor(
    private readonly prisma:PrismaService,
  ) {}



  async getProfile(
    userId:string,
  ){


    const user =

      await this.prisma.user.findUnique({

        where:{
          id:userId,
        },


        include:{


          constituency:true,


          mandal:true,


          village:true,


          department:true,


        },


      });




    if(!user){

      throw new NotFoundException(
        'User not found',
      );

    }




    return user;


  }






  async updateProfile(

    userId:string,

    data:{
      name?:string;
      constituencyId?:string;
      mandalId?:string;
      villageId?:string;
      departmentId?:string;
    },

  ){



    const user =

      await this.prisma.user.findUnique({

        where:{
          id:userId,
        },

      });



    if(!user){

      throw new NotFoundException(
        'User not found',
      );

    }





    return this.prisma.user.update({

      where:{
        id:userId,
      },


      data:{


        name:
          data.name,


        constituencyId:
          data.constituencyId,


        mandalId:
          data.mandalId,


        villageId:
          data.villageId,


        departmentId:
          data.departmentId,


      },


      include:{


        constituency:true,


        mandal:true,


        village:true,


        department:true,


      },


    });


  }


}