export class Department {}
