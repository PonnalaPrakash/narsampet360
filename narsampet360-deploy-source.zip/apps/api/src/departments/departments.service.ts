import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';

import { PrismaService } from '../database/prisma.service';

import { CreateDepartmentDto } from './dto/create-department.dto';
import { UpdateDepartmentDto } from './dto/update-department.dto';


@Injectable()
export class DepartmentsService {

  constructor(
    private readonly prisma: PrismaService,
  ) {}


  async create(dto: CreateDepartmentDto) {

    const exists =
      await this.prisma.department.findFirst({
        where: {
          name: dto.name,
        },
      });


    if (exists) {
      throw new BadRequestException(
        'Department already exists',
      );
    }


    return this.prisma.department.create({
      data: {
        name: dto.name.trim(),
        description: dto.description,
      },
    });
  }



  async findAll() {

    return this.prisma.department.findMany({

      where: {
        isActive: true,
      },

      orderBy: {
        name: 'asc',
      },

    });
  }



  async findOne(id: string) {

    const department =
      await this.prisma.department.findFirst({

        where: {
          id,
          isActive: true,
        },

      });


    if (!department) {

      throw new NotFoundException(
        'Department not found',
      );

    }


    return department;
  }




  async update(
    id: string,
    dto: UpdateDepartmentDto,
  ) {


    await this.findOne(id);



    if (dto.name) {

      const exists =
        await this.prisma.department.findFirst({

          where: {

            name: dto.name,

            NOT: {
              id,
            },

          },

        });


      if (exists) {

        throw new BadRequestException(
          'Department already exists',
        );

      }
    }



    return this.prisma.department.update({

      where: {
        id,
      },

      data: dto,

    });

  }




  async remove(id: string) {

    await this.findOne(id);


    return this.prisma.department.update({

      where: {
        id,
      },

      data: {
        isActive: false,
      },

    });

  }

}