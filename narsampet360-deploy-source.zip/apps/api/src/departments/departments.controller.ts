import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';

import {
  ApiTags,
  ApiOperation,
  ApiResponse,
} from '@nestjs/swagger';

import { DepartmentsService } from './departments.service';

import { CreateDepartmentDto } from './dto/create-department.dto';
import { UpdateDepartmentDto } from './dto/update-department.dto';


@ApiTags('Departments')
@Controller('departments')
export class DepartmentsController {

  constructor(
    private readonly departmentsService: DepartmentsService,
  ) {}


  @Post()
  @ApiOperation({
    summary: 'Create new department',
  })
  @ApiResponse({
    status: 201,
    description: 'Department created successfully',
  })
  create(
    @Body() createDepartmentDto: CreateDepartmentDto,
  ) {
    return this.departmentsService.create(
      createDepartmentDto,
    );
  }


  @Get()
  @ApiOperation({
    summary: 'Get all active departments',
  })
  @ApiResponse({
    status: 200,
    description: 'Departments fetched successfully',
  })
  findAll() {
    return this.departmentsService.findAll();
  }


  @Get(':id')
  @ApiOperation({
    summary: 'Get department by id',
  })
  findOne(
    @Param('id') id: string,
  ) {
    return this.departmentsService.findOne(id);
  }


  @Patch(':id')
  @ApiOperation({
    summary: 'Update department',
  })
  update(
    @Param('id') id: string,
    @Body() updateDepartmentDto: UpdateDepartmentDto,
  ) {
    return this.departmentsService.update(
      id,
      updateDepartmentDto,
    );
  }


  @Delete(':id')
  @ApiOperation({
    summary: 'Deactivate department',
  })
  @ApiResponse({
    status: 200,
    description: 'Department deactivated successfully',
  })
  remove(
    @Param('id') id: string,
  ) {
    return this.departmentsService.remove(id);
  }

}