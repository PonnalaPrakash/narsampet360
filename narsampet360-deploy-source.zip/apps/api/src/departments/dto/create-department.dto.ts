import {
  IsString,
  IsNotEmpty,
  IsOptional,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';

export class CreateDepartmentDto {

  @ApiProperty({
    example: 'Water Supply',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({
    example: 'Water related grievances',
  })
  @IsOptional()
  @IsString()
  description?: string;

}