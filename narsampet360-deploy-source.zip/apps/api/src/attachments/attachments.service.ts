
import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { createReadStream } from 'fs';
import { randomUUID } from 'crypto';
import { access, unlink } from 'fs/promises';
import { basename, resolve } from 'path';

import {
  GrievanceStatus,
  UserRole,
} from '@prisma/client';

import { PrismaService } from '../database/prisma.service';

import { CreateAttachmentDto } from './dto/create-attachment.dto';
import { UpdateAttachmentDto } from './dto/update-attachment.dto';

@Injectable()
export class AttachmentsService {
  constructor(
    private readonly prisma: PrismaService,
  ) {}

  /**
   * Check whether the logged-in user can access
   * the grievance.
   */
  private checkGrievanceAccess(
    grievance: any,
    user: any,
  ): boolean {
    if (!user?.userId || !user?.role) {
      return false;
    }

    switch (user.role) {
      case UserRole.ADMIN:
        return true;

      case UserRole.MLA:
      case UserRole.PA:
        return (
          !!user.constituencyId &&
          grievance.constituencyId ===
            user.constituencyId
        );

      case UserRole.OFFICER:
        return (
          grievance.assignedToId ===
          user.userId
        );

      case UserRole.VILLAGE_COORDINATOR:
        return (
          !!user.villageId &&
          grievance.villageId ===
            user.villageId
        );

      case UserRole.MANDAL_INCHARGE:
        return (
          !!user.mandalId &&
          grievance.mandalId ===
            user.mandalId
        );

      default:
        return false;
    }
  }

  /**
   * Check whether attachment operations
   * are locked because grievance is completed.
   */
  private checkAttachmentLock(
    status: GrievanceStatus,
  ) {
    if (
      status === GrievanceStatus.RESOLVED ||
      status === GrievanceStatus.CLOSED ||
      status === GrievanceStatus.REJECTED
    ) {
      throw new BadRequestException(
        'Attachments are locked after the grievance is resolved.',
      );
    }
  }

  /**
   * Upload a physical file.
   *
   * uploadedById is ALWAYS taken from the
   * authenticated user. Client cannot choose it.
   */
  async upload(
    file: Express.Multer.File,
    grievanceId: string,
    user: any,
  ) {
    if (!file) {
      throw new NotFoundException(
        'File not uploaded',
      );
    }

    if (!user?.userId) {
      throw new ForbiddenException(
        'Invalid user',
      );
    }

    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id: grievanceId,
        },
        select: {
          id: true,
          status: true,
          constituencyId: true,
          mandalId: true,
          villageId: true,
          assignedToId: true,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        'Grievance not found',
      );
    }

    if (
      !this.checkGrievanceAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        'You cannot upload attachment to this grievance',
      );
    }

    this.checkAttachmentLock(
      grievance.status,
    );

    const attachmentId = randomUUID();

    try {
      return await this.prisma.attachment.create({
        data: {
          id: attachmentId,
          grievanceId: grievance.id,
          fileName: file.originalname.replace(/[\\/\0]/g, '_'),
          //fileUrl: `/attachments/${attachmentId}/file`,
          fileUrl: file.filename,
          fileType: file.mimetype,
          fileSize: file.size,
          uploadedById: user.userId,
        },
      });
    } catch (error) {
      await unlink(file.path).catch(() => undefined);
      throw error;
    }
  }

  /**
   * Direct attachment record creation.
   *
   * This endpoint is ADMIN-only.
   */
  async create(
    createAttachmentDto: CreateAttachmentDto,
    user: any,
  ) {
    if (user?.role !== UserRole.ADMIN) {
      throw new ForbiddenException(
        'Only ADMIN can create attachment records',
      );
    }

    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id:
            createAttachmentDto.grievanceId,
        },
        select: {
          id: true,
          status: true,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        'Grievance not found',
      );
    }

    this.checkAttachmentLock(
      grievance.status,
    );

    return this.prisma.attachment.create({
      data: {
        id: randomUUID(),

        grievanceId:
          createAttachmentDto.grievanceId,

        fileName:
          createAttachmentDto.fileName,

        fileUrl:
          createAttachmentDto.fileUrl,

        fileType:
          createAttachmentDto.fileType,

        fileSize:
          createAttachmentDto.fileSize,

        uploadedById:
          user.userId,
      },
    });
  }

  /**
   * Get all attachments.
   *
   * ADMIN only.
   */
  async findAll(user: any) {
    if (user?.role !== UserRole.ADMIN) {
      throw new ForbiddenException(
        'Only ADMIN can view all attachments',
      );
    }

    return this.prisma.attachment.findMany({
      orderBy: {
        createdAt: 'desc',
      },

      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },

        grievance: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });
  }

  /**
   * Get attachments belonging to one grievance.
   *
   * User must have access to that grievance.
   */
  async findByGrievance(
    grievanceId: string,
    user: any,
  ) {
    const grievance =
      await this.prisma.grievance.findUnique({
        where: {
          id: grievanceId,
        },
        select: {
          id: true,
          constituencyId: true,
          mandalId: true,
          villageId: true,
          assignedToId: true,
        },
      });

    if (!grievance) {
      throw new NotFoundException(
        'Grievance not found',
      );
    }

    if (
      !this.checkGrievanceAccess(
        grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        'You cannot view attachments for this grievance',
      );
    }

    return this.prisma.attachment.findMany({
      where: {
        grievanceId,
      },

      orderBy: {
        createdAt: 'desc',
      },

      include: {
        user: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
      },
    });
  }

  /**
   * Get one attachment.
   *
   * Access is checked through its grievance.
   */
  async findOne(
    id: string,
    user: any,
  ) {
    const attachment =
      await this.prisma.attachment.findUnique({
        where: {
          id,
        },

        include: {
          grievance: {
            select: {
              id: true,
              constituencyId: true,
              mandalId: true,
              villageId: true,
              assignedToId: true,
            },
          },
        },
      });

    if (!attachment) {
      throw new NotFoundException(
        'Attachment not found',
      );
    }

    if (
      !this.checkGrievanceAccess(
        attachment.grievance,
        user,
      )
    ) {
      throw new ForbiddenException(
        'You cannot view this attachment',
      );
    }

    return attachment;
  }

  /**
   * Get the physical attachment stream after authorization.
   */
  async getFile(id: string, user: any) {
    const attachment = await this.prisma.attachment.findUnique({
      where: { id },
      select: {
        fileName: true, fileUrl: true, fileType: true, fileSize: true,
        grievance: { select: { id: true, constituencyId: true, mandalId: true, villageId: true, assignedToId: true } },
      },
    });
    if (!attachment) throw new NotFoundException('Attachment not found');
    if (!this.checkGrievanceAccess(attachment.grievance, user)) {
      throw new ForbiddenException('You cannot download this attachment');
    }
    const uploadRoot = resolve(process.cwd(), 'uploads', 'grievance-files');
    const storedName = basename(attachment.fileUrl || '');
    const filePath = resolve(uploadRoot, storedName);
    if (!storedName || !filePath.startsWith(`${uploadRoot}/`)) {
      throw new NotFoundException('Attachment file not available');
    }
    try { await access(filePath); } catch { throw new NotFoundException('Attachment file not available'); }
    return { stream: createReadStream(filePath), contentType: attachment.fileType || 'application/octet-stream', fileName: attachment.fileName, fileSize: attachment.fileSize };
  }

  /**
   * Update attachment metadata.
   *
   * ADMIN only.
   *
   * grievanceId, uploadedById and fileUrl
   * cannot be changed.
   */
  async update(
    id: string,
    updateAttachmentDto: UpdateAttachmentDto,
    user: any,
  ) {
    if (user?.role !== UserRole.ADMIN) {
      throw new ForbiddenException(
        'Only ADMIN can update attachments',
      );
    }

    const attachment =
      await this.prisma.attachment.findUnique({
        where: {
          id,
        },

        include: {
          grievance: {
            select: {
              status: true,
            },
          },
        },
      });

    if (!attachment) {
      throw new NotFoundException(
        'Attachment not found',
      );
    }

    this.checkAttachmentLock(
      attachment.grievance.status,
    );

    return this.prisma.attachment.update({
      where: {
        id,
      },

      data: {
        ...(updateAttachmentDto.fileName !==
        undefined
          ? {
              fileName:
                updateAttachmentDto.fileName,
            }
          : {}),

        ...(updateAttachmentDto.fileType !==
        undefined
          ? {
              fileType:
                updateAttachmentDto.fileType,
            }
          : {}),

        ...(updateAttachmentDto.fileSize !==
        undefined
          ? {
              fileSize:
                updateAttachmentDto.fileSize,
            }
          : {}),
      },
    });
  }

  /**
   * Delete attachment.
   *
   * ADMIN only.
   */
  async remove(
    id: string,
    user: any,
  ) {
    if (user?.role !== UserRole.ADMIN) {
      throw new ForbiddenException(
        'Only ADMIN can delete attachments',
      );
    }

    const attachment =
      await this.prisma.attachment.findUnique({
        where: {
          id,
        },

        select: {
          id: true,

          grievance: {
            select: {
              status: true,
            },
          },
        },
      });

    if (!attachment) {
      throw new NotFoundException(
        'Attachment not found',
      );
    }

    this.checkAttachmentLock(
      attachment.grievance.status,
    );

    return this.prisma.attachment.delete({
      where: {
        id,
      },
    });
  }
}
