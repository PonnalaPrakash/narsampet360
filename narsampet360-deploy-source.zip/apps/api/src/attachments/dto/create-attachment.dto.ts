
import {
  IsInt,
  IsOptional,
  IsString,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';

export class CreateAttachmentDto {
  @ApiProperty({
    example: 'uuid-grievance-id',
    description: 'Grievance id',
  })
  @IsString()
  grievanceId: string;

  @ApiProperty({
    example: 'document.pdf',
    description: 'Uploaded file name',
  })
  @IsString()
  fileName: string;

  @ApiProperty({
    example: '/uploads/grievance-files/document.pdf',
    description: 'File URL path',
  })
  @IsString()
  fileUrl: string;

  @ApiPropertyOptional({
    example: 'application/pdf',
  })
  @IsOptional()
  @IsString()
  fileType?: string;

  @ApiPropertyOptional({
    example: 102400,
  })
  @IsOptional()
  @IsInt()
  fileSize?: number;
}
