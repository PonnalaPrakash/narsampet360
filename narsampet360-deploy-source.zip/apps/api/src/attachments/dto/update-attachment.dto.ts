
import {
  IsInt,
  IsOptional,
  IsString,
} from 'class-validator';

import {
  ApiPropertyOptional,
} from '@nestjs/swagger';

export class UpdateAttachmentDto {
  @ApiPropertyOptional({
    example: 'Updated document.pdf',
  })
  @IsOptional()
  @IsString()
  fileName?: string;

  @ApiPropertyOptional({
    example: 'application/pdf',
  })
  @IsOptional()
  @IsString()
  fileType?: string;

  @ApiPropertyOptional({
    example: 102400,
  })
  @IsOptional()
  @IsInt()
  fileSize?: number;
}
