
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
  UploadedFile,
  StreamableFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';

import {
  FileInterceptor,
} from '@nestjs/platform-express';

import {
  diskStorage,
} from 'multer';

import { extname } from 'path';
import { randomUUID } from 'crypto';

import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';

import { AttachmentsService } from './attachments.service';

import { CreateAttachmentDto } from './dto/create-attachment.dto';

import { UpdateAttachmentDto } from './dto/update-attachment.dto';

import { JwtAuthGuard } from '../auth/jwt-auth.guard';

import { RolesGuard } from '../common/guards/roles.guard';


@ApiTags('Attachments')
@ApiBearerAuth('access-token')
@Controller('attachments')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class AttachmentsController {

  constructor(
    private readonly attachmentsService: AttachmentsService,
  ) {}


  /**
   * Upload attachment file
   */
  @Post('upload')
  @UseInterceptors(
    FileInterceptor(
      'file',
      {
        storage: diskStorage({
          destination:
            './uploads/grievance-files',

          filename:
            (req, file, cb) => {
              cb(
                null,
                `${randomUUID()}${extname(file.originalname).toLowerCase()}`,
              );
            },
        }),

        fileFilter: (req, file, cb) => {
          const allowedTypes = new Set([
            'image/jpeg',
            'image/png',
            'image/webp',
            'application/pdf',
            'text/plain',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          ]);

          if (!allowedTypes.has(file.mimetype)) {
            return cb(
              new Error('Unsupported file type. Allowed: JPG, PNG, WEBP, PDF, TXT, DOC, DOCX, XLS, XLSX.'),
              false,
            );
          }

          cb(null, true);
        },

        limits: {
          fileSize: 5 * 1024 * 1024,
        },
      },
    ),
  )
  @ApiConsumes(
    'multipart/form-data',
  )
  @ApiBody({
    schema: {
      type: 'object',

      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },

        grievanceId: {
          type: 'string',
        },
      },
    },
  })
  @ApiOperation({
    summary:
      'Upload attachment file',
  })
  upload(
    @UploadedFile()
    file: Express.Multer.File,

    @Body()
    body: {
      grievanceId: string;
    },

    @Req()
    req: any,
  ) {
    return this.attachmentsService.upload(
      file,
      body.grievanceId,
      req.user,
    );
  }


  /**
   * Direct attachment record creation
   *
   * Service allows ADMIN only.
   */
  @Post()
  @ApiOperation({
    summary:
      'Create attachment record',
  })
  create(
    @Body()
    createAttachmentDto:
      CreateAttachmentDto,

    @Req()
    req: any,
  ) {
    return this.attachmentsService.create(
      createAttachmentDto,
      req.user,
    );
  }


  /**
   * Get all attachments
   *
   * Service allows ADMIN only.
   */
  @Get()
  @ApiOperation({
    summary:
      'Get all attachments',
  })
  findAll(
    @Req()
    req: any,
  ) {
    return this.attachmentsService.findAll(
      req.user,
    );
  }


  /**
   * Get attachments for one grievance
   *
   * Access is checked against
   * the logged-in user's scope.
   */
  @Get('grievance/:grievanceId')
  @ApiOperation({
    summary:
      'Get attachments for a grievance',
  })
  findByGrievance(
    @Param('grievanceId')
    grievanceId: string,

    @Req()
    req: any,
  ) {
    return this.attachmentsService.findByGrievance(
      grievanceId,
      req.user,
    );
  }


  /**
   * Get one attachment
   *
   * Access is checked against
   * the parent grievance.
   */
  @Get(':id/file')
  @ApiOperation({ summary: 'Download attachment file' })
  async download(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<StreamableFile> {
    const result = await this.attachmentsService.getFile(id, req.user);
    return new StreamableFile(result.stream, {
      type: result.contentType,
      disposition: `attachment; filename=\"${result.fileName.replace(/[\\\"\r\n]/g, '_')}\"`,
      length: result.fileSize ?? undefined,
    });
  }

  @Get(':id')
  @ApiOperation({
    summary:
      'Get attachment by id',
  })
  findOne(
    @Param('id')
    id: string,

    @Req()
    req: any,
  ) {
    return this.attachmentsService.findOne(
      id,
      req.user,
    );
  }


  /**
   * Update attachment metadata
   *
   * Service allows ADMIN only.
   */
  @Patch(':id')
  @ApiOperation({
    summary:
      'Update attachment',
  })
  update(
    @Param('id')
    id: string,

    @Body()
    updateAttachmentDto:
      UpdateAttachmentDto,

    @Req()
    req: any,
  ) {
    return this.attachmentsService.update(
      id,
      updateAttachmentDto,
      req.user,
    );
  }


  /**
   * Delete attachment
   *
   * Service allows ADMIN only.
   */
  @Delete(':id')
  @ApiOperation({
    summary:
      'Delete attachment',
  })
  remove(
    @Param('id')
    id: string,

    @Req()
    req: any,
  ) {
    return this.attachmentsService.remove(
      id,
      req.user,
    );
  }
}
