import {
  Injectable,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';

import {
  PrismaService,
} from '../database/prisma.service';

import {
  CreateMandalDto,
} from './dto/create-mandal.dto';

import {
  UpdateMandalDto,
} from './dto/update-mandal.dto';

@Injectable()
export class MandalsService {
  constructor(
    private readonly prisma: PrismaService,
  ) {}

  async create(
    createMandalDto: CreateMandalDto,
  ) {

    const existingMandal =
      await this.prisma.mandal.findUnique({

        where: {
          code: createMandalDto.code,
        },

      });
    if (existingMandal) {

      throw new ConflictException(
        'Mandal code already exists',
      );

    }
    return this.prisma.mandal.create({

      data: {

        name:
          createMandalDto.name,

        code:
          createMandalDto.code,

        constituencyId:
          createMandalDto.constituencyId,

        // Newly created Mandal should be Active
        isActive: true,

      },
    });


  }
  async findAll() {


    return this.prisma.mandal.findMany({

      include: {

        constituency: true,

        villages: true,

      },

      orderBy: {

        createdAt: 'desc',

      },

    });


  }
  async findOne(
    id: string,
  ) {


    const mandal =
      await this.prisma.mandal.findUnique({

        where: {
          id,
        },


        include: {

          constituency: true,

          villages: true,

          grievances: true,

        },

      });


    if (!mandal) {

      throw new NotFoundException(
        'Mandal not found',
      );

    }

    return mandal;
  }
  async update(
    id: string,
    updateMandalDto: UpdateMandalDto,
  ) {
    await this.findOne(id);
    return this.prisma.mandal.update({

      where: {
        id,
      },


      data: {


        name:
          updateMandalDto.name,

        code:
          updateMandalDto.code,
        constituencyId:
          updateMandalDto.constituencyId,


      },

    });


  }


  async remove(
    id: string,
  ) {


    await this.findOne(id);
  return this.prisma.mandal.delete({

      where: {
        id,
      },

    });


  }


}