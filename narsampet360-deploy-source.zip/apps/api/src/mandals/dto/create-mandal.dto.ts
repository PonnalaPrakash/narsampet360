import {
  IsString,
} from 'class-validator';
import {
  ApiProperty,
} from '@nestjs/swagger';
export class CreateMandalDto {
  @ApiProperty({
    example: 'Narsampet Mandal',
  })
  @IsString()
  name: string;
  @ApiProperty({
    example: 'NAR-MAN-001',
  })
  @IsString()
  code: string;

  @ApiProperty({
    example: 'e63f3f62-06e0-416a-a1c7-f4b2719bdfef',
  })
  @IsString()
  constituencyId: string;
}