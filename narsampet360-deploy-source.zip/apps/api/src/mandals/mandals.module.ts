import { Module } from '@nestjs/common';

import { MandalsService } from './mandals.service';
import { MandalsController } from './mandals.controller';

import { DatabaseModule } from '../database/database.module';


@Module({

  imports: [
    DatabaseModule,
  ],

  controllers: [
    MandalsController,
  ],

  providers: [
    MandalsService,
  ],

  exports: [
    MandalsService,
  ],

})
export class MandalsModule {}