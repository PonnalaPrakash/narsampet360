export class Mandal {}
