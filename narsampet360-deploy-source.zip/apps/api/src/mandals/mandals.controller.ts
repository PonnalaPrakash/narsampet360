import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
} from '@nestjs/common';


import {
  ApiBearerAuth,
  ApiTags,
} from '@nestjs/swagger';


import { MandalsService } from './mandals.service';

import { CreateMandalDto } from './dto/create-mandal.dto';

import { UpdateMandalDto } from './dto/update-mandal.dto';


import { JwtAuthGuard } from '../auth/jwt-auth.guard';

import { RolesGuard } from '../common/guards/roles.guard';

import { Roles } from '../common/decorators/roles.decorator';



@ApiTags('Mandals')

//@ApiBearerAuth('access-token')

@Controller('mandals')

@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)

export class MandalsController {


  constructor(
    private readonly mandalsService: MandalsService,
  ) {}



  @Post()
@ApiBearerAuth('access-token')
  @Roles(
    'ADMIN',
    'MLA',
  )

  create(
    @Body()
    createMandalDto: CreateMandalDto,
  ) {

    return this.mandalsService.create(
      createMandalDto,
    );

  }



  @Get()
@ApiBearerAuth('access-token')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )

  findAll() {

    return this.mandalsService.findAll();

  }



  @Get(':id')
@ApiBearerAuth('access-token')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
  )

  findOne(
    @Param('id')
    id:string,
  ) {

    return this.mandalsService.findOne(
      id,
    );

  }



  @Patch(':id')
@ApiBearerAuth('access-token')
  @Roles(
    'ADMIN',
    'MLA',
  )

  update(
    @Param('id')
    id:string,

    @Body()
    updateMandalDto:UpdateMandalDto,

  ) {

    return this.mandalsService.update(
      id,
      updateMandalDto,
    );

  }



  @Delete(':id')
@ApiBearerAuth('access-token')
  @Roles(
    'ADMIN',
  )

  remove(
    @Param('id')
    id:string,
  ) {

    return this.mandalsService.remove(
      id,
    );

  }


}