import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { PrismaService } from '../database/prisma.service';
import { Public } from '../common/decorators/public.decorator';


@ApiTags('Health')
@Controller('health')
export class HealthController {

  constructor(
    private prisma: PrismaService,
  ) {}


  @Public()
  @Get()
  async check() {

    await this.prisma.$queryRaw`SELECT 1`;

    return {
      status: 'OK',
      database: 'connected',
    };
  }
}