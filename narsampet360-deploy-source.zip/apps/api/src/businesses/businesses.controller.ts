import { Controller, Get, Query } from '@nestjs/common';
import { BusinessesService } from './businesses.service';

@Controller('businesses')
export class BusinessesController {
  constructor(private readonly businessesService: BusinessesService) {}

  @Get()
  findAll(@Query('search') search?: string) {
    return this.businessesService.findAll(search);
  }
}
