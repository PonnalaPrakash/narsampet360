import {
  Injectable,
  ConflictException,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';

import {
  PrismaService,
} from '../database/prisma.service';

import {
  CreateUserDto,
} from './dto/create-user.dto';

import {
  UpdateUserDto,
} from './dto/update-user.dto';

import {
  Prisma,
  UserRole,
} from '@prisma/client';

import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
  ) {}

  private async validateLocationAssignment(data: {
    role: UserRole;
    constituencyId?: string;
    mandalId?: string;
    villageId?: string;
    departmentId?: string;
  }) {
    const { role, constituencyId, mandalId, villageId, departmentId } = data;

    const requiresConstituency = ['MLA', 'PA', 'MANDAL_INCHARGE', 'VILLAGE_COORDINATOR'].includes(role);
    const requiresMandal = ['MANDAL_INCHARGE', 'VILLAGE_COORDINATOR'].includes(role);
    const requiresVillage = role === 'VILLAGE_COORDINATOR';
    const requiresDepartment = role === 'OFFICER';

    if (requiresConstituency && !constituencyId) {
      throw new BadRequestException('Constituency is required for this role');
    }
    if (requiresMandal && !mandalId) {
      throw new BadRequestException('Mandal is required for this role');
    }
    if (requiresVillage && !villageId) {
      throw new BadRequestException('Village is required for Village Coordinator');
    }
    if (requiresDepartment && !departmentId) {
      throw new BadRequestException('Department is required for Officer');
    }

    if (constituencyId) {
      const constituency = await this.prisma.constituency.findUnique({ where: { id: constituencyId } });
      if (!constituency) throw new BadRequestException('Invalid constituency');
    }

    if (mandalId) {
      const mandal = await this.prisma.mandal.findUnique({ where: { id: mandalId } });
      if (!mandal) throw new BadRequestException('Invalid mandal');
      if (constituencyId && mandal.constituencyId !== constituencyId) {
        throw new BadRequestException('Selected mandal does not belong to selected constituency');
      }
    }

    if (villageId) {
      const village = await this.prisma.village.findUnique({ where: { id: villageId } });
      if (!village) throw new BadRequestException('Invalid village');
      if (mandalId && village.mandalId !== mandalId) {
        throw new BadRequestException('Selected village does not belong to selected mandal');
      }
    }

    if (departmentId) {
      const department = await this.prisma.department.findUnique({ where: { id: departmentId } });
      if (!department) throw new BadRequestException('Invalid department');
    }
  }

  // ============================================================
  // CREATE USER
  // ============================================================

  async create(createUserDto: CreateUserDto) {
    const existingUser =
      await this.prisma.user.findUnique({
        where: {
          mobile: createUserDto.mobile,
        },
      });

    if (existingUser) {
      throw new ConflictException(
        'Mobile already exists',
      );
    }

    await this.validateLocationAssignment({
      role: createUserDto.role,
      constituencyId: createUserDto.constituencyId,
      mandalId: createUserDto.mandalId,
      villageId: createUserDto.villageId,
      departmentId: createUserDto.departmentId,
    });

    const hashedPassword =
      createUserDto.password
        ? await bcrypt.hash(
            createUserDto.password,
            10,
          )
        : null;

    const userData =
      createUserDto as CreateUserDto & {
        isActive?: boolean;
      };

    return this.prisma.user.create({
      data: {
        name: createUserDto.name,
        mobile: createUserDto.mobile,
        email: createUserDto.email ?? null,
        password: hashedPassword,
        role: createUserDto.role,
        constituencyId:
          createUserDto.constituencyId ?? null,
        mandalId:
          createUserDto.mandalId ?? null,
        villageId:
          createUserDto.villageId ?? null,
        departmentId:
          createUserDto.departmentId ?? null,
        isActive: userData.isActive ?? true,
      },
      select: {
        id: true,
        name: true,
        mobile: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
        constituency: { select: { id: true, name: true } },
        mandal: { select: { id: true, name: true } },
        village: { select: { id: true, name: true } },
        department: { select: { id: true, name: true } },
      },
    });
  }

  // ============================================================
  // GET USERS
  // ============================================================

  async findAll(params: {
    page: number;
    limit: number;
    search?: string;
    role?: UserRole;
    status?: string;
  }) {
    const {
      page,
      limit,
      search,
      role,
      status,
    } = params;

    const skip =
      Math.max(page - 1, 0) * limit;

    const normalizedStatus =
      String(status || 'ACTIVE').toUpperCase();

    const where: Prisma.UserWhereInput = {};

    if (normalizedStatus === 'ACTIVE') {
      where.isActive = true;
    }

    if (normalizedStatus === 'INACTIVE') {
      where.isActive = false;
    }

    if (search) {
      where.OR = [
        {
          name: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          mobile: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          email: {
            contains: search,
            mode: 'insensitive',
          },
        },
      ];
    }

    if (role) {
      where.role = role;
    }

    const [data, total] =
      await Promise.all([
        this.prisma.user.findMany({
          where,
          skip,
          take: limit,
          select: {
            id: true,
            name: true,
            mobile: true,
            email: true,
            role: true,
            isActive: true,
            createdAt: true,
            updatedAt: true,
            constituency: {
              select: {
                id: true,
                name: true,
              },
            },
            mandal: {
              select: {
                id: true,
                name: true,
              },
            },
            village: {
              select: {
                id: true,
                name: true,
              },
            },
            department: {
              select: {
                id: true,
                name: true,
                description: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        }),
        this.prisma.user.count({
          where,
        }),
      ]);

    return {
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages:
          Math.ceil(total / limit),
      },
    };
  }

  // ============================================================
  // GET SINGLE USER
  // ============================================================

  async findOne(id: string) {
    const user =
      await this.prisma.user.findUnique({
        where: {
          id,
        },
        select: {
          id: true,
          name: true,
          mobile: true,
          email: true,
          role: true,
          isActive: true,
          createdAt: true,
          updatedAt: true,
          constituency: {
            select: {
              id: true,
              name: true,
            },
          },
          mandal: {
            select: {
              id: true,
              name: true,
            },
          },
          village: {
            select: {
              id: true,
              name: true,
            },
          },
          department: {
            select: {
              id: true,
              name: true,
              description: true,
            },
          },
        },
      });

    if (!user) {
      throw new NotFoundException(
        'User not found',
      );
    }

    return user;
  }

  // ============================================================
  // UPDATE USER
  // ============================================================

  async update(
    id: string,
    updateUserDto: UpdateUserDto,
  ) {
    const user =
      await this.prisma.user.findUnique({
        where: {
          id,
        },
      });

    if (!user) {
      throw new NotFoundException(
        'User not found',
      );
    }

    await this.validateLocationAssignment({
      role: updateUserDto.role ?? user.role,
      constituencyId: updateUserDto.constituencyId !== undefined ? updateUserDto.constituencyId : user.constituencyId ?? undefined,
      mandalId: updateUserDto.mandalId !== undefined ? updateUserDto.mandalId : user.mandalId ?? undefined,
      villageId: updateUserDto.villageId !== undefined ? updateUserDto.villageId : user.villageId ?? undefined,
      departmentId: updateUserDto.departmentId !== undefined ? updateUserDto.departmentId : user.departmentId ?? undefined,
    });

    const data: Prisma.UserUpdateInput = {};

    if (updateUserDto.name) {
      data.name =
        updateUserDto.name;
    }

    if (updateUserDto.mobile) {
      data.mobile =
        updateUserDto.mobile;
    }

    if (
      updateUserDto.email !==
      undefined
    ) {
      data.email =
        updateUserDto.email;
    }

    if (updateUserDto.role) {
      data.role =
        updateUserDto.role;
    }

    const updateData =
      updateUserDto as UpdateUserDto & {
        isActive?: boolean;
      };

    if (
      updateData.isActive !==
      undefined
    ) {
      data.isActive =
        updateData.isActive;
    }

    if (updateUserDto.password) {
      data.password =
        await bcrypt.hash(
          updateUserDto.password,
          10,
        );
    }

    if (
      updateUserDto.constituencyId !==
      undefined
    ) {
      data.constituency = updateUserDto.constituencyId
        ? { connect: { id: updateUserDto.constituencyId } }
        : { disconnect: true };
    }

    if (
      updateUserDto.mandalId !==
      undefined
    ) {
      data.mandal = updateUserDto.mandalId
        ? { connect: { id: updateUserDto.mandalId } }
        : { disconnect: true };
    }

    if (
      updateUserDto.villageId !==
      undefined
    ) {
      data.village = updateUserDto.villageId
        ? { connect: { id: updateUserDto.villageId } }
        : { disconnect: true };
    }

    if (
      updateUserDto.departmentId !==
      undefined
    ) {
      data.department = updateUserDto.departmentId
        ? { connect: { id: updateUserDto.departmentId } }
        : { disconnect: true };
    }

    return this.prisma.user.update({
      where: {
        id,
      },
      data,
      select: {
        id: true,
        name: true,
        mobile: true,
        email: true,
        role: true,
        isActive: true,
        updatedAt: true,
        constituency: {
          select: {
            id: true,
            name: true,
          },
        },
        mandal: {
          select: {
            id: true,
            name: true,
          },
        },
        village: {
          select: {
            id: true,
            name: true,
          },
        },
        department: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
  }

  // ============================================================
  // ACTIVATE / DEACTIVATE USER
  // ============================================================

  async setActiveStatus(
    id: string,
    isActive: boolean,
  ) {
    const user =
      await this.prisma.user.findUnique({
        where: {
          id,
        },
      });

    if (!user) {
      throw new NotFoundException(
        'User not found',
      );
    }

    return this.prisma.user.update({
      where: {
        id,
      },
      data: {
        isActive,
      },
      select: {
        id: true,
        name: true,
        mobile: true,
        email: true,
        role: true,
        isActive: true,
        updatedAt: true,
        department: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
  }

  // ============================================================
  // REMOVE / DEACTIVATE USER
  // ============================================================

  async remove(id: string) {
    const user =
      await this.prisma.user.findUnique({
        where: {
          id,
        },
      });

    if (!user) {
      throw new NotFoundException(
        'User not found',
      );
    }

    return this.prisma.user.update({
      where: {
        id,
      },
      data: {
        isActive: false,
      },
      select: {
        id: true,
        name: true,
        mobile: true,
        isActive: true,
        updatedAt: true,
      },
    });
  }

  // ============================================================
  // GET OFFICERS
  // ============================================================

  async getOfficers(
    status = 'ACTIVE',
  ) {
    const normalizedStatus =
      String(status || 'ACTIVE').toUpperCase();

    const where: Prisma.UserWhereInput = {
      role: UserRole.OFFICER,
    };

    if (
      normalizedStatus ===
      'ACTIVE'
    ) {
      where.isActive = true;
    }

    if (
      normalizedStatus ===
      'INACTIVE'
    ) {
      where.isActive = false;
    }

    return this.prisma.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        mobile: true,
        role: true,
        isActive: true,
        departmentId: true,
        department: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        name: 'asc',
      },
    });
  }

  // ============================================================
  // GET USERS BY ROLE
  // ============================================================

  async getUsersByRole(
    role: UserRole,
  ) {
    return this.prisma.user.findMany({
      where: {
        role,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        mobile: true,
        role: true,
        department: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        name: 'asc',
      },
    });
  }

  // ============================================================
  // GET DEPARTMENT USERS
  // ============================================================

  async getDepartmentUsers(
    departmentId: string,
  ) {
    return this.prisma.user.findMany({
      where: {
        departmentId,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        mobile: true,
        role: true,
      },
      orderBy: {
        name: 'asc',
      },
    });
  }
}