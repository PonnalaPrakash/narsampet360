import {
  Body,
  BadRequestException,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';

import {
  ApiBearerAuth,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';

import {
  JwtAuthGuard,
} from '../auth/jwt-auth.guard';

import {
  Roles,
} from '../common/decorators/roles.decorator';

import {
  RolesGuard,
} from '../common/guards/roles.guard';

import {
  CreateUserDto,
} from './dto/create-user.dto';

import {
  UpdateUserDto,
} from './dto/update-user.dto';

import {
  UserQueryDto,
} from './dto/user-query.dto';

import {
  UsersService,
} from './users.service';

@ApiTags('Users')
@ApiBearerAuth('access-token')
@Controller('users')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class UsersController {
  constructor(
    private readonly usersService: UsersService,
  ) {}

  // ============================================================
  // CREATE USER
  // ============================================================

  @Post()
  @Roles('ADMIN')
  @ApiOperation({
    summary: 'Create new user',
  })
  create(
    @Body() createUserDto: CreateUserDto,
  ) {
    return this.usersService.create(
      createUserDto,
    );
  }

  // ============================================================
  // GET USERS
  //
  // status:
  // ACTIVE
  // INACTIVE
  // ALL
  //
  // Existing calls without status continue to return
  // ACTIVE users only.
  // ============================================================

  @Get()
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'MANDAL_INCHARGE',
    'VILLAGE_COORDINATOR',
    'OFFICER',
  )
  @ApiOperation({
    summary:
      'Get all users with pagination and status filter',
  })
  findAll(
    @Query() query: UserQueryDto,
    @Query('status') status?: string,
  ) {
    return this.usersService.findAll({
      page: Number(query.page) || 1,
      limit: Number(query.limit) || 10,
      search: query.search,
      role: query.role,
      status: status || 'ACTIVE',
    });
  }

  // ============================================================
  // GET OFFICERS
  //
  // Default:
  // ACTIVE officers only
  //
  // Examples:
  //
  // /users/officers
  // /users/officers?status=ACTIVE
  // /users/officers?status=INACTIVE
  // /users/officers?status=ALL
  // ============================================================

  @Get('officers')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
    'VILLAGE_COORDINATOR',
  )
  @ApiOperation({
    summary:
      'Get officers with optional status filter',
  })
  getOfficers(
    @Query('status') status?: string,
  ) {
    return this.usersService.getOfficers(
      status || 'ACTIVE',
    );
  }

  // ============================================================
  // GET USER BY ID
  // ============================================================

  @Get(':id')
  @Roles(
    'ADMIN',
    'MLA',
    'PA',
  )
  @ApiOperation({
    summary: 'Get user by id',
  })
  findOne(
    @Param('id') id: string,
  ) {
    return this.usersService.findOne(id);
  }

  // ============================================================
  // ACTIVATE / DEACTIVATE USER
  //
  // PATCH /users/:id/status
  //
  // Body:
  // {
  //   "isActive": true
  // }
  //
  // or:
  //
  // {
  //   "isActive": false
  // }
  // ============================================================

  @Patch(':id/status')
  @Roles('ADMIN')
  @ApiOperation({
    summary:
      'Activate or deactivate user',
  })
  setActiveStatus(
    @Param('id') id: string,
    @Body('isActive') isActive: boolean,
  ) {
    if (typeof isActive !== 'boolean') {
      throw new BadRequestException(
        'isActive must be a boolean',
      );
    }

    return this.usersService.setActiveStatus(
      id,
      isActive,
    );
  }

  // ============================================================
  // UPDATE USER
  //
  // isActive can also be updated here if supported by
  // UpdateUserDto.
  // ============================================================

  @Patch(':id')
  @Roles('ADMIN')
  @ApiOperation({
    summary: 'Update user',
  })
  update(
    @Param('id') id: string,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    return this.usersService.update(
      id,
      updateUserDto,
    );
  }

  // ============================================================
  // DEACTIVATE USER
  //
  // Existing DELETE endpoint preserved.
  // This is a soft delete:
  // isActive = false
  // ============================================================

  @Delete(':id')
  @Roles('ADMIN')
  @ApiOperation({
    summary: 'Deactivate user',
  })
  remove(
    @Param('id') id: string,
  ) {
    return this.usersService.remove(id);
  }
}