import {IsBoolean,
  IsString,
  IsOptional,
  IsEnum,
  IsNotEmpty,
} from 'class-validator';

import {
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';

import { UserRole } from '@prisma/client';


export class CreateUserDto {


  @ApiProperty({
    example: 'Ramesh Kumar',
  })
  @IsString()
  @IsNotEmpty()
  name: string;



  @ApiProperty({
    example: '9876543210',
  })
  @IsString()
  @IsNotEmpty()
  mobile: string;



  @ApiPropertyOptional({
    example:'ramesh@gmail.com',
  })
  @IsOptional()
  @IsString()
  email?: string;



  @ApiPropertyOptional({
    example:'123456',
  })
  @IsOptional()
  @IsString()
  password?: string;



  @ApiProperty({
    enum:UserRole,
    example:UserRole.OFFICER,
  })
  @IsEnum(UserRole)
  role:UserRole;



  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  constituencyId?:string;



  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  mandalId?:string;



  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  villageId?:string;



  @ApiPropertyOptional({
    description:'Officer department mapping',
  })
  @IsOptional()
  @IsString()
  departmentId?:string;

 @IsOptional()
@IsBoolean()
isActive?: boolean;

}