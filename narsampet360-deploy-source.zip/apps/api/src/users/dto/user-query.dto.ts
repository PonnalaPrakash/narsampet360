import {
  IsOptional,
  IsNumberString,
  IsString,
  IsEnum,
} from 'class-validator';
import { UserRole } from '@prisma/client';

export class UserQueryDto {
  @IsOptional()
  @IsNumberString()
  page?: string;

  @IsOptional()
  @IsNumberString()
  limit?: string;

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsEnum(UserRole)
  role?: UserRole;
}