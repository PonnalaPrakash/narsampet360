import {
 IsString,
 IsOptional,
 IsNumber,
} from 'class-validator';


export class CreateVillageDto {


@IsString()
name:string;


@IsString()
mandalId:string;


@IsOptional()
@IsNumber()
population?:number;


@IsOptional()
@IsNumber()
latitude?:number;


@IsOptional()
@IsNumber()
longitude?:number;


}