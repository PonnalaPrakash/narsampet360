import {
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import { PrismaService } from '../database/prisma.service';

import { CreateVillageDto } from './dto/create-village.dto';
import { UpdateVillageDto } from './dto/update-village.dto';


@Injectable()
export class VillagesService {


constructor(
 private readonly prisma:PrismaService,
){}



async create(
 createVillageDto:CreateVillageDto,
){


return this.prisma.village.create({

data:{

name:
createVillageDto.name,

mandalId:
createVillageDto.mandalId,

population:
createVillageDto.population,

latitude:
createVillageDto.latitude,

longitude:
createVillageDto.longitude,

},

include:{
 mandal:{
  select:{
   id:true,
   name:true,
  },
 },
},

});


}





async findAll(){


return this.prisma.village.findMany({


include:{
 mandal:{
  select:{
   id:true,
   name:true,
  },
 },
},


orderBy:{
 createdAt:'desc'
}


});


}





async findOne(
 id:string
){


const village =
await this.prisma.village.findUnique({


where:{
 id
},


include:{
 mandal:{
  select:{
   id:true,
   name:true,
  },
 },
},


});



if(!village){

throw new NotFoundException(
 'Village not found'
);

}


return village;


}






async update(
 id:string,
 updateVillageDto:UpdateVillageDto
){


await this.findOne(id);



return this.prisma.village.update({


where:{
 id
},


data:{
 ...updateVillageDto
},


include:{
 mandal:{
  select:{
   id:true,
   name:true,
  },
 },
},


});


}






async remove(
 id:string
){


await this.findOne(id);



return this.prisma.village.delete({


where:{
 id
},

});
}

}