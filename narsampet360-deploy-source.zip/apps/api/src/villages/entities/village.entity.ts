export class Village {}
