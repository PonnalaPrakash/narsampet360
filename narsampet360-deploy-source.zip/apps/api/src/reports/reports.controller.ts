import {
  Controller,
  Get,
  Req,
  Res,
} from '@nestjs/common';

import {
  ApiBearerAuth,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';

import type {
  Response,
} from 'express';

import {
  ReportsService,
} from './reports.service';



@ApiTags('Reports')
@ApiBearerAuth('access-token')
@Controller('reports')
export class ReportsController {


  constructor(
    private readonly reportsService: ReportsService,
  ) {}




  @Get('summary')
  @ApiOperation({
    summary:'Get grievance summary report',
  })
  getSummary(
    @Req() req:any,
  ){

    return this.reportsService.getSummary(
      req.user,
    );

  }





  @Get('department')
  @ApiOperation({
    summary:'Department wise grievance report',
  })
  getDepartmentReport(
    @Req() req:any,
  ){

    return this.reportsService.getDepartmentReport(
      req.user,
    );

  }





  @Get('monthly')
  @ApiOperation({
    summary:'Monthly grievance trend report',
  })
  getMonthlyTrend(
    @Req() req:any,
  ){

    return this.reportsService.getMonthlyTrend(
      req.user,
    );

  }





  @Get('export/csv')
  @ApiOperation({
    summary:'Export grievances CSV',
  })
  async exportCSV(
    @Req() req:any,
    @Res() res:Response,
  ){


    const csv =
    await this.reportsService.exportCSV(
      req.user,
    );



    res.header(
      'Content-Type',
      'text/csv',
    );


    res.attachment(
      'grievances-report.csv',
    );


    return res.send(csv);

  }







  @Get('export/pdf')
  @ApiOperation({
    summary:'Export grievances PDF',
  })
  async exportPDF(
    @Req() req:any,
    @Res() res:Response,
  ){


    const pdf =
    await this.reportsService.exportPDF(
      req.user,
    );



    res.setHeader(
      'Content-Type',
      'application/pdf',
    );


    res.setHeader(
      'Content-Disposition',
      'attachment; filename=grievances-report.pdf',
    );


    pdf.pipe(res);

  }


}