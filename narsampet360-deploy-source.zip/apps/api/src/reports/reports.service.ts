import {
  Injectable,
  NotFoundException,
} from '@nestjs/common';


import {
  PrismaService,
} from '../database/prisma.service';


import {
  GrievanceStatus,
  UserRole,
  Prisma,
} from '@prisma/client';


import PDFDocument from 'pdfkit';

import {
  Parser,
} from 'json2csv';





@Injectable()
export class ReportsService {



constructor(
 private readonly prisma:PrismaService,
){}


private async getFilter(
 user:any,
):Promise<Prisma.GrievanceWhereInput>{

const where:
Prisma.GrievanceWhereInput = {};

if(user.role === UserRole.ADMIN){

 return where;

}

const dbUser =
await this.prisma.user.findUnique({

 where:{
  id:user.userId,
 },

});

if(!dbUser){

 throw new NotFoundException(
  'User not found',
 );

}





switch(user.role){



case UserRole.MLA:


case UserRole.PA:


 if(dbUser.constituencyId){

  where.constituencyId =
  dbUser.constituencyId;

 }

break;

case UserRole.MANDAL_INCHARGE:
 if(dbUser.mandalId){

  where.mandalId =
  dbUser.mandalId;

 }
break;

case UserRole.VILLAGE_COORDINATOR:


 if(dbUser.villageId){

  where.villageId =
  dbUser.villageId;

 }

break;

case UserRole.OFFICER:


 where.assignedToId =
 user.userId;


break;



}



return where;


}






async getSummary(
 user:any,
){



const where =
await this.getFilter(
 user,
);





const [
 total,
 pending,
 assigned,
 inProgress,
 resolved,
 rejected,
 closed,

] = await Promise.all([



this.prisma.grievance.count({
 where,
}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.PENDING,
},

}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.ASSIGNED,
},

}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.IN_PROGRESS,
},

}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.RESOLVED,
},

}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.REJECTED,
},

}),




this.prisma.grievance.count({

where:{
 ...where,
 status:GrievanceStatus.CLOSED,
},

}),



]);





return {

 total,
 pending,
 assigned,
 inProgress,
 resolved,
 rejected,
 closed,

};



}
async getDepartmentReport(
 user:any,
){



const where =
await this.getFilter(
 user,
);





const data =
await this.prisma.grievance.groupBy({

 by:[
  'departmentId',
 ],

 where,


 _count:{
  id:true,
 },


});







const departments =
await this.prisma.department.findMany({

 select:{
  id:true,
  name:true,
 },

});






const departmentMap =
new Map(

 departments.map(
  department=>[

   department.id,
   department.name,

  ],
 ),

);






return data.map(item=>({



 department:

 item.departmentId

 ?

 (
  departmentMap.get(
   item.departmentId,
  )
  ||
  'Unknown'
 )

 :

 'Unknown',




 total:
 item._count.id,



}));



}








async getMonthlyTrend(
 user:any,
){



const where =
await this.getFilter(
 user,
);






const grievances =
await this.prisma.grievance.findMany({

 where,


 select:{

  createdAt:true,

  status:true,

 },


 orderBy:{
  createdAt:'asc',
 },


});







const months:

Record<
 string,
 {
  month:string;
  created:number;
  resolved:number;
 }
>

={};






grievances.forEach(item=>{


const month =
item.createdAt
.toISOString()
.substring(
0,
7,
);





if(!months[month]){


 months[month]={

  month,

  created:0,

  resolved:0,

 };


}




months[month].created++;





if(

 item.status === GrievanceStatus.RESOLVED

 ||

 item.status === GrievanceStatus.CLOSED

){


 months[month].resolved++;


}



});







return Object.values(months);



}
async exportCSV(
 user:any,
){



const where =
await this.getFilter(
 user,
);






const grievances =
await this.prisma.grievance.findMany({

 where,


 include:{

  department:{
   select:{
    name:true,
   },
  },


  assignedTo:{
   select:{
    name:true,
   },
  },


 },



 orderBy:{
  createdAt:'desc',
 },


});







const rows =
grievances.map(item=>({



 Title:item.title,


 Citizen:item.citizenName,


 Mobile:item.citizenMobile,


 Status:item.status,


 Priority:item.priority,


 Department:
 item.department?.name || '',



 Officer:
 item.assignedTo?.name || '',



 CreatedAt:
 item.createdAt,



}));







const parser =
new Parser();



return parser.parse(rows);



}









async exportPDF(
 user:any,
){



const where =
await this.getFilter(
 user,
);






const grievances =
await this.prisma.grievance.findMany({

 where,


 include:{


  department:{
   select:{
    name:true,
   },
  },


  assignedTo:{
   select:{
    name:true,
   },
  },


 },


 orderBy:{
  createdAt:'desc',
 },

});






const doc =
new PDFDocument();






doc.fontSize(18)
.text(
'Grievance Report',
{
 align:'center',
}
);




doc.moveDown();






grievances.forEach(
(item,index)=>{



doc.fontSize(12)
.text(
`${index+1}. ${item.title}`
);



doc.text(
`Citizen: ${item.citizenName}`
);



doc.text(
`Mobile: ${item.citizenMobile}`
);



doc.text(
`Status: ${item.status}`
);



doc.text(
`Priority: ${item.priority}`
);



doc.text(
`Department: ${
 item.department?.name ||
 'Unknown'
}`
);



doc.text(
`Officer: ${
 item.assignedTo?.name ||
 'Not Assigned'
}`
);



doc.moveDown();



});





doc.end();



return doc;


}
}