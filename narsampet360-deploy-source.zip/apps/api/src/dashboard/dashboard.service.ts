import {
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import {
  PrismaService,
} from '../database/prisma.service';

import {
  GrievanceStatus,
  UserRole,
  Prisma,
} from '@prisma/client';


@Injectable()
export class DashboardService {


  constructor(
    private readonly prisma: PrismaService,
  ) {}



  private async getFilter(
    userId: string,
    role: UserRole,
  ): Promise<Prisma.GrievanceWhereInput> {


    const where: Prisma.GrievanceWhereInput = {};



    if (role === UserRole.ADMIN) {

      return where;

    }



    const user =
      await this.prisma.user.findUnique({

        where:{
          id:userId,
        },

      });



    if(!user){

      throw new NotFoundException(
        'User not found',
      );

    }



    switch(role){


      case UserRole.MLA:

      case UserRole.PA:

        if(user.constituencyId){

          where.constituencyId =
            user.constituencyId;

        }

        break;



      case UserRole.MANDAL_INCHARGE:

        if(user.mandalId){

          where.mandalId =
            user.mandalId;

        }

        break;



      case UserRole.VILLAGE_COORDINATOR:

        if(user.villageId){

          where.villageId =
            user.villageId;

        }

        break;



      case UserRole.OFFICER:

        where.assignedToId =
          userId;

        break;


    }



    return where;

  }






  async getDashboard(

    userId:string,

    role:UserRole,

  ){



    const where =
      await this.getFilter(
        userId,
        role,
      );




    const todayStart =
      new Date();

    todayStart.setHours(
      0,
      0,
      0,
      0,
    );




    const [

      totalGrievances,

      pending,

      assigned,

      inProgress,

      resolved,

      rejected,

      closed,

      totalUsers,

      totalDepartments,

      totalMandals,

      totalVillages,

      today,


    ] = await Promise.all([



      this.prisma.grievance.count({

        where,

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.PENDING,
        },

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.ASSIGNED,
        },

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.IN_PROGRESS,
        },

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.RESOLVED,
        },

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.REJECTED,
        },

      }),




      this.prisma.grievance.count({

        where:{
          ...where,
          status:
            GrievanceStatus.CLOSED,
        },

      }),




      role === UserRole.ADMIN

      ? this.prisma.user.count()

      : Promise.resolve(0),




      role === UserRole.ADMIN

      ? this.prisma.department.count()

      : Promise.resolve(0),




      role === UserRole.ADMIN

      ? this.prisma.mandal.count()

      : Promise.resolve(0),




      role === UserRole.ADMIN

      ? this.prisma.village.count()

      : Promise.resolve(0),




      this.prisma.grievance.count({

        where:{

          ...where,

          createdAt:{

            gte:
              todayStart,

          },

        },

      }),


    ]);





    return {


      role,



      summary:{


        totalUsers,

        totalDepartments,

        totalMandals,

        totalVillages,


        totalGrievances,


        pending,

        assigned,

        inProgress,

        resolved,

        rejected,

        closed,


        today,


      },



      recentGrievances:

        await this.prisma.grievance.findMany({


          where,


          orderBy:{

            createdAt:'desc',

          },


          take:10,



          include:{


            department:true,


            assignedTo:{


              select:{


                id:true,

                name:true,


              },

            },



            village:true,

            mandal:true,


          },


        }),



    };


  }

    async getAnalytics(

    userId:string,

    role:UserRole,

  ){


    const where =
      await this.getFilter(
        userId,
        role,
      );




    const [

      statusWise,

      priorityWise,

      departmentWise,

    ] = await Promise.all([




      this.prisma.grievance.groupBy({

        by:[
          'status',
        ],

        where,

        _count:{

          id:true,

        },

      }),





      this.prisma.grievance.groupBy({

        by:[
          'priority',
        ],

        where,

        _count:{

          id:true,

        },

      }),





      this.prisma.grievance.groupBy({

        by:[
          'departmentId',
        ],

        where,

        _count:{

          id:true,

        },

      }),



    ]);






    const departments =

      await this.prisma.department.findMany({

        select:{

          id:true,

          name:true,

        },

      });





    const departmentMap =

      new Map(

        departments.map(

          department => [

            department.id,

            department.name,

          ],

        ),

      );







    return {



      statusWise:

        statusWise.map(item => ({


          status:item.status,


          count:item._count.id,


        })),






      priorityWise:

        priorityWise.map(item => ({



          priority:item.priority,


          count:item._count.id,



        })),







      departmentWise:

        departmentWise.map(item => ({



          department:


            item.departmentId

            ? (

              departmentMap.get(
                item.departmentId,
              )

              || 'Unknown'

            )

            : 'Unknown',




          count:

            item._count.id,



        })),



    };


  }
    async getTrends(

    userId:string,

    role:UserRole,

  ){


    const where =
      await this.getFilter(
        userId,
        role,
      );




    const grievances =

      await this.prisma.grievance.findMany({

        where,

        select:{

          createdAt:true,

          status:true,

        },


        orderBy:{

          createdAt:'asc',

        },


      });






    const monthly:

      Record<

        string,

        {

          total:number;

          resolved:number;

        }

      > = {};






    grievances.forEach(item => {



      const month =

        item.createdAt

        .toISOString()

        .substring(
          0,
          7,
        );





      if(!monthly[month]){


        monthly[month]={

          total:0,

          resolved:0,

        };


      }






      monthly[month].total++;





      if(

        item.status ===

        GrievanceStatus.RESOLVED

        ||

        item.status ===

        GrievanceStatus.CLOSED

      ){


        monthly[month].resolved++;


      }



    });







    return Object.keys(monthly)

      .map(month => ({


        month,


        total:

          monthly[month].total,



        resolved:

          monthly[month].resolved,



      }));


  }



}