import {
  Controller,
  Get,
  Req,
} from '@nestjs/common';

import {
  ApiBearerAuth,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';

import { DashboardService } from './dashboard.service';


@ApiTags('Dashboard')
@ApiBearerAuth('access-token')
@Controller('dashboard')
export class DashboardController {


  constructor(
    private readonly dashboardService: DashboardService,
  ){}



  @Get()
  @ApiOperation({
    summary:'Role based dashboard summary',
  })
  getDashboard(
    @Req() req:any,
  ){

    return this.dashboardService.getDashboard(

      req.user.userId,

      req.user.role,

    );

  }





  @Get('analytics')
  @ApiOperation({
    summary:'Dashboard analytics',
  })
  getAnalytics(

    @Req() req:any,

  ){

    return this.dashboardService.getAnalytics(

      req.user.userId,

      req.user.role,

    );
   
  }

  @Get('trends')
@ApiOperation({
  summary:'Monthly grievance trends',
})
getTrends(

  @Req() req:any,

){

  return this.dashboardService.getTrends(

    req.user.userId,

    req.user.role,

  );

}


}