import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';

import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';

import { DatabaseModule } from './database/database.module';

import { HealthModule } from './health/health.module';
import { AuthModule } from './auth/auth.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { ProfileModule } from './profile/profile.module';
import { MasterModule } from './master/master.module';
import { GrievanceModule } from './grievance/grievance.module';
import { UsersModule } from './users/users.module';

import { ConstituencyModule } from './constituency/constituency.module';
import { MandalsModule } from './mandals/mandals.module';
import { VillagesModule } from './villages/villages.module';
import { DepartmentsModule } from './departments/departments.module';

import { CommentsModule } from './comments/comments.module';
import { AttachmentsModule } from './attachments/attachments.module';
import { NotificationsModule } from './notifications/notifications.module';
import { ReportsModule } from './reports/reports.module';
import { BusinessesModule } from './businesses/businesses.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    DatabaseModule,

    HealthModule,
    AuthModule,
    DashboardModule,
    ProfileModule,
    MasterModule,
    GrievanceModule,
    UsersModule,

    ConstituencyModule,
    MandalsModule,
    VillagesModule,
    DepartmentsModule,

    CommentsModule,
    AttachmentsModule,
    NotificationsModule,
    ReportsModule,
    BusinessesModule,
  ],

  providers: [

  {
    provide: APP_GUARD,
    useClass: JwtAuthGuard,
  },

  {
    provide: APP_GUARD,
    useClass: RolesGuard,
  },

],
})
export class AppModule {}